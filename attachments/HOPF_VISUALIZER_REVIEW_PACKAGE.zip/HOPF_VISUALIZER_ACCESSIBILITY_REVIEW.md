# Hopf Visualizer — accessibility and inclusive interaction specialist

Review date: September 15, 2026  
Scope: The Visualizer as the site's visually impressive, functional centerpiece.  
Live inspection: https://hopf-workshop.vercel.app/  
Method: Supported live browser; fresh dedicated tab `accessibilityVizTab`; rendered DOM, computed layout, keyboard mode-switch interaction, and visual inspection. No source-code inspection, implementation, deployment, real screen-reader session, or mobile-device session.

## Recommendation

Make the geometry a large, beautiful instrument people can actually operate. A person should be able to select a participant, proposal, phase, blocker, or past event in the scene and learn **what it means, why it is in that state, and what can happen next**. The same interaction must work by keyboard and touch, with an inspect panel that is part of the main composition.

The accessibility goal is not a text alternative buried below an impressive picture. It is one coherent experience with a richly drawn scene, a visible compact state summary, an equivalent object navigator, and a synchronized inspector. People who use different inputs should be working on the same objects and understanding the same decision.

The strongest design opportunity is to make disagreement and recovery legible without presenting either as a person failing the group. Use beautiful materials and meaningful motion; keep labels, state distinctions, and participant agency precise.

## Evidence: newly inspected versus reused

| Evidence | Status | Meaning for this redesign |
|---|---|---|
| Canvas has intrinsic dimensions 900×520, but the inspected desktop layout renders it at 838×233 CSS pixels. Its computed aspect ratio is `auto 900 / 520`, while the explicit rendered dimensions have ratio about 3.60:1. | **Newly measured.** | The scene is visibly flattened. The drawing's aspect ratio must be preserved, or the renderer must recompute its projection for the actual viewport. This is a primary legibility and visual-quality problem. |
| Before scrolling, the canvas's top edge was at document/viewport y=1176. Its rendered height was 233px. | **Newly measured** on this desktop viewport. | The intended centerpiece currently arrives well below the opening material and receives little vertical space. Bring the Visualizer into the primary opening composition. Do not treat this coordinate as a universal breakpoint measurement. |
| Canvas is a `CANVAS` with `role="img"`, no `tabindex`, no child elements, default cursor and touch-action. | **Newly inspected DOM.** | No graphical object navigation is exposed in the observed DOM. There are external controls, but a viewer cannot discover participant/proposal/phase controls inside the image through keyboard semantics. This does not prove absence of all pointer event handlers. |
| Bundle mode changes the caption and canvas accessible name to a description of solid-torus charts, the Clifford torus, and linked fibres. | **Newly tested** with the visible Bundle map button. | Preserve this useful mode description, then add current-state and selected-object descriptions. A geometry label alone does not explain who has agreed or what is blocked. |
| Pressing ArrowLeft while Bundle map is focused leaves focus on `map-bundle`; the mode remains Bundle. The container is still exposed as a tablist, while children are pressed buttons. | **Newly tested**, confirming the earlier mixed-pattern issue in the reverse direction. | Choose a coherent drawing-mode control pattern rather than carrying an incomplete tabs widget into the centerpiece. |
| The sole observed live region is the Parade ledger, `#ledger`, with `aria-live="polite"`. | **Newly inspected.** | The Visualizer has no dedicated concise change-announcement channel. Add one derived from the same state events that drive the scene. |
| Screenshot shows extremely small canvas annotations and thin dim linework against a near-black stage. | **New visual observation, not a quantitative canvas contrast audit.** | Separate atmospheric background fibres from meaningful foreground objects, with readable HTML/SVG labels and sufficient line weight. |
| Earlier whole-site review calculated the authored yellow focus cue at approximately 1.46–1.52:1 on pale panels, and observed focus dropping to BODY after participant consent/readiness changes. | **Reused evidence** from `reviews/accessibility-review.md`; not retested on every action in this focused pass. | These defects must not migrate into new actor controls, mode controls, object navigation, or the inspector. Retest the completed redesigned workflow. |

## The centerpiece's inclusive composition

Use a large, stable stage with a restrained control bar and a visually integrated inspector. On desktop, the scene should dominate the width and have enough height to distinguish the upper cone, torus, and lower cone. Keep the current proposal and decision status adjacent to the scene, not scattered among raw mathematical readings. When the viewport is narrow, preserve a useful scene and place the inspector directly below or in an explicitly opened sheet; do not reduce the stage to a decorative thumbnail.

Always expose these four small pieces of information visually and semantically:

1. **Context:** table/scenario, proposal version, and whether the view is simulation, current state, or replay.
2. **Current phase and condition:** for example, “Proposal review · waiting for current consent.” Do not invent a percentage of completion where the process can branch or return.
3. **People and prerequisites:** exact participant states and exact missing conditions.
4. **Latest consequential change:** what changed, who initiated it, and what remains possible.

The inspector is the detailed answer to selection. It should show object name, kind, state, proposal/version binding, last meaningful event, reason/evidence, and relevant actions. Advanced geometry may be a disclosure within the same panel. These fields are a proposed design contract; map them to actual repository contracts before implementation. Do not invent authority or provenance that the current simulation does not record.

## Visual language that remains readable

Retain the visual richness: a sculptural torus, luminous fibres, depth, well-composed lighting, distinct participant anchors, and carefully timed transitions can make this feel memorable. Use the brightest emphasis on the selected object, the current phase, and the next unresolved condition. Background fibres, stars, particles, and glow should recede.

Use stable identity colors for people, separate from status. Do not turn a participant's whole body red for declining a proposal or move their avatar outside the social circle. Instead, attach an explicit “Declined v2” badge, a recognizable icon, and a relationship to the affected proposal. A withdrawn consent is a change in authorization state, not a disappearing person.

Meaningful labels need a solid or reliably controlled backing surface. Do not put small text directly across bloom, transparent overlapping geometry, or moving clouds. Required graphical boundaries, meaningful states, and authored focus cues need 3:1 contrast against adjacent colors; extremely thin lines can remain hard to perceive even when nominal colors meet that threshold. Decorative lines may stay subtle. Normal-size labels need the applicable text contrast threshold, typically 4.5:1. [W3C Non-text Contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html)

Use shape, symbol, and words together. A suggested mapping is below; the protocol specialist must confirm each state actually exists and what it permits.

| Meaning | Scene cue | Required visible/spoken wording | Critical distinction |
|---|---|---|---|
| No choice recorded | Hollow state chip with a dash | “Maya · no decision recorded · v2” | Missing information is not a no. |
| Ready | Separate readiness chip | “Maya ready; consent still needed” | Readiness never fills the consent indicator. |
| Current consent | Check symbol and outlined affirmative chip | “Maya consents to proposal v2” | It must be tied to this version. |
| Declined | Clear stop/decline icon, ordinary emphasis | “Maya declined proposal v2” | Avoid a danger aura or punishment-like effects around Maya. |
| Consent withdrawn | Withdraw icon plus event marker | “Maya withdrew consent to v2” | Preserve the person and the preceding consent in history. |
| Consent belongs to an earlier version | Muted historical chip with version badge | “Consent recorded for v1; v2 needs a new choice” | Earlier consent cannot masquerade as current consent. |
| Proposal cannot proceed | Gate icon and counted reasons | “Blocked: safety review and Bea's current consent are missing” | “Blocked” identifies conditions, not merely a red stage. |
| Prerequisites satisfied | Open-gate/available-action cue | “Ready to commit; commitment not yet recorded” | Meeting prerequisites is not the commitment action. |
| Commitment recorded | Distinct solid commitment marker | “Committed to v2 at event 12” | Commit is not act, success, or unanimous preference strength. |
| Work has begun | Phase marker on ACT, with execution state | “Acting on v2” | Movement should not imply successful completion. |
| Repair needed | Clearly labeled repair branch | “Repair needed: [recorded reason]” | A loop is a legitimate route, not a graph rendering error. |
| Return/outcome recorded | Return marker attached to retained history | “Round 1 returned; recorded outcome: …” | Return is not erasure or a fresh proposal's authorization. |
| Viewing history | Persistent Replay banner and event position | “Replay · event 8 of 17 · proposal v1” | Historical state cannot be presented as the live state. |
| Current state unavailable/stale | Distinct stale-data banner and last confirmed event | “Updates disconnected; showing last confirmed state” | Frozen rendering is not evidence of no change. |

Do not use a green filling ring to collapse consent, safety, authority, and test evidence into one numerical readiness score. If counts are useful, show separate named facts such as “3 of 4 required participants currently consent”; the denominator must come from the selected table and proposal.

## Graphical object and keyboard contract

Give every meaningful selectable item a stable object ID and one semantic representation. Separate transient hover, keyboard focus, pinned selection, and authority-changing commands. Hover may preview. Focus identifies where keyboard input goes. Selection opens information. None of those records consent, commits a proposal, or advances a round.

For a small number of visible actor and phase anchors, use native HTML buttons positioned with the scene or accessible SVG/HTML counterparts. For a dense geometric scene, provide an always discoverable “Objects in this view” navigator next to the stage, with compact groups such as Participants, Proposal, Prerequisites, and Events. Selecting an item highlights the actual object and opens the same inspector. Avoid hundreds of invisible tab stops and avoid duplicating the same command in a hidden accessibility tree.

The simplest reliable base is ordinary buttons and grouped lists. If a roving-focus composite is used, follow one established widget pattern fully; do not add a generic `role="application"` to the whole site. Tab should enter and leave the Visualizer predictably. Arrow navigation inside a chosen composite must be explained and must not steal the arrow keys from a slider or text field. Home/End should have consistent documented behavior where relevant.

Selection should remain stable through live scene updates, camera changes, 2D/3D switching, and inspector editing. Updating Maya's state must not replace the focused control and leave focus on BODY. If an event or object legitimately disappears from the current filtered view, move focus to a defined neighboring object or the containing group and announce that reason. Never automatically focus a newly added event while the user is reading.

Use a distinct high-contrast focus outline that remains visible over any scene material, in addition to the selected-object treatment. If a selected object is occluded, use a labeled screen-space anchor or reveal control. A participant behind a torus still needs an operable target. Do not require orbiting until the correct pixel happens to become visible.

## Inspector, actions, and attribution

Desktop inspection can be a nonmodal complementary region with its own heading and a “Focus details” control. Selecting a scene object need not throw keyboard focus into the panel; the user should be able to continue browsing objects. A deliberate Open details action can move focus to the inspector heading. An explicit close/return action returns it to the originating object.

If mobile inspection is implemented as a modal sheet, it needs a label, an intentional initial focus target, contained tab order, Escape/close behavior, and focus returned to the invoker. The content behind it must behave consistently with a modal. Do not apply modal semantics to a panel that leaves the background operable. [W3C Modal Dialog Pattern](https://www.w3.org/WAI/ARIA/apg/patterns/dialog-modal/)

Every actor-specific action must name its actor and current proposal in the relevant context: “Record Maya's yes to v2” in this simulation, or an appropriately authenticated first-person action if such a feature is actually implemented. Inspecting Bea's object should not allow a visitor to mistake selecting Bea for being Bea. Make simulated actor controls visibly labeled as simulation controls.

Show disabled-action reasons next to the relevant action and in the inspector. If a disabled control cannot receive focus, its explanation must be reachable elsewhere without pointer hover. For an enabled attempt that is rejected, retain focus, display a concise reason, and announce the actual rejected outcome. Do not animate the requested successful transition before the protocol accepts it.

## Touch, geometry manipulation, and modes

Aim for roughly 44×44 CSS-pixel effective targets for primary controls and object anchors, with spacing. That is a product usability target, not a claim that all AA targets require 44px. Evaluate the precise WCAG 2.2 24px minimum-or-spacing rule and exceptions on the completed layout. Overlapping invisible hit areas are not a solution: they make adjacent actor choices ambiguous.

Give camera orbit, pan, zoom, and timeline scrub single-pointer alternatives: labeled controls, presets, step buttons, or a precise field. Pointer dragging can remain an attractive convenience; neither meaningful navigation nor required functionality should rely on dragging alone when an exception does not apply. Keyboard equivalence and a non-drag pointer alternative are separate checks. [W3C Dragging Movements](https://www.w3.org/WAI/WCAG22/Understanding/dragging-movements.html)

Provide Reset view and Focus selected object. Explain whether geometry controls change the camera, the displayed coordinates, or a proposal candidate. The present site explicitly distinguishes display from protocol; preserve that difference. Keep unit names stable, use readable current values, and expose the same units to assistive technology. Avoid tiny Greek letters as the only explanation.

Use a labeled button group or radio group for exclusive view choices unless true tab panels are intended. Separate “Decision process / Mathematical structure” from “3D / 2D” and “Current / Replay” where these are actually independent dimensions. Those choices answer different questions. A switch must preserve selected object and applicable context or explicitly explain why it cannot.

## Motion should reveal a transition, not create a dependency

Animate the consequence of a recorded event: an event marker arrives, the affected participant chip changes, and the relevant relation highlights. Do not auto-orbit by default while someone is making or inspecting decisions. Restrict decorative particles and continuous glow cycling so that meaningful changes remain distinguishable.

Include an easily found Pause motion control. Honor reduced-motion preferences by removing nonessential orbit, parallax, camera flights, bloom pulses, particle travel, and repeated attention effects; state changes should still appear promptly with static highlights and words. A reduced-motion view should retain the geometry, color, depth cues, and all functionality.

Be precise about what pauses. “Pause motion” stops visual animation; it does not stop real decisions occurring or silently freeze the latest state. “Pause replay” stops advancing the historical event cursor. “Hold this view” would be a separate feature requiring an unmistakable held/historical label and a way to return to current state. Persistent automatically moving or updating content must provide applicable pause/stop/hide or update-control behavior. [W3C Pause, Stop, Hide](https://www.w3.org/WAI/WCAG22/Understanding/pause-stop-hide.html)

Avoid flashes, compulsory countdowns, urgency effects on dissent, and audio as the only signal. If optional sound is later added, its cue must have a visible equivalent and independent mute control. None is necessary for this visualizer upgrade.

## Synchronized state narration

Derive scene objects, compact summary, inspector, object navigator, and announcements from the same accepted state/view model. This is the strongest protection against an accessible route becoming an inaccurate shadow version of the application.

The visible state summary should answer a useful sentence, for example: “Reviewing proposal v2. Maya and Finn have consented; Bea has not decided. Safety review is missing. No commitment has been recorded.” The actual names, required participants, and reasons must come from the selected scenario, not hardcoded prose.

A stable polite status region should announce meaningful accepted changes once: “Bea withdrew consent to v2. The current commitment status is [actual resulting status].” Do not assume withdrawal always yields the same phase; follow the actual protocol. Keep a separate navigable event history for details. Do not announce every animation frame, camera angle, changing timestamp, or scrubbing pixel.

For fast event streams, summarize a batch and offer Review changes. While replay is paused, announce only the event explicitly selected. If incoming live data arrives while viewing history, show “New current events available” without moving the historical cursor. Ensure announcing a result never silently changes focus.

## 2D fallback and failure are first-class views

Create a graceful 2D process representation with the same proposal, actor anchors, phase states, reasons, inspector, and history. It can still be beautifully designed and animated sparingly. It must not become a plain emergency table that looks unrelated to the main instrument.

Offer 2D as a user choice. If 3D fails or is unavailable, keep the same state and selection and show a short explanation: “3D view unavailable. Showing the same decision in 2D.” Do not reset the round or pretend no data exists. If the state source itself is unavailable, say that separately and show only the last confirmed state with its freshness information.

Keep labels and controls as real responsive content around the scene. At zoom and narrow widths, preserve readable state and operable actions without horizontal page scrolling merely to reach the inspector. A complex diagram may intrinsically need two-dimensional navigation; that does not exempt surrounding controls and text from usable reflow. Large-text users must be able to collapse advanced controls and give the scene or inspector more space.

## Feature-level acceptance criteria

Each item below belongs in the implementation inventory and must receive its own four-loop evidence, not merely a shared claim that the Visualizer was checked.

| Feature | Acceptance that an independent reviewer must demonstrate |
|---|---|
| Stage layout and labels | Geometry retains correct proportions at all target sizes; primary scene labels remain readable; inspector and essential controls reflow; selection and current phase can be found without reading a ledger. |
| Object selection and navigation | Every actionable object is selectable by pointer, keyboard, and non-drag touch; selection and focus are visibly distinct; one object ID resolves consistently across scene and navigator. |
| Actor state encoding | Unset, ready, consented, declined, withdrawn, and earlier-version consent remain distinguishable with color removed and with a screen reader; identity stays stable across changes. |
| Phase, blockers, and progress | Reviewer identifies the phase, missing requirements, and next allowed action from scene plus summary; no invented completion score or false successful transition appears. |
| Inspector | Relevant context and reasons are available for all object kinds; actions have attribution; focus is predictable on open, update, and close on desktop and mobile. |
| Geometry/camera controls | Reset, focus selected object, view changes, and precision adjustments work without dragging; camera experimentation cannot silently mutate consent or authorization. |
| View/mode controls | Correct native/ARIA pattern and keyboard behavior; context and selection preserved; user can explain the difference between process, structure, current/replay, and 2D/3D. |
| Motion controls | Reduced motion is honored; Pause motion does what its label says; current state remains truthful; no meaning depends on travel, pulse, or animation timing. |
| Summary and announcements | Accepted, blocked, failed, and historical changes are represented accurately, once, with no focus theft; no stale version is read as current. |
| Replay | Previous/next and scrub alternatives work; historical context is unmistakable; latest events never overwrite the chosen past view; Return to current restores current state explicitly. |
| Fallback and degraded state | Forced 3D failure preserves selection and state in 2D; data failure is distinct from renderer failure; stale/unknown state never becomes an apparent all-clear. |

## Four independent verification-and-revision loops per feature

Apply the following sequence to **every feature in the final inventory**, including features split or added during implementation. The implementation owner cannot certify their own feature. Different lenses within the same reviewing agent can be useful, but independent verification must actually run separately from the builder and inspect the resulting artifact.

| Loop | Independent work | Required result |
|---|---|---|
| 1 — Discover and operate | Use the live built scene to find/select the feature by keyboard and pointer; inspect semantics, naming, visible focus, essential contrast, and obvious geometry/label quality. | Record exact failures; builder revises; independent reviewer reruns the failed steps on the revised artifact. |
| 2 — Change and recover | Exercise the feature through proposal replacement, absent consent, withdrawal, accepted action, blocked action, replay, and return wherever applicable. Verify focus, version binding, announcements, selection, and no accidental authority action. | Revise concrete defects and independently verify the revised transition plus a different ordering. Document genuinely inapplicable transitions with reasons. |
| 3 — Different body, device, and rendering conditions | Keyboard only; real screen reader/browser pair; touch or relevant real device; large text/zoom/reflow; color-independent meaning; forced colors; reduced motion; 2D; slow or failed renderer/data source as relevant. | Fix the actual failure, then independently rerun the affected environment and adjacent state. Unavailable real AT/device checks remain explicitly unverified. |
| 4 — Integrated decision comprehension | A reviewer who did not build the feature completes the decision task from a fresh session using both the scene and equivalent route, with an interruption and disagreement/recovery path. Ask them to identify what changed, who is needed, whether commitment exists, and what happens next. | Revise cross-feature defects. Independently verify the final revised artifact again; any later relevant code change invalidates that feature's affected evidence. |

For each loop retain feature ID, build/commit or artifact identifier, reviewer, environment, starting state, exact actions, expected/actual result, evidence, defects, revision, and post-revision verification. Four cycles are a minimum, not an excuse to stop with known failures. If a pass finds no defect, record “no change needed” and why; do not manufacture arbitrary changes. Automated scans supplement actual interaction and cannot prove comprehension, spoken output, or focus restoration.

The final experience should feel impressive because it makes a difficult collective process unusually visible. A user who cannot see color, cannot drag, or does not want motion should still feel that they are using the site's centerpiece—not an inferior side entrance.
