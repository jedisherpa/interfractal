# Visualizer review: clarity, information architecture, and useful interaction

Specialist continuation: first-time usability, information architecture, and plain language. Reinspected the live [Hopf Workshop](https://hopf-workshop.vercel.app/) on 15 September 2026 using a separate review tab, `clarityVizTab`. This review is restricted to making the Visualizer the site's centerpiece. It builds on the earlier specialist review without re-auditing the whole homepage.

## The recommendation

Make the Visualizer a large, interactive **view of this group's decision right now**. Its geometry should organize and reveal the work: the idea being considered, the people responding, the checks supporting it, the agreement that currently permits action, the action's result, and anything that requires attention. Clicking a meaningful object should explain it and reveal the relevant actions.

The centerpiece must answer five questions together: **What are we deciding? Where are we in the process? What is true right now? Why can or can't we act? What can I do next?** A beautiful shape alone cannot answer them. A dashboard full of numbers does not answer them either. The core experience should combine the shape, names, readable state, and direct interaction in one stage.

Keep the mathematical view first-class and visually impressive. Put mathematical diagnostics in optional detail, not the Visualizer itself. Treat the process visualization and mathematical geometry as distinct lenses over coordinated selection and context; do not invent a mathematical equivalence between a fibre and a person's authority.

## Live observations and their limits

I opened the live page, switched to **Bundle map**, inspected its screenshot and controls, ran **Run cardboard-dragon demo**, switched back to **Hourglass / process**, inspected the paused state, and selected **Resolve repair**. These were the site's fictional teaching interactions. No source or deployed files were changed.

1. The process canvas was measured at approximately **838 × 233 CSS pixels** in a **1363 × 936 viewport**. Its image description names generate/keep/release funnels. The screenshot shows a thin hourglass outline, an elliptical central region, and colored lines against black. The drawing does not visibly identify a current proposal, active agreement, participant, blocker, current step, outcome, or next action.
2. The geometry drawing occupies the left card; the actual proposal and participant choices occupy a narrow right card. At the inspected position, some decision actions and reasons require additional scrolling. There is no single composition that binds a participant choice to a visible change in the process.
3. **Bundle map** exposes the alternative drawing and updates its explanatory text. The same block below it lists display/protocol coordinates, a route suggestion, holonomy, the Chern integral, linking, and residual. These are mathematical/coordinate signals, not a current decision summary.
4. Running the dragon demo moved the three-person table to **paused**, proposal **v2**, orchard-route wording, Maya/Finn yes, Bea no, and two blockers: missing current consent and consequences requiring a response. The event log preserves a successful earlier commit/action and then withdrawal and a blocked further action.
5. After this demo, the geometry metrics and accessible image description did not express the new decision state. **Suggestion: Bridge route** remained visible beside **v2: Carry the dragon through the checked orchard route**. This is not evidence of a protocol bug: an exploratory suggestion may legitimately differ from a proposal. The interface needs to make their different roles immediately clear.
6. **Resolve repair** removed the repair-related blocker; the table remained **paused**, Bea remained no, and missing consent remained. That is an important distinction to show as a positive, visible partial change: one issue addressed, permission still absent.
7. The adjacent four-person practice table has different readiness, round, ACT, and RETURN concepts. Its state should not be silently folded into the three-person simulation just to create one attractive picture.

These are expert inspection findings, not measured user-study results. I did not audit source architecture, mathematical correctness, persistence, real participant identity, or physical mobile devices. Exact canonical semantics must be established from the repository before implementation. The proposed richer interaction design below is not a claim about current functionality.

## Proposed composition: a decision stage

The main screen should have a concise workshop header and then the Visualizer occupying the dominant area. The normal view should already be useful; fullscreen expands it rather than making it usable for the first time.

**A stable state header above the geometry:** show the selected scenario, current round if the selected protocol has one, proposal version, and one readable state sentence. Example after the demo: **“Action paused. Bea withdrew from agreement v2.”** Below it: **“The earlier action remains in the history. Another action is blocked.”** Pair this with an explicit **Simulation** indicator.

**The central visual scene:** use the workshop's upper cone, central torus/table, and lower cone as a process metaphor. Give those regions short names and render the relevant proposal, agreement, and consequence objects in context. Only map a region to a protocol state when that mapping is documented; unmodeled regions may be navigational/educational landmarks, not invented lifecycle states. Show one selected decision clearly before adding many objects.

**Participants around the working region:** stable identities and stable positions, each with labeled status markers. The selected person has an inspector with their current-version choice and available actions. Connection styles mean specific things defined in a visible legend. Decorative orbiting must not move identities around unpredictably or imply stronger consensus.

**A focused inspector beside the scene:** selection opens the relevant information and controls—participant, proposal, agreement, check, blocked transition, or outcome. The default inspector explains the current state and next useful action. It should not begin as an exhaustive control wall.

**A compact progress and history area below:** current phase plus separate counts for relevant prerequisites. Recent events appear as readable cards with versions and consequences. A timeline can expand into replay. The central scene, inspector, and text equivalent are projections of the same selected scenario and event position.

On a phone, keep the state header, a meaningful compact scene, and the primary explanation visible in a logical sequence. Selecting an object opens a bottom sheet or inline inspector without losing the current state. All scene actions must also exist in an accessible list; they must not require precise manipulation of a tiny 3D object.

## State-to-visual contract

Every visual encoding below is a proposal requiring confirmation against canonical state. Text and shape accompany color. Counts use the actual relevant participant set or required checks, not fixed demonstration assumptions.

| State or concept | On-stage representation | Selection reveals | Critical invariant |
|---|---|---|---|
| Exploratory geometry / suggestion | A clearly marked preview trace or ghost object, labeled **Exploration**; show **Suggestion: Bridge route** | What coordinates produced it; **Use as a new proposal** only if supported | Exploration cannot alter agreement, consent, or permission |
| Draft / current proposal | A proposal object carrying a version and short title; an outline distinguishes it from an active agreement | Exact wording, version, scope, evidence, changes from previous version | A new version cannot inherit old signatures by visual continuity |
| Active agreement | A distinct solid agreement object on the central table with **Active agreement vN** | Exact agreed wording, current validity, applicable participants, permitted action scope | Appearance is derived from canonical current validity, never geometric closeness or enthusiasm |
| Agreement existed but is paused/withdrawn | Retain its object and version, add a pause/withdrawal state, visibly stop the affected permitted-action path | Who changed what, when, the retained history, what remains blocked | History is preserved; previous commitment is not displayed as permission now |
| Participant readiness | A separate small **Ready / Not ready / Not applicable** marker | Round/version applicability and readiness action | Readiness does not fill consent markers |
| Participant choice | Labeled **Agrees vN / No vN / No response / Withdrawn vN / Earlier version** as supported by canonical records | Actual recorded event and version, with current choice actions in simulation | Missing, no, withdrawn, and stale consent remain distinct; never infer a choice |
| Required review check | An evidence/check token with **Missing / Recorded / Failed / Out of date / Unknown**, where supported | What was reviewed, why it matters, evidence source/version, unresolved issue | A supplied simulation flag cannot be represented as independent real-world verification |
| Transition blocked | A marked gate at the relevant next transition plus a readable cause | Complete blockers, affected action, relevant people/evidence, available next actions | The gate is specific to that transition; round closure and agreement commitment have different rules |
| Action allowed | **Available: [specific simulated action]** beside an explicit control | Why it is available and the exact scope of the action | Availability is not automatic execution or a general authority grant |
| Action recorded | A stable result object / event marker linked to its agreement version | What happened, outcome/evidence, time/event identity | Animation completion cannot fabricate an outcome |
| Repair/consequences unresolved | A visible consequence branch with **Response needed** | What remains to be addressed and the supplied simulation response | Repair may change obligations without restoring consent |
| Retired/released | A retained, quieter object labeled **Retired** with history access | Last state and retirement event | Retiring does not erase prior actions, consequences, or history |
| Historical replay | Prominent **Viewing event N — read-only history** with a different frame treatment | State as of the event and **Return to current state** | Replay does not issue commands or replace current live state |
| Unknown/stale/unavailable data | Explicit **State unavailable** or **Last confirmed [time/event]**, with neutral styling | What is missing and retry/recovery path | No affirmative agreement or permission is inferred from a failed refresh |

The current page displays Bea's post-withdrawal participant status as **no** while the ledger identifies a withdrawal. The richer view should read authoritative event/state data to distinguish these only when that data supports the distinction. It must not guess a prior withdrawal from a false boolean.

## Show progress without manufacturing a score

Use a **current phase and prerequisites**, not an overall percentage. Decision work can branch, move backward, pause, or retire; an earlier successful action and a present stop can both be true.

Examples of useful displays, with live denominators:

- **Considering proposal v3.** Two of three current responses recorded; one no response. No active agreement.
- **Ready for round closure.** Four of four active seats ready. Consent is shown separately; round closure is not commitment.
- **Agreement v2 paused.** Two current consents remain; Bea withdrew. One earlier action recorded. One consequence response needed.
- **Response recorded.** No unresolved repair item in this simulation. Agreement remains paused because current consent is missing.

Counts are descriptive, not votes toward a threshold. Do not show “67% agreement” or a near-complete green ring that implies one person's missing consent is a small obstacle to be overcome. State the actual decision rule and actual missing prerequisite. Equally, do not style a participant's refusal as a player failure or assign blame to them.

Where the canonical protocol has an explicit lifecycle, show its exact phases and history. A multi-step visual path can display previously visited phases and the current stop without implying a monotonic completion percentage. Treat **lesson completion** as separate from **agreement validity** and **task outcome**.

## Prioritized implementation features and acceptance criteria

### CV1 — Centerpiece and semantic overview

Make the scene the dominant interaction surface and place the current decision summary directly with it. Acceptance: a clean first view names the scenario, proposal version, current agreement state, blocking cause, and next useful action without opening diagnostics or reading a log. The same essentials remain readable on a narrow phone viewport and in fullscreen. The visualizer is not relegated to an expert drawer.

### CV2 — Interactive process geography

Render the upper/convergence/lower regions with labels and selectable meaning. Acceptance: selecting each meaningful object opens an explanation tied to that exact object. Spatial regions do not assert unsupported protocol transitions. Users can operate the same selections by keyboard and list view. Reset view changes only the camera/selection state that its label promises.

### CV3 — Proposal versus agreement

Present both identities wherever relevant; include the active version in choices and commands. Acceptance: in a fixture with an older agreement and a newer proposal, a verifier can identify which is which without consulting source code. Where the protocol invalidates or replaces an earlier agreement, the display follows that exact rule. No stale consent is colored as current.

### CV4 — Participants with separate readiness and consent

Acceptance: every applicable seat shows readiness independently from consent and exact version. No response, no, withdrawal, and stale response have distinct readable presentations when supported by state. Clicking the participant does not itself submit consent. Changes show immediate readable feedback. The simulation never implies actual identity verification.

### CV5 — Explainable blockers and next actions

Acceptance: a blocked action reveals every applicable reason and links to the relevant object/action; it does not merely disable a button. Reasons for commit, act, and round close are separately derived. All missing prerequisites remain available even if one main next action is emphasized. A participant's refusal is neutrally described, not framed as an error to defeat.

### CV6 — Meaningful multi-dimensional progress

Acceptance: phase, recorded responses, review checks, outcomes, and unresolved consequences are independently inspectable. Round readiness is included only where relevant. Counters have explicit scope/version/denominator and never grant authority. A withdrawal can stop action without erasing a completed prior action. Lesson completion never implies active consent.

### CV7 — Visible causal changes

Acceptance: after each supported action, the scene briefly highlights what changed and gives a concise textual explanation. After repair, only the repaired consequence changes while the consent blocker remains. For new proposals, affected version-dependent elements visibly become stale or reset according to canonical rules. Reduced motion retains the same causal explanation.

### CV8 — Historical replay and comparison

Acceptance: a verifier can select the prior successful action, the withdrawal, and the later blocked action and compare their state. Replay is plainly labeled and cannot issue live commands. Returning to current state recovers the latest authoritative snapshot. History browsing and animation never mutate the decision.

### CV9 — Mathematical and process lenses

Acceptance: Process and Geometry are accessible first-class view controls. Both preserve selection context where meaningful. Current decision state remains available when exploring geometry. Suggestions are clearly labeled as exploratory; adopting one is an explicit versioned proposal action. Camera changes, coordinate exploration, recompute, and transport operations preserve all authority invariants.

### CV10 — Scenario separation and recovery

Acceptance: selected participants, round, proposal, agreement, scene, inspector, and history all belong to the same visibly named simulation. Changing between the three-person and four-person protocols does not transfer state or imply shared signatures. Reset identifies its scenario and treatment of history; it cannot silently delete unrelated work. Unavailable state is represented as unavailable.

## Four independent loops for every feature

Apply all four loops to each accepted feature above and to features added by other specialists. A cross-cutting browser session may supply evidence for several feature rows, but each row needs its own verdict, findings, revision, and re-verification record. The implementer cannot verify their own feature. After the fourth revision, independently verify that revision before marking the feature complete.

| Loop | Independent verification question | Required challenges | Expected revision focus |
|---|---|---|---|
| 1: Readability and first use | Can the reviewer tell what is being decided, what state applies, why, and what to do next using the interface alone? | Initial state, no responses, one response, valid agreement, paused agreement | Labels, visual hierarchy, contextual explanation, interaction discoverability |
| 2: Semantics and counterexamples | Does every visible claim match the canonical event/state? | Ready but not consenting; old consent/new version; high belief/no authority; geometry differs from proposal; withdrawal; repair without renewed consent | Incorrect aggregation, misleading shapes/colors, lost distinctions, wrong next-action derivation |
| 3: Interaction and inclusive presentation | Is the same decision understandable and operable across input and presentation modes? | Keyboard/list selection, narrow viewport, zoom, reduced motion, long names/proposals, dense blockers | Focus, layout, motion, touch targets, text equivalents, overflow |
| 4: Integrated causality and recovery | Does the final composition remain truthful across complete journeys and navigation? | Replay versus current state; switch scenarios; resize; reset; new version; act then withdraw; partial recovery; unavailable state | Cross-feature inconsistencies, stale selection, wrong history context, lost feedback |

A clean verification round does not require an invented code change: retain evidence and record a justified no-change revision decision. A failed round must be revised and independently rechecked. New findings reopen affected feature rows; do not declare completion because four browser sessions happened.

The central acceptance question is concrete: **without reading the raw ledger, can a new visitor point to the exact proposal, the applicable agreement, each person's actual choice, the thing that changed, and the reason another action is allowed or blocked?** The Visualizer is successful when those answers are visible in the scene and remain true under independent verification.
