# Independent reliability verification of the illustrative Visualizer concept

**Artifact inspected:** `/workspace/hopf-decision-stage.html`  
**Reviewer:** reliability specialist, separate from concept author.  
**Verification level:** source inspection and a bounded Node fixture harness executing the original inline script against minimal synthetic DOM elements. This is **not browser rendering verification, live-site integration verification, or proof of normative-model parity**. The reported browser preview security block was respected; no alternate URL, transport, or browser was used. No concept edits were made by this reviewer.

## Result

The concept largely preserves the intended distinctions: separate v2 draft and v1 agreement, withdrawal pauses v1, repair does not restore consent, and retirement does not permit action. It is visibly labelled as a design concept and fictional sample replay. Its handlers only select snapshots or objects and redraw local fixture state; this inspected script has no production command, network, grant, or persistence path.

**One material selection-context defect needs correction before sharing the concept as behaviorally coherent.** Timeline navigation can leave the inspector headed “proposal v2” while its review and consent sections show v1 approvals. Two smaller explanatory inconsistencies should be corrected at the same time.

## CV-01 — Timeline navigation can mix selected proposal v2 with v1 consent and review

**Priority:** P1 for concept correctness.  
**Evidence:** original source at `display()` line 103 and timeline/object handlers at lines 143 and 144; reproduced by the fixture harness.

Sequence:

1. Start on New draft, select Proposal v2.
2. Select the earlier Proposed snapshot.
3. Select New draft again, leaving the proposal object selected.

Observed fixture output:

```text
Inspecting: proposal v2
Title: The orchard route
People: agreement v1
Consent: Maya: yes · Finn: yes · Bea: yes. Applies to v1.
Bounded test / Required authority / Safety: recorded for v1
Description: A new candidate ... no earlier consent carries across.
```

The labels acknowledge v1 but their placement under the selected v2 inspector is inconsistent. This is precisely the version confusion the new design is meant to remove. The same defect occurs when the user first selects a v1 proposal and subsequently moves to a v2 snapshot.

**Cause:** `display()` forces `contextVersion=1` when visiting a v1 snapshot but never rederives it from `selected==='proposal'` when returning to a v2 snapshot. The proposal-click handler updates the context only on a new object click. `isDraft` then incorrectly becomes false while the selected object heading uses current proposal v2.

**Exact bounded fix:** at the start of each `display()`, derive the version from object selection before computing `isDraft`. For this fixture, the minimum coherent correction is:

```js
const s = scenes[current];
if (selected === 'proposal') contextVersion = s.pv;
else if (selected === 'agreement') contextVersion = 1;
else if (s.pv === 1) contextVersion = 1;
const isDraft = contextVersion === 2 && s.pv === 2;
```

Participant selection can retain the most recently selected version intentionally; keep its version explicit. For production, selection should carry a typed object identity rather than a freely mutable context variable.

**Acceptance:** for all seven source snapshots, select the proposal then visit all seven destination snapshots. The selected proposal heading, crew context, response version, and review version must agree after every transition. Current source failed **12 of 49** such version-context cases: all v1-to-v2 snapshot transitions with the proposal selected. The initial direct Proposal v2 selection passed, explaining why a single happy-path click check would miss it.

## CV-02 — Empty agreement position is labelled as an existing agreement v1

**Priority:** P2.  
**Evidence:** the agreement inspector branch at source line 118 unconditionally sets `kind='agreement v1'`; reproduced on Proposed and Review snapshots.

The main object correctly says No active agreement, and the inspector title says No agreement yet, but the eyebrow and selection announcement say “Inspecting agreement v1.” There is no agreement in those snapshots.

**Exact fix:** change the inspector kind to `s.status === 'none' ? 'agreement position · empty' : 'agreement v1'`. Keep proposal v1's review and response information labelled as proposal information; do not imply that an agreement identity has been allocated merely because a proposal exists.

**Acceptance:** select the agreement position in Proposed and Review. Title, eyebrow, scope, announcement, and primary scene all say an agreement does not yet exist. In Agreed and later snapshots, the same object correctly identifies agreement v1.

## CV-03 — “Inspect the repaired consequence” has no corresponding detail

**Priority:** P2 for interaction completeness in this concept.  
**Evidence:** Repaired snapshot at source line 97, history inspector at line 116, and globally assigned next-step text at line 123; reproduced by the fixture harness.

On Repaired, the next-step box says “Inspect the repaired consequence or propose fresh terms.” Clicking What changed only repeats “Repair was recorded; the agreement remains paused.” There is no repair term, consequence, record, or proposal action to inspect in this artifact. It correctly teaches that consent remains withdrawn, but it offers a next step the sample cannot perform.

**Exact fixes — choose one consistent scope:**

- For the present bounded replay, replace the guidance with “Select Bea to inspect the withdrawn response, or select Retired to see the next illustrated state.” Those interactions exist. Rename the box “Explore this example” if all guidance remains observational.
- If illustrating repair details is desired, add explicit fictional consequence and repair text to the Repaired fixture, show them when What changed is selected, and say “Select What changed to inspect the recorded repair. Agreement v1 remains paused.” Any stated repair must be labelled as sample data.

Also review the Agreed snapshot's “The agreed bridge action is available in the simulation.” This concept exposes no action command; the statement may accurately describe its fictional snapshot but reads like an executable affordance under “Available next step.” For this replay use “Select New draft to see a new proposal coexist with this agreement.” Actual action guidance belongs in the implemented product.

**Acceptance:** every guidance statement either names an interaction supported by the concept or clearly describes the hypothetical workshop state, rather than promising a control that does not exist.

## CV-04 — Withdrawal headline can imply earlier completed action is undone

**Priority:** P3 copy refinement.  
**Evidence:** source line 96 says “Bea stops. The action stops.” The same snapshot says withdrawal occurred after a simulated action.

The rest of the copy correctly preserves prior consequences and blocks further action. Make the headline equally precise: **“Bea withdraws. Further action pauses.”** The concept should not imply it can undo a completed action. No domain change is needed.

## Checks that passed at this limited verification level

| Check | Evidence / result |
|---|---|
| Initial agreement selected | Inspector shows active agreement v1; v2 remains separate and uncommitted. |
| Direct selection of Proposal v2 | All three responses unset for v2; all three review items not recorded for v2. |
| Participant in selected v2 context | Bea description and consent refer to unset v2, while scope separately shows v1 paused. |
| Withdrawal fixture | Agreement status paused; Bea response withdrawn; prior consequences retained in text. |
| Repair fixture | Status remains paused; Bea remains withdrawn; copy explicitly says consent is not restored. |
| Retired fixture | Agreement status retired; v2 remains a draft; copy says retired agreement cannot act. |
| Replay authority | Handlers select local fixtures and update DOM/SVG; no authoritative command dispatch exists in the inspected source. |
| Concept attribution | Header says “Design concept · sample replay”; participants and replay are described as fictional; scene description says symbolic. |
| Snapshot scope | Timeline is labelled replay snapshots, so the seven entries need not claim to be a complete event ledger. The omitted action snapshot is a demonstration limit, not proof of lost real history. |
| State source | Scene styling and text read the same fixture `scenes[current]`; no animation completion controls permission. |

## Verification method and boundaries

The synthetic DOM harness loaded the unmodified inline script, supplied basic elements, attributes, child creation and event listener behavior, and invoked the script's actual event handlers. It checked generated text/attributes and the proposed 49-pair version transition matrix. It did not emulate CSS layout, focus behavior, accessibility-tree construction, browser rendering, ResizeObserver timing, touch interactions, browser security policy, or normative workshop state. Findings CV-01 and CV-02 are behavioral source-fixture results, not screenshots.

After fixes, independently rerun the selected-proposal transition matrix plus empty-agreement checks. Confirm all guidance has an actual illustrative destination. A real browser visual and accessibility inspection remains necessary before claiming the concept renders correctly; live integration verification and the implementation prompt's repeated independent loops remain future work.

---

## Independent recheck of the revised eight-snapshot candidate

**Review date:** 2026-09-15  
**Signed technical review:** `/root/reliability_review`, independent reliability specialist  
**Artifact:** `/workspace/hopf-decision-stage.html`  
**Candidate SHA-256:** `2644d9cb061df32ad35d44ceb51184c004800e166642e7cc608e00d1a9e0c022`

**Result: PASS for the bounded source/fixture checks below.** The initial findings remain above as an accurate record of the prior candidate. No new actionable reliability issue was found within this recheck's scope. This result does not extend to browser layout, accessibility behavior, actual production state, or domain-model correctness.

The revised source was reread in full. Its unmodified inline script was executed in the same minimal synthetic DOM method, updated for eight snapshots and the new event inspector. No browser, local HTTP server, alternate preview transport, or production website was involved. No concept changes were made by this reviewer.

| Recheck | Cases / evidence | Result |
|---|---|---|
| Proposal selection across every source/destination snapshot pair | **64 of 64** cases; selected proposal kind, crew version, response context and review version checked; all v2 requirements remain unrecorded and responses unset | Passed; CV-01 resolved |
| History selection independent of preceding interaction | **384 of 384** cases: 8 destination snapshots × 8 source snapshots × 6 previously selected object types; entire generated semantic snapshot compared with the destination's reference history inspector | Passed; deterministic v1 context and separate event details |
| Empty and lifecycle state | **8 of 8** snapshot cases; empty agreement kind, paused/withdrawn state, retirement, matching event identity, and mutually exclusive detail sections checked where applicable | Passed; CV-02 resolved |
| Explicit action identity | Action A1 explicitly uses bridge agreement v1, distinguishes uncommitted orchard v2, and records consequence C1 | Passed |
| Recorded repair versus consent and completion | R1 references C1, records a proposed response, says this is not proof of physical completion, retains Bea's withdrawal, and leaves v1 paused | Passed |
| Reachable illustrative guidance | Source review confirms guidance names actual snapshot/object controls; the box is now “Explore this example” | CV-03 resolved |
| Withdrawal wording | Headline now says “Bea withdraws. Further action pauses.” Earlier action and consequence are retained in the sample event | CV-04 resolved |
| Neutral missing review | `data-recorded` is false for missing review; default marker colour is neutral; positive colour only applies when recorded=true | Source/fixture check passed; visual colour rendering not assessed |
| Fictional scope and authority boundary | Design concept/sample replay labels retained; snapshot and object handlers only update view state; no production command path added | Passed by source inspection |

The 64 proposal-transition cases now produce **zero mismatches**, compared with 12 mismatches among the original 49 seven-snapshot cases. History selection hides review/consent facts and exposes a named fictional event record, so previous proposal selection cannot misleadingly colour the event inspector with another version's approval context.

The added Action snapshot also makes the withdrawal/repair sequence traceable: **E05 / A1 → consequence C1 → E06 withdrawal → E07 / R1 → E08 retirement**. Each remains sample data. In particular, the response at E07 is not asserted to have physically repaired the dragon or restored consent.

This closes the four original concept findings for the identified candidate hash. A subsequent change produces a different candidate and requires a scope-appropriate recheck. The browser preview remains unverified due to the previously reported policy restriction; this signed technical review is not a substitute for visual browser testing or human authorization.
