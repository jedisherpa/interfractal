# Hopf Workshop — the Visualizer as the centerpiece

Focused review and design specification for Paul Cooper · 15 September 2026

## The decision

Make the Visualizer the main working surface of [Hopf Workshop](https://hopf-workshop.vercel.app/): a luminous, interactive **decision stage** that answers what is being considered, what is currently agreed, who has responded, what is needed next, and what changed. Its beauty should come from readable depth, precise geometry, stable people, and meaningful transitions.

The five specialist roles reviewed the live site again: clarity and information architecture; visual design; accessibility and inclusive interaction; functional reliability; and learning and mathematical explanation. Their separate reports accompany this document. This synthesis resolves their overlapping and occasionally differing suggestions into one implementable direction.

This is a focused design and implementation brief. The live site has not been changed. The accompanying interactive concept uses eight illustrative snapshots; it is not a connected simulation or a verified mathematical renderer. The implementation prompt requires four independent verification/revision loops for every feature; those future implementation loops have not been performed by this review.

## What the renewed inspection established

| Evidence | Finding | Design consequence |
|---|---|---|
| Live layout at 1363 × 936 | The canvas displayed at approximately 838 × 233 CSS pixels, with a 900 × 520 backing surface. | Correct projection and surface sizing before visual polish. Verify the actual renderer treatment; changing CSS alone is insufficient. |
| Live initial and post-demo states | The generic loops and funnels do not visibly identify the proposal, agreement version, participants, pause, withdrawal, or repair branch. | Bind the centerpiece to decision state and events. A larger rendering of the same picture will not solve the problem. |
| Live demo and explicit interactions | Withdrawal pauses action; repair can be recorded while consent remains missing; retirement retains the ledger. | Give each of these states an understandable scene treatment and inspectable cause. |
| Live replacement sequence | A new v2 proposal can coexist with an active v1 agreement. An action entry exposed ambiguous version attribution. | Display candidate proposal and applicable agreement separately, including the version actually used by an action. |
| Live geometry operations | Display adjustment, Reframe, Explore, and Carry have different effects; none grants participant consent. | Separate camera, displayed coordinates, explicit exploration, and decision commands. |
| Repository source inspection | `drawProcessMap` and `drawBundleMap` consume geometry/display values, map choice, and camera angle; they do not project consent, agreement, or rehearsal state. | Introduce a shared state-to-view adapter, rather than adding decorative effects around an unchanged drawing. |
| Repository source inspection | The animation frame loop continues under reduced motion; selected fibers are rebuilt per frame; numerical curvature is recalculated during broad UI rendering. | Investigate on-demand rendering and caching with measurements. These are source-level optimization candidates, not measured performance defects. |

Source anchor: `jedisherpa/hopf-workshop`, `workshop.html` blob `55e79d4edd53d758f8764da53af2e97c90e76657`, inspected on 15 September 2026. The deployed commit was not established. Re-resolve source and deployment before implementation; the report does not certify current production parity. The individual reviews distinguish direct observation, reused evidence, and proposed behavior.

## One centerpiece, two lenses, explicit history

**Decision** is the default entrance. It contains the symbolic process scene and the useful state of the selected practice. **Geometry** is the mathematical lens, initially showing **Bundle map**. This resolves the earlier lab-default instruction without demoting the Visualizer: the product starts in Decision, while the exact geometry lab retains its Bundle default. Document this product decision against existing repository instructions.

History is a time context available from the event ribbon in either lens, not another competing state model. Opening history reveals a persistent **Replay · event N of M** label and **Return to current** control. New current events cannot move a selected historical cursor. If a historical decision has no corresponding recorded geometry, show that absence; do not present today's geometry as its historical state.

The three-person parade and four-seat rehearsal share the visual shell but remain separate simulations. Show the selected practice prominently. Map each through a separate adapter where their actual contracts differ. The four-seat model's phase and readiness cannot be invented for the parade merely to fill a uniform layout.

## Art direction and layout

Think of an illuminated workshop instrument: twilight blue, warm gold, clear aqua, a quiet faceted plinth, and a strongly composed toroidal center. The stage should feel crafted and alive when something changes. Its resting state should be calm enough to read.

At a 1440px reference width, use a compact header, approximately 24–32px outer margins, a stage taking roughly two-thirds of the working row, and a 340–380px inspector. Aim for a stage around 480–620px tall where viewport height permits. The centerpiece should occupy most of the first useful desktop screen; diagnostics and duplicate control banks should not push it below the fold.

The scene has five layers:

1. **Possibilities:** a restrained upper canopy holding an exploratory candidate or current proposal, each with a type, short title, and version where applicable.
2. **Agreement:** the largest central form, containing the applicable agreement and explicit current validity. An uncommitted proposal cannot fill this space as though it were agreed.
3. **People and requirements:** stable named participant anchors plus a separate review rail. The people remain present and recognizable through Yes, No, silence, withdrawal, and retirement.
4. **Consequences:** a visible action branch and repair item when the model supplies them. An accepted commitment, recorded action, and known outcome are distinct facts.
5. **Retained history:** a shallow lower shelf and event ribbon. Retired forms settle into inspectable history; people never fall away or disappear because they declined.

Use HTML labels and controls anchored around the scene, so small text is not flattened into canvas pixels. The inspector holds full proposal wording and detail. Selection isolates relevant relations and emphasizes the selected object without moving the whole layout.

| Visual role | Starting direction | Requirement |
|---|---|---|
| Background | Deep blue `#081421`, quiet blue depth | Maintain a useful light appearance if the product supports themes. |
| Main labels | Pale `#F2F7FB`; secondary `#B7C9D7` on dark surfaces | Measure actual composited contrast; never rely on glow. |
| Agreement form | Warm gold, solid or sealed treatment only when justified | Explicit label distinguishes ready, active, paused, and retired. |
| Possibilities | Violet/aqua outlines, open treatment | No implied commitment or geometric certainty. |
| Selection | Aqua outline and connected-label emphasis | Separate from keyboard focus and consent meaning. |
| Fulfilled requirement | Check shape plus readable recorded status | Never use an unsaved checkbox as completed evidence. |
| Pause/attention | Amber marker plus cause | A calm, legitimate state, without shaming a participant. |
| System failure | Separate error treatment and recovery copy | Do not color a person as a system error. |

These are design tokens to refine, not contrast certification. Retain the site's canonical Wizard Joe assets if used; no generated replacement. Joe can orient the learner, but does not speak consent or become the decision engine.

On tablet, stack the inspector before either column becomes cramped. On phones, use a readable state summary, an approximately 300–380px fitted scene, named participants, inspector/action, and wrapping history controls. Reflow content instead of shrinking a desktop screenshot. Primary object targets should be about 44px where practical, with nonoverlapping hit regions. That is a usability target; assess the actual WCAG 2.2 minimum target rule separately. [W3C target size guidance](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html).

## State must be visible and exact

| Fact | Visible treatment | What selection reveals |
|---|---|---|
| Geometric candidate | Ghost/outline in Possibilities, labeled Exploration | Source operation and an explicit supported proposal action |
| Current proposal | Versioned proposal plate | Exact wording, differences, review and responses applying to this version |
| No agreement | Quiet empty agreement slot | What is needed for an explicit commitment |
| Review partially recorded | Individually labeled requirement marks | Missing, recorded, invalid, out-of-date, or unknown only as supported |
| No response | Open marker and words | Actor and exact target version; never inferred Yes |
| Yes | Check and `Yes · vN` | Recorded response and its applicability |
| No | Stable hold marker and `No · vN` | Recorded decision, with no blame treatment |
| Withdrawn | Distinct withdrawn label when event/state evidence supports it | What changed, affected agreement, retained earlier actions |
| Ready | Separate readiness chip in the rehearsal | Round scope; readiness cannot fill a consent mark |
| All prerequisites, no commit | `Ready to commit`, visibly unsealed | Explicit versioned command, not automatic action |
| Active agreement | Solid central agreement and version | Applicable participants, actual scope, specific available action |
| v2 proposal plus v1 agreement | Two objects, both identities visible | Compare current responses and applicable older agreement |
| Recorded action | Persistent event/action marker | Actual executed agreement version, receipt, outcome if known |
| Paused agreement | Immediate pause label and blocked action path | Actual cause and complete action-specific blockers |
| Repair unresolved | Consequence branch with `Response needed` | Consequence, supplied response, current obligations |
| Repair recorded | Consequence item updates; agreement validity remains explicit | What repair changed and what it did not change |
| Retired agreement | Inspectable retained-history object | Last state, retirement event, remaining consequences |
| Round phase / RETURN | Actual phase label plus separate RETURN event | Round identity and outcomes applied once; RETURN is not a phase |
| Replay | Persistent time-context frame and event identity | Recorded before/after state; current mutations unavailable |
| Renderer failure / data failure | Different, explicit treatments | Equivalent 2D view versus last-confirmed/unknown data and recovery |

Progress means evidence of work: named review requirements, responses received and their choices, current round/phase where applicable, actions recorded, and unresolved consequences. It is not a blended completion percentage, consensus score, safety meter, or countdown to agreement. Counts use the actual applicable population. A No can increase the response count while correctly preventing commitment.

The initial inspector should answer **Current decision / What is needed / Available next step**. Selecting a participant, requirement, version, action, or event replaces it with that object's details. A scene click selects; an explicitly labeled command acts. Actor-specific simulation controls identify the actor and proposal version. Selecting Bea must not make the visitor appear to be authenticated as Bea.

## Meaningful motion and faithful geometry

Motion follows accepted events. A response changes one person's marker. An accepted commitment briefly illuminates the agreement. A recorded action leaves one persistent trace. Withdrawal opens the affected relation and changes the state immediately. Repair updates its consequence item. Retirement settles the form into retained history.

Use short transitions, approximately 180–450ms for ordinary state changes and at most a brief 400–700ms event traversal. Never wait for animation completion to display current permissions. A newer withdrawal must cancel an older commitment flourish. Resize, selection, and rerender cannot replay action animations.

Pause motion stops animation while current facts continue updating. Reduced motion preserves all state and functionality. Pause replay stops historical advancement. These controls must not silently do one another's work. The reduced-motion treatment is a product requirement; WCAG's Animation from Interactions criterion is AAA, not an AA requirement. [W3C animation guidance](https://www.w3.org/WAI/WCAG22/Understanding/animation-from-interactions.html).

Geometry gets its own clear visual hierarchy: subdued context, readable selected structure, bright inspected fiber/path, stable labels, and optional precise diagnostics. A base-sphere point and its fiber can be paired by selection when implemented faithfully. Two fibers can be compared without asserting that they are people. Reframe, Explore, and Carry should report **Changed / Kept** from verified operations. Preserve coordinate conventions, projection singularity handling, normalization, and numerical limitations. [Niles Johnson's mathematical visualization material](https://nilesjohnson.net/notes/Hopf-fib-vis.pdf) is a teaching reference, not proof that this site's renderer is correct.

## Reliability, access, and implementation priorities

Build one pure, immutable projection of canonical state. Scene, summary, inspector, accessible object navigator, availability, and history all consume it. Give entities stable identities and version references. Keep commands outside rendering. Preserve Python as normative and JavaScript parity. Do not parse human-readable ledger sentences to reconstruct permission.

Use the existing architecture unless a measured need warrants an isolated renderer change. A polished 2.5D scene can meet the goal. If WebGL is chosen, preserve a designed 2D representation with the same state, selection, and commands; avoid making GPU support a prerequisite. Measure resizing, rendering quality, context loss, and device cost. [MDN WebGL best practices](https://developer.mozilla.org/en-US/docs/Web/API/WebGL_API/WebGL_best_practices) supports adaptive rendering and explicit handling of browser/device constraints.

Keyboard users need the same selectable objects and actions through native controls. Selection, focus, and command execution remain separate. Keep focused controls stable across state updates. Announce meaningful accepted or denied changes once, not every frame. No essential meaning requires color, motion, hover, dragging, or deciphering a torus. Reflow and actual screen-reader checks belong in implementation verification, not assumed conformance.

Build in this order: state projection and identity; correctly sized stage and semantic overview; the complete proposal-to-withdrawal/repair story; object selection and contextual commands; full history and truthful replay; geometry inspection; art, motion, responsive behavior and renderer resilience. Apply the style early enough to evaluate the actual centerpiece, then refine it against the difficult states.

## Review package and acceptance

The five individual reviews contain fuller rationale, observed limitations, and specialty-specific acceptance criteria. The implementation prompt consolidates them into a numbered feature inventory, state fixtures, and evidence requirements. Every feature receives four independent verification/revision loops plus verification of the fourth revision. Shared test runs are allowed only when each feature has its own assertion and evidence.

The concept demonstrates the layout and the distinction between proposal, agreement, participant response, and retained change. It omits production commands, exact mathematical geometry, rehearsal integration, complete replay data, and renderer failure handling. Its JavaScript received syntax checking and independent source review. Local browser preview was blocked by the browser security policy; responsive rendering, actual browser interaction, assistive technology, and contrast were not certified for the concept. The implementation must validate those capabilities on a permitted running preview.
