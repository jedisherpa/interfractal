# Hopf Workshop Visualizer — implementation and independent verification prompt

Prepared for Paul Cooper · 15 September 2026

Copy this entire document into the coding environment for `jedisherpa/hopf-workshop`. Attach `HOPF_VISUALIZER_DESIGN_REVIEW.md` and the five focused specialist reviews. This prompt contains the core requirements if attachments are unavailable; record missing evidence and inspect the current application.

## 1. Execute this outcome

Make the Visualizer the centerpiece of https://hopf-workshop.vercel.app/: visually striking, simple to understand, directly useful, and reliable. It must make the decision-making process, actual progress, current state, and causal history visible. Build a large interactive decision stage with readable proposals, agreements, people, requirements, actions, consequences, and retained history. Keep exact Hopf geometry as a first-class lens within the same centerpiece.

Implement the features, independently verify them, revise from that verification, independently verify again, and continue for **at least four full loops per feature**. Independently verify the fourth revision too. Do not stop at another design plan or a beautiful screenshot. Do not claim that four reviews of the whole site satisfy four loops for each feature.

Scope is the Visualizer and the minimal layout, state adapters, controls, event data, tests, and explanations needed to make it work. Replace duplicate competing controls with a shared interaction surface where safe; preserve every existing supported command's access. Do not redesign unrelated pages, build production multiplayer/authentication, expand other repositories, or migrate frameworks for appearance alone. Finish a reviewable implementation and evidence package. Apply existing session authorization for remote actions; this prompt alone does not authorize production promotion or merging.

The latest user direction makes the Visualizer central. Earlier recommendations that relegated it to an optional detail drawer are superseded. Default entrance: **Decision**. Default inside **Geometry**: **Bundle map**. Reconcile this explicitly with current repository instructions and document the decision.

## 2. Team, baseline, and independence

Use the same five specialist perspectives: clarity and information architecture; visual design; accessibility and inclusive interaction; reliability and state correctness; learning and mathematical explanation. Use actual separate agents or reviewers for independent verification. These are agent responsibilities, not claims of human credentials or user research.

Assign a builder/integrator and verifiers with clear feature ownership. A person/agent who writes a feature or its repair cannot accept that same change as its independent verifier. A verifier may explain a defect, but if they supply implementation code, use another verifier for that patch. At least two independent verifier identities must participate across each feature's four loops. Preserve the five specialty perspectives across the full inventory.

Use bounded branches/worktrees or sequential editing to avoid competing changes. Freeze each candidate under review and record its commit or immutable content hash. Give verifiers acceptance criteria, canonical rules, scenario fixtures, and candidate identity first; let them inspect the running task before reading the builder's success narrative. They must be able to issue FAIL. The builder cannot rewrite a verifier's result.

Confirm repository remote, branch, dirty state, commit, and deployed source mapping. Preserve unrelated changes. Read applicable `AGENTS.md`, relevant skills, `README.md`, `INTEGRATION.md`, `docs/DISCIPLINE.md`, `VERIFICATION.md`, visual assets/provenance, model contracts, and tests. Inspect `workshop.html`, `hopf_model.py`, `hopf.js`, `weopoly_hopf.py`, `weopoly_hopf.js`, learning-packet modules, fixtures, and existing UI tests. Confirm actual package scripts and dependencies before running them. Do not assume React, Next.js, or a new database is needed.

Review evidence anchor: `workshop.html` blob `55e79d4edd53d758f8764da53af2e97c90e76657`. Earlier repository main was observed at `cf8326aa497c490dd074db2c98c2224a6175435f`; deployment equivalence was not established. These are historical inspection anchors, not a checkout instruction or guarantee about current source.

Reproduce relevant findings: distorted display/backing proportions; geometry not representing decision changes; ambiguous action-version attribution when a v2 draft coexists with v1 agreement; unsaved review input versus recorded review; DOM replacement losing focus; limited visible event history; and persistent frame work under reduced motion. Mark each reproduced, resolved, not reproduced with steps, or outside the bounded task with justification. Do not turn a source-level performance suspicion into a claimed benchmark.

If independent execution contexts or permitted browser preview are unavailable, complete useful code and permitted checks, record the exact blocked capability, and do not claim independent/browser completion. Do not work around security policy. This limitation is a reportable gate, not permission to substitute self-review for independence.

## 3. Preserve the product's actual rules

1. Python is normative; HTML/JavaScript display remains faithful to it. A new renderer is not a new permission engine. Topology does not authorize.
2. Candidate geometry, proposal, exact-version response, recorded review, agreement, action, outcome, consequences, readiness, and phase are separate concepts.
3. Camera/display changes, selection, hover, dragging, animation, replay, confidence, or lesson progress cannot grant consent, commit, or execute. Explore is an explicit existing operation with its actual defined scope.
4. New proposal v2 does not silently inherit v1 responses or reviews. Where the normative model preserves active agreement v1, show it alongside v2. Executed actions reference the actual applicable agreement and wording, regardless of the current draft.
5. No response, No, withdrawal, and earlier-version response remain distinguishable when source records support them. Do not infer withdrawal from a false boolean alone. People remain present and equal in visual prominence.
6. All prerequisites satisfied is not commitment. A valid explicit command creates an agreement. A commitment is not an executed action; an action record is not a verified successful outcome.
7. Withdrawal and repair follow the model. Recording repair does not itself restore consent. Retirement preserves history and cannot revive by replay, reload, camera change, or dragging an archived object.
8. Parade and rehearsal remain separate simulations with explicit scope. Readiness is not consent. PLAY, COORDINATE, and ACT are phases; RETURN is a separate command that applies supported pending outcomes once and preserves history.
9. This is practice with simulated seats. Actor commands identify their simulated actor; selecting a person does not authenticate the visitor as that person. Humans attest; agents do not ratify.
10. Preserve canonical Wizard Joe assets and provenance if used. No generated lookalike. Joe can teach; Joe cannot supply consent or authority. Keep any existing learning-packet contract, `simulated=true`, and surrounding integration seams compatible.
11. Symbolic cones and the decision torus are a process vocabulary, not the exact mathematical chart construction. Participants are not literal Hopf fibers. Numerical approximations are not proofs or ethical scores.
12. Preserve the model's actual display/protocol equivalence: the inspected code compares Hopf projections with tolerance. Do not replace this with an incorrectly stricter claim that all complex coordinates or common phases must be identical.

Represent these rules in the interaction and concise contextual copy. Do not crowd the stage with a wall of implementation caveats.

## 4. Design the centerpiece

Use an illuminated workshop instrument: deep blue spatial background, warm luminous agreement form, restrained aqua/violet possibilities, stable named people, opaque readable annotation surfaces, and a shallow retained-history shelf. Keep a calm fitted camera at rest. Avoid constant orbiting, particle fog, excessive bloom, or equal emphasis on every line. Beauty must survive reduced motion and a 2D renderer.

At 1440px, target a compact header, 24–32px margins, a 340–380px inspector, and a stage taking the remaining roughly two-thirds of the work row. A 480–620px stage height is a starting composition, adapted to available height and content. The Visualizer should dominate the first useful screen. Keep essential state and next action visible before advanced diagnostics.

Scene geography:

- Upper **Possibilities**: distinguish exploratory suggestion from the current versioned proposal.
- Central **Agreement**: largest form, exact agreement identity and validity, empty/unsealed when no agreement exists.
- Stable **People** anchors: all applicable actors by name for the current 3–4 seat cases. Readiness, response, and version are separate fields.
- **Requirements and consequences**: a distinct review rail, action-specific blocker, recorded action trace, and repair branch where applicable.
- Lower **Retained history**: selectable records and event navigation. Archive forms, not people.

Use HTML for essential labels, selection targets, summaries, and actions. Keep full wording in the inspector. Use approximate 15–16px ordinary controls and readable secondary text. Refine candidate dark tokens such as background `#081421`, panel `#132636`, text `#F2F7FB`, secondary `#B7C9D7`, gold `#FFD27A`, aqua `#76E0EB`, fulfilled `#8BE0BC`, attention `#FFCA80`. Measure final contrast and supply theme behavior consistent with the product. State is never color alone.

The default inspector answers: **What is being decided? What is currently agreed? What is needed? What can happen next?** Object selection opens exact versioned detail without mutating domain state. Offer one visually primary contextual command where appropriate, with other supported commands available nearby. Show reasons next to blocked commands; a disabled control's explanation must also be reachable without hover.

Use Decision and Geometry as distinct lenses. History is an explicit read-only time context reachable from both. Keep scope and typed selection stable where meaningful. A person has no automatic mathematical counterpart; retain their context without relabeling them as a fiber.

On narrow screens, stack the inspector; fit rather than squash the scene; keep long text readable; preserve normal page scroll. Use an inline inspector by default, avoiding modal focus complexity unless it materially helps. No essential action requires hover, dragging, or precisely hitting a hidden 3D object. Include an equivalent object navigator and useful designed 2D view.

## 5. State architecture and event contracts

Create a narrow pure adapter from canonical snapshots to a shared view model. Reuse existing contracts. Suggested concepts, adapted to actual source types:

```ts
type VisualizerView = {
  scopeId: string;
  sourceRevision: string | number;
  snapshotId: string;
  timeContext: { kind: "current" } | { kind: "history"; eventId: string };
  proposal: VersionedProposal | null;
  agreement: VersionedAgreement | null;
  participants: ParticipantFacts[];
  recordedReviews: ReviewFact[];
  actionAvailability: ActionEligibility[];
  round: RoundFacts | null;
  outcomes: OutcomeFact[];
  consequences: ConsequenceFact[];
  events: EventFact[];
  dataHealth: DataHealth;
};
```

Represent unavailable values explicitly instead of filling missing facts with optimistic defaults. Keep current state, history cursor, selected entity, lens, camera, and motion preference as separate concerns. Selection uses typed stable identity, scope, and applicable version—not row index, screen position, or a mutable label. Recompute version context when moving between historical snapshots; selecting proposal v2 must never show v1 approvals after visiting a v1 event.

All scene markings, DOM state, summaries, announcements, and commands' displayed eligibility consume the same accepted revision. Query canonical guards or a verified read-only adapter; do not duplicate authorization logic in CSS or renderer conditionals. Actual command execution revalidates the target and current state even if its button previously appeared available.

Keep command dispatch outside render/animation/history code. Accepted or denied receipts update the UI promptly. Animate the actual recorded result: a denial can update blocker feedback and canonical blocked/denied history, but cannot fabricate an accepted action/outcome or advance the workflow as though the command succeeded. Pending operations, if any, cannot target a new scope after the user switches practices. Cancel stale visual callbacks; a delayed commit animation cannot overwrite a later pause.

Use structured event identity, sequence, kind, scope, participant, proposal version, actual agreement/version, round, and outcome identity wherever relevant. Extend event contracts narrowly if necessary, with normative/parity coverage. Never infer authoritative state by parsing a ledger sentence. Timestamps are not unique event identities. Deduplicate by real identity, including outcomes applied at RETURN.

History uses stored snapshots or tested read-only reconstruction. It never re-executes commands. If legacy events cannot reconstruct a field, disclose unavailable history for that field; do not fabricate a complete replay. New sessions should record sufficient data. Full available history must remain accessible beyond a short recent-events window, with explicit retention limits if any. Reload behavior must be truthful: do not claim saved/resumable history unless persistence exists and is verified.

Renderer failure preserves canonical state and DOM interaction. Data failure is separate: show last-confirmed or unknown facts with their revision/context. A local idle practice is not stale merely because time elapsed. Do not add artificial network/loading architecture to a synchronous local simulation; test asynchronous failure cases only if such an adapter is actually introduced.

## 6. Feature inventory and acceptance contracts

Create `visualizer-feature-inventory.md`. The following is the minimum inventory. Number acceptance criteria within every row. Split independently implemented behaviors into child features as needed; each child gets four loops. Map every detailed finding and feature contract in the five focused reviews to criteria/disposition. Shared fixes may resolve multiple findings but cannot erase their traceability.

| ID | Feature | Acceptance contract |
|---|---|---|
| VZ01 | Centerpiece layout | Decision stage dominates the useful first screen; status, relevant version, and next action remain legible; unrelated site functions remain reachable. |
| VZ02 | Scope and lens controls | Decision default, Geometry/Bundle default, explicit practice identity, correct control semantics; scope switching cannot transfer actors, outcomes, or permission. |
| VZ03 | Canonical view projection | Scene, inspector, object navigator, summaries, and eligibility agree on scope/revision; incomplete source data stays explicitly incomplete. |
| VZ04 | Candidate and proposal | Candidate and recorded proposal have distinct types; exact text/version visible; promoting a suggestion requires a supported explicit command. |
| VZ05 | Proposal/agreement coexistence and comparison | Active v1 plus proposed v2 visible together; compare wording/reviews/responses; replay and selection cannot display v1 approvals as v2 consent. |
| VZ06 | Participant identity and responses | Every applicable person stays named and stable; Yes, No, unset, withdrawal, and earlier-version evidence distinguishable; each actor's control names actor/version. |
| VZ07 | Readiness and round state | Rehearsal shows actual phase/round and separate readiness; Ready never means Yes; parade does not receive invented phase data. |
| VZ08 | Recorded review requirements | Each required review has version and recorded state; toggled draft inputs cannot display as accepted review; source/version invalidation follows model. |
| VZ09 | Blockers and meaningful progress | Complete action-specific reasons and next options; dynamic applicable denominators; no blended agreement/safety/completion score. |
| VZ10 | Explicit contextual commands | All existing commands remain reachable in their proper scope; selection cannot execute; accepted, pending if applicable, and denied results are truthful; current guards revalidate. |
| VZ11 | Commitment display | All-ready but uncommitted is distinct from active; explicit accepted commit determines agreement; no premature action trace or success animation. |
| VZ12 | Action/outcome attribution | Action names actual agreement/version and wording even with a newer draft; recorded action and known outcome remain distinct; no fabricated success. |
| VZ13 | Withdrawal and pause | Correct actor/version and immediate resulting state; blocked action and retained earlier activity visible; interrupted animation cannot restore active appearance. |
| VZ14 | Consequences and repair | Consequence has source action and response state; repair updates only its contracted facts; missing consent and current agreement validity stay explicit. |
| VZ15 | Retirement and retained learning | Retired form remains inspectable; prior action/consequences remain; replay/reload cannot revive authorization. |
| VZ16 | Round closure, ACT and RETURN | Actual command/phase distinctions shown; close round is not commitment; outcomes remain attributed and apply once at RETURN; invalid order explains denial. |
| VZ17 | Typed selection and inspector | Pointer and object navigator select identical entity/scope/version; selecting history then switching snapshots preserves truthful context; complete text and applicable actions available. |
| VZ18 | Structured event history | Every supported event type retained and ordered; executed agreement version explicit; old records accessible; no timestamp-only identity or duplicate receipt. |
| VZ19 | Replay and before/after | History is unmistakable and read-only; before/after shows recorded changes; new current events do not shift history; Return to current uses latest accepted state. |
| VZ20 | Semantic motion | Accepted events animate once; no animation-driven authority; pause motion and reduced motion preserve current facts; late effects cannot override a newer snapshot. |
| VZ21 | Exact geometry and object inspection | Bundle drawing keeps correct mathematical meaning/proportions; selected point/fiber/path labels and numerical diagnostics accurate; no participant/fiber equivalence. |
| VZ22 | Camera and coordinate controls | Camera, display coordinates, and protocol exploration clearly separated; fit/reset/non-drag controls work; theta/phi/gamma endpoints and resize preserve model invariants. |
| VZ23 | Explore, Reframe, Carry and diagnostics | Each existing operation works with correct units/conventions and Changed/Kept explanation; linking/curvature/holonomy stay numerical checks, never permission scores. |
| VZ24 | Accessibility, focus and announcements | All objects/actions keyboard operable; focus survives updates; selection distinct from focus; accepted/blocked states announced once; actual screen-reader and contrast evidence recorded. |
| VZ25 | Responsive stage and touch | Actual 320, 390, 768, 1024, 1440px layouts, zoom, long content, and coarse targets remain usable; no squashing, clipped essential labels, or trapped page scroll. |
| VZ26 | Rendering quality and resilience | Designed 2D equivalent preserves state and actions if enhanced rendering fails; adaptive workload, visibility and reduced motion checked; data failure is distinct from graphics failure. |
| VZ27 | Integrated teaching and regression | Newcomer can explain decision/version/people/blocker/next action from the interface; complete parade, rehearsal and geometry stories remain correct in the assembled candidate. |

VZ21's added base-point/fiber inspection is a bounded educational enhancement, not permission to invent unverified mathematics. If implementing it requires additional subfeatures, register and verify them. Existing theta, phi, gamma, linking, Explore, Reframe, Carry, and each model command retain individual criteria even where grouped above. Do not count a broad feature title as complete while one underlying control remains untested.

## 7. Required state and challenge matrix

Build deterministic fixtures from the normative model. Record expected identities, revisions, and guards independently of the UI implementation. Use fictional data. For each applicable feature exercise the following, plus any defect-specific cases:

| Fixture | Required observation |
|---|---|
| Initial proposal | No agreement, unset responses, actual missing review; useful initial scene without animation. |
| Draft review flags toggled, not recorded | No completed-review indication or false commitment availability. |
| Partial review; partial responses; one No | Distinct facts, accurate blockers, calm stable participant identity. |
| All Ready, no Yes | Rehearsal readiness can be complete while consent remains absent. |
| All prerequisites, before Commit | No active agreement until explicit accepted commitment. |
| v1 committed, v2 proposed | Both identities visible; v2 lacks inherited consent; allowed v1 action correctly attributed. |
| Select proposal v2, visit a v1 historical snapshot, return to v2 | Proposal inspector and people/review details all use v2 context; old approvals stay v1. |
| Same-version safety/review invalidation | Canonical agreement validity and command guards determine display; new draft review cannot corrupt older applicable stamps. |
| Action recorded, then withdrawal | Earlier action remains; actual actor's withdrawal and blocked future action visible. |
| Withdrawal arrives during a commit effect | Latest paused state wins in labels, scene, announcements, and controls. |
| Repair response recorded | Consequences update; consent does not automatically return. |
| Retired agreement with prior activity | History remains; action denied; replay/reload does not revive it. |
| Rehearsal full round and repeated RETURN attempt | Correct phases and command order; each outcome applied once; history retained. |
| History longer than the visible ribbon | All retained records accessible, stable ordering, no omission hidden by UI window. |
| Current event arrives during paused replay, if supported | Historical cursor remains fixed; current-update indicator available; no historical mutation. |
| Denied command, rapid repeated input, scope switch | No fabricated receipt/advance, wrong-scope effect, duplicate outcome, or lost focus. |
| Geometry change, Reframe, Carry, resize and lens switch | Exact contracted geometric change; proposal/consent/authority unaffected except explicit allowed operation effects. |
| Reduced motion, graphics failure, long content | Equivalent state and controls remain usable; graphics failure does not masquerade as missing domain state. |

Test each affected actor and each scope, not only the first participant. Use actual source-supported states; mark genuinely inapplicable cases with a reason. Add tests for positive and negative paths. Do not turn a correct denial into a success to make the scene look smoother.

## 8. Four independent loops for every feature

Maintain `visualizer-verification-ledger` in machine-readable JSON/CSV plus a concise Markdown report. Each feature starts with a candidate implementation and numbered criteria. Apply this cycle four times:

```text
Candidate C0
  -> independent verification I1 -> revision R1 -> independent recheck K1
  -> independent verification I2 -> revision R2 -> independent recheck K2
  -> independent verification I3 -> revision R3 -> independent recheck K3
  -> independent verification I4 -> revision R4 -> independent recheck K4
  -> independent final integration audit of the assembled candidate
```

The next loop's verification may share a run with the previous revision's recheck only if both obligations have explicit criteria, candidate identity, and distinct recorded results. K4 is mandatory after R4; four initial reviews without checking the last repairs are incomplete. Four is a minimum. Unresolved material findings require further revisions and checks.

| Loop | Independent focus | Required revision work |
|---|---|---|
| 1 — Meaning and primary behavior | Run the feature's normal user task. Identify proposal/agreement/version, people, current state, blocker and next action. Compare scene and DOM with the model. | Fix misleading hierarchy/copy, missing interaction, wrong identity, and primary behavior defects. Recheck affected criteria. |
| 2 — Difficult state and causal truth | Challenge invalid orders, No, unset, withdrawal, replacement, repair, retirement, duplicates and scope boundaries as applicable. | Fix incorrect mappings, stale state, wrong-version evidence, guard divergence, event attribution and missing consequences. Recheck. |
| 3 — Access and visual resilience | Use keyboard, actual screen reader where available, reduced motion, color-independent interpretation, measured contrast, touch/non-drag alternatives, zoom, target widths and rendering fallback. | Fix access, legibility, focus, responsive and failure-mode issues. Record actual browser/device/tool limits. Recheck. |
| 4 — Integrated use and regression | A fresh independent perspective runs the feature inside complete parade/rehearsal/geometry journeys, with repeated input, replay, view switching and performance observation. | Fix all remaining integrated defects and regressions. Independently verify the exact fourth revision. |

Do not manufacture code churn to populate the ledger. A no-change revision is allowed only when the independent finding set has no actionable defect, records why the criteria passed, and receives the required recheck. A skipped feature is not a no-change revision. A screenshot can support visual evidence but cannot substitute for using a control or checking state.

Each record includes: feature and criterion IDs; loop and check stage; candidate commit/hash; builder and verifier identity; test environment and viewport; exact setup/steps; expected and observed result; source/model evidence; screenshot/recording or log reference where useful; PASS/FAIL/BLOCKED; finding severity; revision commit/hash; and independent recheck result. Retain failed records. Include feature-specific assertions when one run covers multiple features.

Define completion mechanically: every required feature/criterion mapped; I1–I4 and R1–R4 present; all revisions independently rechecked, including K4; at least two independent verifier identities per feature; no unresolved material failures or blocked required gates; final audit on the actual integrated candidate. Later changes invalidate affected accepted criteria and require new checks. Do not reuse evidence from an older build when a changed dependency could affect it.

## 9. Evidence and engineering gates

Use the repository's actual model, parity, numerical, rehearsal, learning-packet and UI gates as applicable. Run them on the candidate and inspect coverage rather than copying historical passed counts. Add focused regression tests where a concrete state/identity defect warrants them. Browser tests prove interaction and rendering; model/parity tests prove contractual behavior. Neither replaces the other.

Before optimization, record a baseline and after-change evidence in the same conditions: initial useful render, frame/work behavior during idle and interaction, representative event bursts, resize, hidden/visible transitions, reduced motion and renderer failure. Record browser/device/viewport and the method. Choose explicit budgets before judging results. Stop unnecessary idle animation work; cache stable geometry/diagnostics and invalidate only when their inputs change; use time-based animation and bounded quality. Do not advertise a universal frame-rate guarantee from one desktop measurement. If WebGL is used, include context-loss recovery, device pixel ratio/resize behavior and 2D equivalence.

Use W3C WCAG 2.2 AA as the accessibility baseline with explicit product requirements for reduced motion and roughly 44px primary touch targets. Do not mislabel the AAA Animation from Interactions criterion as AA or the 44px target as the universal AA minimum. Test applicable contrast, focus, reflow, target spacing, keyboard, drag alternatives and status announcements on the rendered interface. An automated scan is useful but not proof of complete conformance. Expert comprehension review is not a fabricated novice study.

Preserve exact geometry computations and mathematical tests. Verify normalization, Hopf projection invariance where claimed, projection singularities, periodic/end-point controls, linking sign conventions/approximation, curvature/Chern expectations, and Carry/holonomy units with the repository's actual definitions. An independent mathematical verifier must derive representative expected values/invariants from the declared definitions and conventions, not merely repeat the current renderer's output or trust existing tests. Reconcile disagreements explicitly. Numerical diagnostics cannot become a safety score. A symbolic torus is not a substitute for the verified geometry view.

## 10. Deliver and stop at a truthful result

Deliver the reviewable code/diff, feature inventory and finding map, state adapter/event schema notes, required fixtures/regression tests, before/after screenshots from permitted previews, performance/accessibility evidence, complete four-loop ledger, final independent integration report, and any exact remaining limitations. Include a brief explanation of why the centerpiece is easier to use and what changed functionally.

Do not report production deployment unless it was authorized and actually completed. Do not report four loops complete if independent evidence is absent or a required gate remains blocked. Do not mark a concept, mock fixture, or static screenshot as integrated functionality. Once all authorized work and gates are complete, provide the reviewable result and any concrete final approval step that is truly required.
