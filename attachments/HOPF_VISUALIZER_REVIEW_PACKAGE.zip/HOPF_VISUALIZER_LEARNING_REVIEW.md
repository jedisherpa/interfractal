# Visualizer centerpiece — learning and mathematical explanation review

Reviewer: independent learning and mathematical explanation specialist, continuing the same role as the original five-specialist review. Review date: September 15, 2026. Scope: only the Visualizer and the surrounding controls needed to make it a useful centerpiece. This is a design review and implementation specification, not a completed implementation or a human usability study.

## Main recommendation

Make the Visualizer the place where someone can **see what the group is considering, what they have actually agreed to, what is preventing the next action, and what happened earlier**. A newcomer should be able to point at an object and ask “What is this?” or “Why is this paused?” without first learning the names of the mathematical machinery.

The scene should be beautiful enough to invite exploration and precise enough to trust. Its beauty should come from clear spatial relationships, material depth, selective illumination, useful motion, and responsive selection. The learning experience should come from changing one thing and immediately seeing both its effect and its limits.

Use three named views of one selected activity: **Decision**, **Geometry**, and **History**. The default centerpiece is Decision. When a person deliberately enters Geometry, default that view to the Bundle map. This reconciles the earlier mathematical-lab recommendation with Paul's new instruction: the centerpiece now serves the decision process, while the mathematical view still opens with the mathematical subject. Do not make a newcomer complete a geometry lesson before they can understand the decision.

## Evidence from this new inspection

I reopened the public deployment in my own tab, `learningVizTab` / tab `13`, at [the Hopf Workshop](https://hopf-workshop.vercel.app/). I inspected the initial rendered state, selected Bundle map, inspected its screenshot and accessible surface, reframed by π/2, ran the cardboard-dragon demo, resolved repair, and retired the arrangement. All changes were the site's displayed teaching simulation. I did not inspect the source model or make production changes.

| Observed today | Consequence for the proposed centerpiece |
|---|---|
| The geometric drawing follows a large four-seat practice section and sits next to a separate Parade table. | The scene currently does not own the task's attention or clearly declare which process it represents. Move the selected activity into the centerpiece and keep its identity visible. |
| In the inspected viewport the canvas measured 838 × 233 CSS pixels. It exposed `role="img"` and no `tabindex`. The Bundle drawing used very thin curves and tiny embedded labels against near-black. | A large nominal width does not make a readable, explorable learning space. Give the stage usable height, legible external labels, and accessible object selection. No accessible scene-object controls were exposed in the inspected surface; I did not test undocumented pointer hit targets. |
| Clicking Bundle map selected that view; its caption described two solid tori and the Clifford torus. | Preserve a genuine mathematical view, but introduce the objects through selection and explanation rather than a dense caption alone. |
| Reframe added “Changed common phase; proposal and permission unchanged” to the Parade ledger. | This is an excellent invariant to teach in the scene itself: visibly show the changed geometric quantity alongside the unchanged proposal and permissions. |
| The demo created orchard proposal v2, recorded review and three consents, committed it, performed a simulated action, then paused after Bea withdrew. Geometry still displayed the suggestion “Bridge route.” | This is a real distinction between a geometric suggestion and a proposal, not necessarily an implementation defect. A centerpiece must label and compare them explicitly so the viewer cannot mistake a suggestion for the current agreement. |
| After withdrawal, the Parade state was PAUSED with missing current consent and unresolved consequences. | Make the reason for pausing selectable and visible at the agreement object. The prior action remains part of the story. |
| Resolve repair removed only the consequences blocker. Bea still showed no and the agreement stayed PAUSED. | The scene must demonstrate that addressing prior consequences does not restore consent. |
| Release / retire produced RETIRED, preserved the ledger, and stated that a retired agreement cannot be revived in place. | Release should create an inspectable historical object, not make the arrangement disappear. |

These observations do not certify the formulas, the normative transition rules, multiuser security, persistence, or a complete accessibility implementation. The implementation team must inspect the canonical model before assigning precise state meanings to the visual vocabulary.

## A centerpiece that explains itself

The first screen should show a spacious central scene with a compact factual header: the activity, the current proposal/version, and the current agreement state. Nearby, put a short answer to “What needs attention?” and a relevant action. The scene should be dominant; the supporting text should make it usable.

For the observed withdrawal state, a useful scene caption is:

> Orchard route · agreement v2 · Paused. Bea withdrew. Earlier action remains recorded. Two things need attention: current consent and the response to earlier consequences.

After repair, the same scene changes to:

> Response to earlier consequences recorded. Agreement v2 is still paused because Bea has not given current consent.

This gives meaning to a visual change without repeatedly covering the stage in warnings. A small persistent label can say “Teaching simulation.” Decision can carry a compact “Process metaphor” badge. Geometry can carry its exact representation label. Put the fuller mathematical and protocol explanations in the selection inspector and “How this works.”

The main explanatory loop is **select → understand → act when appropriate → see what changed**. Selection is inspection. Panning is inspection. Rotating is inspection. Changing views is inspection. None is consent, agreement, execution, or release.

## Spatial vocabulary: upper cone, torus table, and lower release

Keep the recognizable hourglass composition as a process metaphor in Decision. Give each zone a consistent operational meaning while keeping the protocol's real sequencing explicit.

| Scene region | Proposed visual meaning | What selection reveals | Boundary that must hold |
|---|---|---|---|
| Upper cone / Ideas | Candidate routes and proposed changes, including a clearly distinguished geometry-derived suggestion. A selected candidate has an outline or suspended token. | Candidate origin, description, changed assumptions, whether it has become a versioned proposal, and the allowed next action. | Position or movement toward the center does not establish consent, readiness, review, or authority. Ideas can coexist with an active agreement. |
| Central torus / Agreement table | The named proposal under review and, separately when present, the last committed agreement with its actual state. Participants and review requirements are attached as readable symbolic markers. | Proposal/version, participant decisions for that version, review conditions, exact blockers, and the last committed agreement's status. | The glowing torus is a symbolic process surface. It is not mathematical proof of agreement. Completeness of an animation cannot grant authority or execute an action. |
| Action trace adjacent to the table | Recorded actions and outcomes for the specific agreement version. Use a visible branch or trail rather than treating “committed” and “acted” as identical. | Action record, version, outcome and source, timing/order, and unresolved consequences when present. | A commit is not execution. An action is not a verified successful outcome. Display only the distinctions the source data establishes. |
| Lower cone / Release and learning | A retired arrangement and the retained records of its consequences, repair, and learning. Use settling, archival outlines, and a retained event trail. | Why it ended, what remains unresolved, what was learned, and any permitted new proposal path. | Retiring an arrangement does not erase obligations, restore consent, reverse earlier actions, or rewind history. |

Do not map this onto a mandatory one-way funnel. A new idea can appear while another agreement is active. An agreement can pause without being released. Repair may be needed before or after release according to the actual model. A reviewer may reject a candidate without moving it into an active agreement. The scene should follow events and state, not compel them into an attractive but false lifecycle.

If the four-seat round model is selected, show its own PLAY / ACT / RETURN structure and readiness separately from consent. Do not borrow Parade rules just because the same scene can draw both activities. Closing a round, committing an agreement, and beginning ACT require their own model-backed meanings. The scene needs an adapter per activity, not a merged fictional protocol.

## Candidate, proposal, and agreement must be separately selectable

Today's “Bridge route” suggestion alongside an orchard agreement exposes the most valuable redesign opportunity. Show three explicitly typed objects:

1. **Candidate:** Bridge route — generated from the current geometric exploration. No proposal status is implied.
2. **Current proposal:** Orchard route — v2, with exact current-version review and participant choices.
3. **Last committed agreement:** Orchard route — v2, currently paused after withdrawal. Earlier action retained.

Where no agreement exists, show an empty agreement slot labeled “No agreement yet.” Where the current proposal is also the committed version, show that relationship without duplicating conflicting status. When a new proposal exists alongside an older agreement, show both identities and whatever validity the normative model actually assigns. Do not presume whether the prior agreement continues: derive that from the model.

Offer Compare from either object. The comparison should include changed content, version identity, review requirements, participant decisions that apply to each version, and consequences for allowed actions. Use a split inspector or layered outline in the scene; do not blend the two versions into an average.

A learner should be able to answer, “Which plan did Bea agree to?” and “Would that agreement apply to this edited plan?” through selection. This is more important than showing a sophisticated score.

## Decision, Geometry, and History: shared context, explicit meaning

| View | Primary question | What persists | What changes only through an explicit action |
|---|---|---|---|
| Decision | What are we deciding, what state are we in, and what can happen next? | Activity identity, selected entity/version, actual protocol state, geometry exploration state. | Proposal, review, consent, agreement, execution, repair, and release, through their own supported controls. |
| Geometry | What is the mathematical relationship, and what changes when I explore it? | Activity identity and associated selection when a genuine mapping exists; protocol state stays visible in a compact context strip. | Mathematical exploration state through labelled geometry controls. Promoting a suggestion to a proposal remains a separate command. |
| History | How did this arrangement reach its present state? | Selected activity and entity identity. Live state remains clearly distinguished from the inspected past state. | Scrubbing changes the inspected snapshot, not the current process. Return to current restores the present-time view. |

Shared selection must be typed. Selecting Bea in Decision cannot silently turn Bea into a Hopf fiber in Geometry. If an entity has no mathematical counterpart, retain its context in the inspector and say so briefly; allow a separate geometric selection. A fiber is a mathematical object, not a real participant. Any symbolic correspondence belongs to the application and must be labelled as such.

History should show the state *at* a selected event as well as the event's effect. At minimum support the original proposal, replacement, review, consent, commit, action, withdrawal, repair, and release events available in the current simulation. A before/after toggle should reveal the exact changed fields without requiring a reader to parse the raw ledger. Where earlier snapshots are reconstructed, verify the reconstruction against the model and identify missing evidence instead of inventing state.

## Direct manipulation that teaches the geometry

The mathematical core is a circle fiber over a point on a base sphere, presented through an appropriate visualization of the total space. Niles Johnson's mathematical visualization material explicitly links points to fibers, latitude circles to tori, and disks to solid tori, and distinguishes stereographic representation from the underlying spaces. That is a useful primary teaching reference for the Geometry view; it is not evidence that this site's renderer is correct. [Niles Johnson, Visualizing the Hopf fibration](https://nilesjohnson.net/notes/Hopf-fib-vis.pdf).

Build three short, optional interactions using the implementation's verified coordinate conventions:

**Select one point; reveal its fiber.** A labelled base-sphere inset shows the selected point. The scene highlights the corresponding fiber while dimming unrelated context. A concise inspector says what the point and fiber represent mathematically. Keyboard selection and an object list provide the same relationship. Do not rely on color alone to pair the objects.

**Select another point; compare the fibers.** Show both points and both fibers with stable labels, line styles, and selection. Offer a purposeful camera preset that makes their relationship inspectable. Avoid continual automatic rotation. If projected curves approach the projection singularity, the display and explanation must handle that case correctly rather than falsely clipping a fiber into a broken object.

**Change one operation; inspect its invariants.** Reframe should show the geometric quantity that changes and the base/proposal/permission state that stays fixed under the verified operation. Carry should show the traversed base path, the lifted state before and after, and the resulting quantity with declared units. Explore should show a temporary candidate distinct from the protocol's recorded coordinates until the explicit Explore operation does whatever the model specifies.

Use a small “Changed / Kept” inspector following each operation. For example: “Changed: common phase. Kept: proposal v2 and permission state.” The actual mathematical fields must come from source verification; do not reuse today's “sliders are camera” phrase until its accuracy is established. Distinguish geometric coordinates from the ordinary scene camera.

Keep numerical measurements subordinate to the selected mathematical question. A user investigating linking sees the two selected fibers, the computation method, expected behavior under the declared orientation convention, and approximation quality. A person deciding whether a group may act should not have to interpret a Chern integral. Preserve advanced formulas, conventions, source links, and numerical diagnostics in the Geometry inspector.

The upper and lower cones are never labelled as the literal two solid tori. The mathematical chart construction needs its own accurate rendering and caption. “Boundary identification” must be explained or illustrated correctly by the mathematical reviewer; making two attractive surfaces touch is not proof of the required gluing.

## Progress should reveal work, not pressure agreement

Do not create a single “alignment” percentage that mixes confidence, votes, evidence, safety, readiness, authority, and outcomes. It would encourage a false conclusion that enough of one can compensate for absence of another.

Instead, show independently labelled dimensions only when their source data exists:

- Review: the actual named required conditions and their states.
- Consent: named participant choices for the exact version; unset, no, withdrawn, and yes remain distinguishable.
- Agreement: no agreement, active, paused, retired, and any additional canonical states.
- Action: actions recorded, outcomes recorded, and unresolved consequences as separate facts.
- Round progress, where applicable: the actual phase, readiness, and outstanding outcomes under that round model.

A ring of participant markers can make the table feel alive, but its segments are a symbolic status display. Consent counts need the participant total and scope; “2 of 3 currently yes to v2” may be useful, while “67% safe to act” is false. A no or withdrawal should be calm and legible. It is a legitimate participant choice, not a villain, a damaged fiber, or a failure animation.

## Motion that makes transitions understandable

Every meaningful animation should answer “What changed?” rather than merely imply activity.

| Event | Proposed transition | Stable evidence that remains after motion |
|---|---|---|
| A candidate becomes a proposal | Candidate token moves into the proposal slot after the model accepts the command. | Proposal text, new version, source event, and unfulfilled requirements. |
| A participant decides | That person's symbolic marker changes state with a brief local emphasis. | Name, exact choice, applicable version, and record provenance. |
| Commit succeeds | Proposal and agreement relationship becomes explicit; a short central illumination establishes focus. | Exact agreement identity and current status. No action trace until an action exists. |
| An action is recorded | A trace extends from the agreement toward the outcome/history layer. | Action record and whether an outcome is known. |
| Consent is withdrawn | Relevant marker and state label change immediately; a short emphasis identifies why action is paused. | Earlier consent/action history retained, current consent state, and blockers. |
| Repair is recorded | The consequences item receives its documented resolved state. | Consent remains unchanged unless a separate valid event changes it. |
| Arrangement is retired | Active emphasis settles into a clearly selectable archive object. | Retired status, reasons, consequences, and event history. |

Render authoritative state promptly even when animation is disabled, interrupted, or skipped. Animation is a rendering of an accepted transition, not the clock that decides when permission becomes valid. Reduced motion uses immediate state updates plus concise explanations. Do not impose delays before a person can understand the next state.

## Feature acceptance contracts

These are proposed requirements for the implementation prompt, not claims that the deployed site passes them.

| Feature | Minimum acceptance evidence |
|---|---|
| Central Decision scene | At desktop and narrow layouts, a first visit identifies the activity, proposal/version, agreement state, key blocker, and relevant next action without a ledger search. Scene labels remain readable at the supported viewport sizes. |
| Typed object selection | Pointer, keyboard, and accessible list select the same candidate, proposal, agreement, participant marker, requirement, or event and open the same factual inspector. Selection cannot mutate protocol state. |
| Candidate/proposal/agreement comparison | Reproduce geometric Bridge suggestion plus orchard v2 agreement. All three identities remain clear. Compare never inherits consent or review across versions without canonical model support. |
| Process region mapping | Source review documents every visual state mapping. Upper/table/lower placement cannot hide concurrent ideas, pauses, outstanding consequences, or model-specific round states. |
| Decision/Geometry/History switcher | Switching preserves the selected activity and valid shared context; no state mutation, authority change, fabricated correspondence, or consent transfer occurs. Geometry initially selects Bundle map. |
| Interactive mathematical lesson | Independent mathematical reviewer confirms point/fiber mappings, chart/projection conventions, relevant edge cases, and each operation's affected and invariant state. Accessibility inspection confirms equivalent selection/explanation without the drawing. |
| Versioned consent and progress | No, unset, withdrawal, yes, readiness, confidence, and review are independently represented. No combined progress score or animation can override a failed required condition. |
| Withdrawal/repair/release explanation | Reproduce demo → withdrawal → repair → release. At every step the scene, inspector, status summary, and history agree. Repair does not restore consent, release does not delete history, and retirement cannot be revived in place through view controls. |
| History inspection and replay | Past state is unmistakably identified. Scrubbing and replay issue no live protocol commands. Returning to current restores the actual present state, including intervening events if the architecture supports live updates. |
| Meaningful transition motion | Interrupt animations, enable reduced motion, switch views during events, and issue rapid supported actions. Visual state always converges to actual state; labels and accessible feedback retain the explanation. |
| Learning outcomes | A tester can explain what is being decided, who agreed to which version, why action is blocked, and what changed after repair. Claims about novice comprehension require actual novice testing; agent inspection is labelled expert evaluation. |

## Four independent verification/revision loops for every feature

Apply all four loops to every feature contract above. A builder cannot verify their own work as the independent authority. Each loop must record the build identity, feature identity, verifier, cases, observed results, defects, revisions, and resulting verification evidence. A feature is not complete merely because its parent scene has four reports.

1. **Semantic and model correctness.** Independently derive expected states from canonical model/source and compare scene, inspector, controls, and history against them. Include candidate versus proposal, version-bound consent, commit versus action, withdrawal, repair, release, and activity isolation. Revise all failures and independently confirm the revisions.
2. **Explanation and direct manipulation.** A different reviewer begins from a clean session and uses the actual browser to select objects, compare versions, explore geometry, and explain the process. Add real novice sessions when available. Revise confusing mappings, labels, timing, or sequence; independently recheck. Never report agent role-play as observed human comprehension.
3. **Equivalent access and difficult states.** Independently test keyboard and accessible object list, reduced motion, narrow screens, interrupted motion, stale selection, past-state inspection, and geometry edge cases. Add source-backed negative cases for every affected state boundary. Revise and independently recheck.
4. **Integrated feature and regression review.** A fresh verifier repeats the feature in the whole centerpiece on the exact revised candidate, including a normal journey, a blocked/withdrawn journey, and relevant other-activity isolation. Revise every material finding. Independently verify the post-revision build; continue further loops where necessary.

If a loop identifies no warranted change, record that fact and its evidence instead of fabricating a cosmetic revision. Four is a floor. Revision after the fourth review must still be independently checked. Mathematical verification must use an independently derived expectation; a screenshot that resembles a Hopf illustration is insufficient. Visual elegance must also receive a human-style screenshot review, since passing transition assertions does not establish readability or beauty.

## Suggested centerpiece learning scenario

Open Decision with one understandable card: the cardboard dragon and a proposed route. Let the visitor select the proposal and inspect the table's unanswered questions. Raising confidence changes its own indicator but leaves the missing conditions visible. The visitor explores an alternative in Geometry, sees a candidate appear, and explicitly returns it to the proposal process. The version changes, and the scene reveals which choices apply to that version.

The visitor then witnesses review, fictional participant choices, a commit, and one simulated action as individually inspectable events. Bea withdraws. The table pauses; the action trace remains. Recording repair resolves one visible condition but does not restore Bea's consent. Releasing the arrangement moves it into the retained history. The scene ends with a clear explanation of what the group learned and which future actions are actually allowed.

Use the existing model and verified event sequence for this lesson, with pause, previous, next, and replay controls. A scripted lesson remains explicitly a simulation and does not issue fresh live actions when replaying history. The visitor should finish having experienced the distinctions, not having read a screenful of caveats.
