# Independent clarity verification of the Visualizer review and implementation prompt

Reviewer: clarity and information-architecture specialist, independently reviewing the coordinating agent's synthesis and implementation prompt. Date: 15 September 2026. I did not edit either deliverable.

## Candidate identity and method

- `HOPF_VISUALIZER_DESIGN_REVIEW.md` — SHA-256 `a313292a273b4bfa8c413ffcc5196b09e12e6ec1a11b9b4680686ca55d0ea520`.
- `HOPF_VISUALIZER_IMPLEMENTATION_PROMPT.md` — SHA-256 `89dae5d8739cdc2dc0bd624db673f42ce68c1875edd9bced653dcbd5fb17464e`.

I read both documents, reread the implementation prompt's full initial sections separately after combined-output truncation, checked the cited observations against my own fresh live inspection and the other specialist reports, and inspected the two existing independent concept-review reports. This is document verification. It is not a new live-site implementation test, a mathematical source audit, browser validation of the concept, or execution of the future four-loop implementation process.

## Verdict

**The documents substantially satisfy the user's focused goal and provide a usable, comprehensive implementation prompt. One medium wording defect should be corrected before finalizing.** The centerpiece is explicit, the visual direction is concrete, useful state is precisely specified, scope is bounded, and the per-feature four-loop requirement is unusually well protected against superficial completion claims.

## PCV-01 — Medium: clarify that denied commands can produce real denial events

**Location:** implementation prompt, section 5, paragraph beginning “Keep command dispatch outside render/animation/history code.”

**Current wording:** “A denied action does not advance the scene or invent an event.”

**Issue:** the intent is sound, but the sentence can be read as forbidding any event or visible scene update following denial. The live model deliberately records `blocked` and `blocked_action` events. My observed dragon demo contained a blocked commitment and a later blocked action. The reliability review explicitly requires denied attempts to remain visible in history. Other prompt sections also require every supported event type and truthful accepted/denied feedback.

**Concrete revision:** “A denied command may add the canonical denial receipt/event to history and update its blocker explanation. It must not advance the workflow, create an action/outcome that did not occur, or play an accepted-transition effect.” Preserve any actual model revision/event change associated with that receipt.

This avoids an implementer suppressing legitimate history while attempting to satisfy the instruction against invented events. It also makes a blocked gate's explanatory emphasis compatible with the instruction that successful state-transition effects occur only after acceptance.

**Recheck acceptance:** section 5, VZ10, VZ18, the denied-command fixture, and loop 2 consistently permit real denial records while prohibiting fabricated success. The failed attempt remains visible; agreement validity and action progress do not falsely advance.

## PCV-02 — Low, conditional: maintain the concept snapshot count after revision

The review accurately labels its concept as seven illustrative snapshots at the inspected candidate. Independent concept reviewers recommended adding an explicit action snapshot or subrecord. If the concept revision changes the count, update the opening count and any package summary accordingly. If it remains seven snapshots with an embedded action record, no count change is needed.

This is a synchronization check, not an existing false-count finding. The concept itself was being revised separately during this verification.

## Requirements that passed document verification

| Requirement | Result and evidence |
|---|---|
| Visualizer is the centerpiece | PASS. Both documents state it as the main working surface. The prompt defines first-use placement, approximate dimensions, inspector proportions, dominant agreement form, and phone reflow. Diagnostics cannot displace it. |
| Cool and visually appealing | PASS as a design specification. Concrete palette, lighting restraint, readable depth, stable people, five scene layers, typography, short semantic transitions, and designed 2D representation provide an implementable art direction. This is not a claim that the unrendered concept has visually passed. |
| Superfunctional and easy to understand | PASS. Selection opens meaningful detail; explicit commands act; all existing commands remain reachable; object navigator and inspector share the same context; the default inspector answers decision, agreement, needs, and next step. |
| Actual decision state visible | PASS. Candidate/proposal/agreement identities, versioned choices, recorded review, readiness, specific action eligibility, outcomes, consequences, pause, retirement, and unknown state are distinguished. |
| Meaningful progress | PASS. Counts and phase facts are scoped to actual source data and denominators. No blended percentage, safety meter, or implied consent threshold. A No is a valid recorded response, not a failure animation. |
| Proposal and agreement coexistence | PASS. The prompt explicitly covers active v1 plus new proposal v2 and requires executed actions to name the applicable agreement version. It protects against v1 approvals appearing under v2 after replay. |
| Scope isolation | PASS. Parade and four-seat rehearsal share a shell without invented shared semantics. Scope is visible, adapter differences remain explicit, and commands/selection/history cannot cross-contaminate scope. |
| Decision, Geometry, and History relationship | PASS. Decision is the default lens, Geometry defaults to Bundle, and History is read-only time context reachable from either. It is not an independent competing state engine. No historical geometry is fabricated where records do not supply it. |
| Current versus replay semantics | PASS. Historical cursor, current state, selection, camera, and motion are separate. Current events cannot silently move the selected historical event. Return to current uses the latest state. Replay cannot issue commands or reapply outcomes. |
| Motion versus state | PASS. Permission appears immediately; accepted-event animation cannot overwrite a later pause. Pause motion does not pause current facts; pause replay is a different control. |
| Real independence | PASS. Actual separate verifier identity required, self-acceptance prohibited, code-contributing verifiers disqualified for that patch, at least two verifier identities per feature, frozen candidate and retained failed records. |
| Four loops per feature | PASS. Section 8 spells out I1/R1/K1 through I4/R4/K4, requires all four independent revision rechecks, and explicitly rejects four whole-site reviews as a substitute. |
| Fourth-revision verification | PASS. K4 is mandatory and separately explained. Final integration audit follows it; unfinished material failures require more loops. |
| No-change and grouped-run handling | PASS. No-change revisions require evidence and recheck. Shared sessions need feature-specific criteria and results. Broad grouped feature rows cannot hide untested individual controls; children each receive four loops. |
| Completion criteria and evidence | PASS. A mechanically inspectable ledger includes feature/criterion, loop/stage, immutable candidate, builder/verifier, setup, expected/actual, evidence, finding, revision, and recheck. Affected accepted criteria reopen after dependency changes. |
| No fabricated completion claims | PASS. Review explicitly says live site unchanged, concept illustrative and disconnected, future implementation loops not performed. Prompt forbids representing a concept/static image as functionality or a blocked gate as completion. |
| Evidence discipline | PASS within document review scope. Canvas measurements match my fresh observation and visual review; retirement is supported by the learning review; v1/v2 ambiguity is reproduced by reliability review. Source optimization findings are labeled candidates rather than benchmarks, and deployment parity is unestablished. |
| Concept verification limits | PASS. Existing independent concept reports support the source/fixture-review claim. Browser security limitation is explicit. No responsive, contrast, assistive, actual browser-interaction, mathematical, or integration certification is claimed. |

## Practical interpretation

An implementation agent can identify the desired object hierarchy, model boundaries, minimal feature inventory, negative-state fixtures, and evidence needed to finish. A reader can understand the proposal without already understanding Hopf topology: an idea is separate from an agreement, each person has an actual choice, action has a specific basis, and consequences remain visible after a pause.

The specification also preserves mathematical exploration as an attractive first-class activity. It does not turn people into literal fibers or turn numerical invariants into authority. This resolves the main tension between a dramatic visual centerpiece and a trustworthy working interface.

After PCV-01 is revised, independently re-read the exact revised paragraph and its related denial/history criteria. Final reporting should describe this as verification of the review/prompt, distinct from the future feature-level production loops.

## Independent recheck of the revised documents

Rechecked on 15 September 2026 against these exact candidates:

- `HOPF_VISUALIZER_DESIGN_REVIEW.md` — SHA-256 `3be509b6f1c2103f1c96fc88574c778c61ac4d5f698015a147e847d330e593d9`.
- `HOPF_VISUALIZER_IMPLEMENTATION_PROMPT.md` — SHA-256 `c986a1f0f60643964f5584db22e4c1092535b3601d2eb4d7be44f5eadbb93c9b`.

**PCV-01: PASS / resolved.** Section 5 now explicitly permits canonical blocked/denied history and blocker feedback while prohibiting a fabricated accepted action/outcome or advancement as though the command succeeded. I checked the paragraph together with VZ10, VZ18, the denied-command challenge and the four-loop criteria. These requirements now agree: real denial records are retained and understandable, while authorization and action progress stay truthful.

**PCV-02: PASS / synchronized.** The design review now says eight illustrative snapshots. I inspected the revised concept's eight explicit replay buttons (`data-state` 0 through 7) and its eight scene entries: Proposed, Review, Agreed, New draft, Action, Withdrawn, Repaired, Retired. The count matches; the separate Action record supplies the previously missing visible cause. This narrow count check does not certify concept rendering or its full behavior.

**Added mathematical verification requirement: PASS as prompt wording.** Section 9 now requires the independent mathematical verifier to derive representative expected values and invariants from declared definitions/conventions, rather than merely trusting renderer output or existing tests. This makes independence concrete while requiring discrepancies to be reconciled. I have not independently evaluated the mathematical implementation.

**Four-loop guard retained: PASS.** I reread the revised section 8. All I1–I4/R1–R4/K1–K4 requirements, exact-candidate evidence, mandatory post-R4 K4, feature-specific shared-run results, and final independent integration audit remain intact.

**Revised document verdict: PASS within the stated document-review scope.** No unresolved clarity finding remains from this verification. The earlier findings are preserved above as the record of what changed. This recheck does not mean the website was implemented or that its required four verification loops have run.
