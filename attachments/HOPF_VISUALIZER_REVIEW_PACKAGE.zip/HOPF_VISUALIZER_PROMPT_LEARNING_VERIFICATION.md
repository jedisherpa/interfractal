# Independent learning and mathematical-truth verification

Reviewer: learning and mathematical explanation specialist; independent of the author of the two consolidated documents. Date: September 15, 2026.

## Verdict

**PASS for the requested review-and-prompt deliverable, with two small recommended clarifications below.** I found no material contradiction in the learning design, mathematical/process distinction, authority boundaries, candidate/proposal/agreement handling, preserved scope, or four-loop verification requirement. This verdict concerns the documents, not a completed implementation, numerical certification, novice study, or browser validation of the illustrative concept.

Reviewed artifacts and immutable identities:

| Artifact | SHA-256 |
|---|---|
| `HOPF_VISUALIZER_DESIGN_REVIEW.md` | `a313292a273b4bfa8c413ffcc5196b09e12e6ec1a11b9b4680686ca55d0ea520` |
| `HOPF_VISUALIZER_IMPLEMENTATION_PROMPT.md` | `89dae5d8739cdc2dc0bd624db673f42ce68c1875edd9bced653dcbd5fb17464e` |

## Evidence and scope

I read both consolidated documents completely. I compared them with my focused learning review and its independently observed browser sequence: initial state, Bundle map, Reframe, the dragon demo, withdrawal, repair, and retirement. I also consulted the focused reliability and clarity reviews for the separately observed active-v1/new-v2 sequence, action-version ambiguity, and scope distinctions. The reliability report explicitly attributes source corroboration to the coordinator; I did not independently audit that repository source in this verification.

The Niles Johnson mathematical reference was opened during my original focused inspection. It supports the cited teaching relationships among base points, fibers, and selected families of fibers. The consolidated review accurately calls it a teaching reference rather than certification of this application. I did not separately recheck the W3C/MDN sources because this verification's assigned scope is learning/mathematical truth; those remain with their relevant reviewers.

## Checks

| Requirement | Result and evidence |
|---|---|
| Visualizer as the centerpiece | PASS. The default useful screen centers the scene and an inspector answering decision, agreement, unmet needs, and next action. It is not restricted to an expert drawer. |
| Decision default and Geometry/Bundle default | PASS. Both documents state these distinctly. The prompt explicitly instructs reconciliation with current repository instructions. |
| History does not invent a third authority model | PASS. The synthesis chooses two lenses plus an explicit historical time context. This retains the learning functionality of the originally proposed three views while simplifying navigation. |
| Symbolic process versus mathematical geometry | PASS. Cones and decision torus are explicitly process vocabulary. Geometry retains accurate chart/projection meaning and numerical limitations. No fiber is treated as a human participant or a theorem of consent. |
| Candidate, proposal, and agreement | PASS. Each has a separate type, visible identity, explicit promotion/commit action, and comparison treatment. The v1-active/v2-proposed case is mandatory. Candidate geometry cannot silently become a proposal or agreement. |
| Version-bound responses and review | PASS. The prompt prevents transfer of v1 responses to v2, includes historical selection regression, and derives actual agreement validity from canonical rules. It qualifies older agreement preservation by the actual model. |
| Commit, action, outcome, repair | PASS. These remain distinct. Repair changes only contracted facts, does not restore consent, and cannot fabricate successful action or outcome. |
| Withdrawal and retained earlier action | PASS. The scene updates promptly and retains prior actions and consequences. No delayed animation may overwrite a newer paused state. |
| Retirement and retained history | PASS. Retirement preserves inspectable records and cannot be undone by replay, reload, or direct manipulation. Missing legacy history is disclosed rather than fabricated. |
| Progress and participant agency | PASS. No blended consensus/safety/completion score; response counts and review conditions remain separate. No/unset/withdrawal are distinct where source evidence permits, and people remain present. |
| Different practice models | PASS. Separate adapters and explicit scope prevent readiness/phase/outcome rules from silently moving between parade and rehearsal. |
| Existing controls and task scope | PASS. All existing supported commands must remain accessible. VZ21–23 explicitly preserve geometry operations and their individual criteria. The task does not expand into production identity, other repositories, a new permission engine, or unrelated redesign. |
| Honest explanation and research claims | PASS. No agent role-play is claimed as novice testing. The review separates live observations, repository inspection, proposals, concept limitations, and future implementation verification. |
| Mathematical correctness requirement | PASS, with recommended clarification MATH-02 below. Source definitions, normalization, projection invariance, singularities, endpoints, linking conventions, curvature/Chern expectations and Carry units must be checked. |
| Four loops per feature | PASS. Feature inventory, child-feature splitting, traceability, I1–I4/R1–R4/K1–K4, candidate identities, actual independent reviewers, failed-record retention, and mechanical completion criteria are explicit. |
| Independent fourth-revision check | PASS. K4 is mandatory after R4, and an independent final integration audit follows. A failed final revision cannot be labelled complete. |
| Review independence | PASS. Builders cannot accept their own code or repairs, at least two independent verifier identities participate per feature, and a verifier who writes a fix loses independence for that patch. |

## Recommended clarifications

### LEARN-V01 — Preserve real denial events while prohibiting fabricated success

**Priority: low; wording clarification, not a release blocker for the prompt.**

Prompt §5 currently says: “A denied action does not advance the scene or invent an event.” In context, this correctly prohibits a fabricated accepted event. However, the current teaching model visibly records blocked and blocked-action events, and those are important to learning why confidence or incomplete consent did not permit action. The same prompt also requires complete supported event history.

Recommended replacement:

> A denied command does not advance the domain process or fabricate an accepted event. Preserve any canonical blocked/denied event or receipt, and display its reason and unchanged process state in the history and inspector.

**Acceptance:** Attempt an invalid Commit or Act. The agreement/action state does not advance. A source-supported denial record remains selectable with its true cause. No fake successful action is drawn. If the canonical model does not emit a historical event, show the denial feedback without inventing one.

### LEARN-V02 — Make the mathematical oracle independent explicitly

**Priority: low; strengthen an already present obligation.**

Prompt §9 lists the right mathematical checks and the focused-review mapping imports the original requirement for independently derived expectations. Nevertheless, an implementation agent could read “preserve computations and tests” as merely rerunning existing repository tests. A mathematical implementation error and a matching test expectation could then survive together.

Add after the mathematical-check paragraph:

> For changed mathematical rendering or calculations, the independent mathematical reviewer must derive at least one analytic or independently computed expected result for every affected operation, using the declared conventions and an authoritative definition. Record the derivation/oracle and relevant edge cases; agreement with the existing implementation or its existing test output alone is insufficient.

**Acceptance:** A reviewer can identify the expectation's independent source and method, the declared sign/coordinate conventions, the numerical tolerance or convergence reason where relevant, and the actual comparison. The derivation must not be copied from the function under review and reported as independent verification.

## Claims requiring the stated limits to remain

- The active-v1/new-v2 and ambiguous action-prefix facts are corroborated by the separate reliability review, not by my own renewed browser sequence. The synthesis correctly avoids claiming that unapproved v2 executed.
- The source blob is an inspection anchor. No reviewed evidence establishes that it is exactly the deployed commit; both consolidated documents preserve that limitation.
- Source-level frame scheduling and repeated computation support investigation, not measured performance claims. The consolidated review labels them accordingly.
- The concept's syntax/source checking and browser-preview limitation are stated in the synthesis. My verdict does not certify its rendering or independently repeat its source fixture tests.
- The exact mathematical renderer remains a future verification target. A correct primary mathematical reference cannot establish correctness of this application's implementation.

The documents do not need restructuring. The two clarifications above can be inserted narrowly without altering the recommended scene, the preserved protocol, the feature inventory, or the mandatory verification cycle.
