# Visualizer review — functional reliability, state, and verification

**Reviewer:** the reliability specialist from the preceding five-person review.  
**Scope:** make the Visualizer the site's central interface for understanding decisions, progress, and current state. This is a review and implementation specification, not a website modification.  
**Observed:** 2026-09-15, [Hopf Workshop](https://hopf-workshop.vercel.app/), in a new isolated browser tab using the public teaching simulation.  
**Earlier review:** `reviews/reliability-review.md`, used as continuity and explicitly distinguished from observations repeated below.

## Main recommendation

Make the centerpiece a **visible explanation of the actual workshop state**. Its shape, labels, selection details, next-action controls, and timeline must all read the same canonical snapshot. Geometry remains a powerful explanatory lens, but an animation must never be the thing that decides whether someone agreed or whether action is authorized.

The most important upgrade is a state projection layer joining the existing teaching state to the scene. Enlarging the current geometry drawing will not achieve Paul's objective: the current drawing does not show the agreement becoming active, a new proposal waiting for consent, or the agreement pausing after a withdrawal. Those facts remain in separate text panels.

Use the upper exploration area for proposals, a central torus for a specifically identified agreement, and a retained history area for released forms and outcomes. These are visual placements, not a replacement state machine. The scene should answer: **What are we considering? What have we actually agreed? What is stopping the next action? What changed?**

## What I directly observed in this focused review

1. The site presents a separate four-seat table and three-seat Parade table. The Geometry lab offers Hourglass / process, Bundle map, coordinate sliders, Explore, Reframe, linking recomputation, and transport around a latitude. No visible selector associates the geometry with a particular decision table.
2. Reframe by π/2 appended an event saying that common phase changed and proposal and permission remained unchanged. No agreement or consent appeared. Preserve this boundary.
3. Moving θ to its upper limit changed the displayed projection to `0.0516, 0.0000, -0.9987`; the protocol projection remained `0.8660, 0.0000, 0.5000`. The UI correctly said the sliders were camera/display controls.
4. Explore these coordinates made the displayed and protocol projections coincide, enabled Propose geometric suggestion, and logged that exploratory coordinates changed while permissions did not. This is a distinct operation from merely moving a slider and must stay explicit.
5. Carry once around this latitude logged a holonomy result without creating agreement, consent, or authorization. Its name should not become visually confused with executing the dragon-carrying agreement.
6. After recording review and clicking all three Yes controls, Commit made the Parade table ACTIVE. The Geometry lab's accessible image description remained a generic bundle explanation; the lab did not expose the active agreement, participants' consent, or current blockers as a decision-state summary.
7. After Propose replacement, the Parade table showed ACTIVE beside the unapproved v2 orchard proposal. Act logged `10 simulated_action v2 Carry the cardboard dragon over the bridge`. This repeats the earlier review's version-label ambiguity: the event's body described the committed v1 bridge action, while its prefix showed current proposal v2. This does **not** prove the unapproved orchard proposal executed.
8. Bea withdraws then showed PAUSED and logged that Bea stopped participation in agreement v1; Act was correctly denied. The geometry region continued to describe the same mathematical bundle and still did not summarize this decisive state change.
9. At the θ extreme, the Bundle map contained long projected strands crossing the viewport. The visual was mathematical linework, not an inspectable representation of which human had done what. Other specialists own the detailed projection, sizing, and art-direction recommendations.

**Source corroboration supplied by the coordinating reviewer:** inspection of `workshop.html`, blob `55e79d4edd53d758f8764da53af2e97c90e76657`, found that the drawing path reads angles and map mode and draws fibres; it does not take agreement, consent, rehearsal, or ledger data. Separate rendering updates text panels. I did not independently reread that source; this attribution is deliberate. The coordinator also found continuous animation-frame scheduling under reduced motion, repeated fibre generation, and curvature computation on ordinary renders. Those are implementation targets requiring measurements, not benchmark results from this review.

Earlier review evidence additionally established readiness-versus-consent separation, blocked invalid phase ordering, duplicate RETURN rejection, repair not automatically renewing authorization, retirement blocking action, and reload resetting both practice tables. Those behaviors should be regression fixtures; they were not all repeated during this focused pass.

## What the central scene should express

Give the scene a stable identity strip: **Three-person parade · Practice · Current state** or **Four-seat practice · Round 2 · COORDINATE**. A user must not have to infer which table they are viewing from the number of dots. Changing scenarios selects another state source and never merges the tables' people, consent, rounds, or history.

Place versioned objects in the scene rather than one global ACTIVE badge. A proposal token can say “Orchard route · proposal v2 · awaiting review,” while a separate central token says “Bridge route · agreement v1 · active.” Selection brings up the exact text, recorded review, participant responses, authority scope, and event references for that object. The scene remains understandable even when both objects coexist.

Use short cause-and-effect transitions after canonical receipts: a participant's recorded response appears on that participant; a confirmed commitment places the identified agreement in the torus; withdrawal changes that agreement to a labelled paused form. At rest, the same information remains visible. Animation is an explanation of an event that already occurred, never evidence that it occurred.

Represent waiting, disagreement, blocked action, pause, repair, and release as legitimate states. Do not give every non-green state an alarming failure aesthetic. In particular, a person's No is a response that must be understood; a missing response is unknown; withdrawal is an explicit event; none should be substituted for another.

## State-to-display contract

These mappings are proposed acceptance criteria. Their field names are conceptual; adapt them to the actual model. Do not introduce unsupported domain states merely to match a drawing.

| Canonical fact | Scene and plain-language display | Required detail and behavior |
|---|---|---|
| No agreement | Empty central agreement position; “No active agreement” | Proposal may exist elsewhere. Empty is not loading or failure. |
| Current proposal vN | Distinct, labelled proposal token | Exact proposal text and version. Do not label it active because an older agreement is active. |
| Draft review controls | Draft marks in inspector | “Not recorded for vN.” Checkboxes do not stand in for recorded review. |
| Review recorded for vN | Three named review indicators with event reference | Evidence, authority, safety remain distinct; version change does not inherit them silently. |
| Participant readiness for current round | Separate readiness marker and text | Readiness cannot fill the consent marker or imply permission. Missing readiness must not count as ready. |
| Consent unset / yes / no / withdrawn | Named participant markers with shape, text, and response state | Bind to proposal/agreement identity as appropriate. Old-version Yes appears only as historical detail. |
| All prerequisites satisfied, no commit | “Ready for a human commitment action” | A complete ring must not say committed. No automatic transition or celebration that implies commitment. |
| Committed agreement vM active | Central agreement token labelled vM and ACTIVE | Its action controls target vM explicitly. Current proposal vN may differ. |
| Invalid action attempted | Local explanation attached to attempted action and relevant blocker | Remain at the actual stage; denied attempt is visible in history but does not advance progress. |
| Four-seat PLAY / COORDINATE / ACT | Canonical phase marker plus round | Do not invent this phase field for the three-seat model or derive it from cone position. |
| Agreement paused after withdrawal | Explicit pause marker with cause and actor | Pause any visual suggestion of execution immediately. History and consequences remain. |
| Repair unresolved / resolved | Named repair state and response record | Resolving consequences does not itself renew consent or reactivate action. |
| Agreement retired | Retired token in retained history area | Inspectable record remains. Never revive its grant by dragging it, replaying it, or reloading. |
| Outcome recorded, not yet applied | Outcome marker labelled “Recorded; awaiting RETURN” where the model supports that distinction | Show participant, round, agreement version, evidence/result identity. Recording a claim is not proof of success. |
| RETURN successfully applied | Updated round and “Applied once” receipt for the relevant outcomes | Counts derive from unique applied outcome identities. Do not imply all participants completed work because one outcome was applied. |
| Return to planning / replacement / repair branch | Visible feedback route and new version or round label | Process progress is not a monotonic percentage. Prior learning and unresolved consequences remain inspectable. |
| Historical cursor selected | Persistent “History · event … · read only” label | Current agreement remains unchanged. Return to current state is obvious. No state-changing controls operate on the historic snapshot. |
| Display geometry differs from protocol projection | “Exploring a different view” in Geometry details | Equality follows the existing projection contract, not a newly invented requirement that every coordinate or common phase match. |
| Adapter loading, stale, disconnected, inconsistent, or unsupported | Visible data-health status separate from agreement status | Do not claim activity stopped merely because connection was lost. Do not present stale information as current authority. Local idle simulation is not stale merely because time passed. |

## Progress: display evidence, not an invented completion score

Use several small factual measures instead of “Decision 82% complete.” Examples: “Review: 2 of 3 recorded for v2,” “Responses: 2 of 3 received — 1 Yes, 1 No, 1 unset,” “Round 2 · COORDINATE,” and “1 outcome applied at last RETURN.” A response count can increase while the proposal becomes less ready to commit. That is useful information, not a defect in a progress bar.

The denominator comes from the canonical participant set for the applicable proposal or round. The renderer must not drop nonresponding people to make a ring look complete. Changed membership is an event with explicit model semantics, not a layout decision. If the model does not supply an authoritative denominator or outcome expectation, show the count without inventing a percentage.

For every candidate action, provide “Why available?” or “What is needed?” linked to named blockers. Do not repeat an independent copy of domain guards in the visual layer. If no authoritative eligibility query exists, add a narrow read-only adapter to existing guard results and verify it against the normative model.

## Bounded architecture: one engine, several views

1. **Canonical workshop/rehearsal model remains owner of truth.** Preserve the Python normative model and existing JavaScript parity obligation. The Visualizer is not an opportunity to rewrite permission logic.
2. **One adapter produces immutable snapshots.** It projects a selected scenario into a decision view model. It keeps proposal, agreement, participant responses, recorded review, blockers, round/phase, outcomes, history, and availability separate. Unsupported values are explicit, not inferred from the most recent text log.
3. **One shared selection state drives scene and DOM inspector.** Selected proposal, participant, agreement, outcome, or event is an identity, not a screen coordinate or array index. The accessible list and visual scene expose the same facts.
4. **Command dispatch stays explicit and outside rendering.** The inspector's buttons call the existing command path with the actual target. Clicks on shapes may select, explain, or open controls. Camera movement, hover, drag, resizing, animation completion, colour changes, and timeline scrubbing never grant consent or commit an agreement.
5. **Command receipts update state before event animation.** The UI shows pending feedback when applicable, then adopts confirmed state. A rejected command leaves canonical state and stage unchanged and explains why. A renderer failure cannot block the domain transition or hide the accessible state.
6. **History is a projection, never re-execution.** Replaying previous events must not call commands or reapply outcomes. Use supported snapshots or a tested read-only reconstruction method; if existing ledger records are insufficient, label replay unavailable until the necessary data is supplied.
7. **The geometry lens reuses existing mathematical operations.** Preserve Explore as an explicit exploratory-model change; ordinary coordinate viewing and mathematical transport do not authorize. Keep the process metaphor distinguishable from the actual bundle description.

Conceptual adapter shape:

```ts
type DecisionView = {
  scenarioId: string;
  mode: "practice-current" | "history";
  snapshotId: string;
  sourceRevision: string | number;
  proposal: VersionedProposalView | null;
  agreement: VersionedAgreementView | null;
  participants: ParticipantStateView[];
  review: RecordedReviewView;
  blockers: BlockerView[];
  phase: CanonicalPhaseView | null; // null if this scenario has no phase field
  outcomes: OutcomeView[];
  history: EventView[];
  actions: ActionAvailabilityView[];
  dataHealth: DataHealthView;
};

// Pure projection; no command dispatch, consent mutation, or event application.
projectDecision(sourceSnapshot, selectedScenario, historyCursor): DecisionView;
```

This is a suggested boundary, not a prescribed new framework. Use the current site's technology if it can meet the behavior and rendering targets. Do not add a second orchestration kernel, real multiplayer identity system, or external production integration merely to produce an attractive teaching centerpiece.

### Required identity and event wiring

Every fact shown in a status ring or inspector must carry its source identity. Event data should distinguish current proposal context from the agreement actually affected or executed. For the observed failure, the UI needs an unambiguous equivalent of:

```text
Action performed under agreement v1: Carry the cardboard dragon over the bridge.
Proposal currently under consideration: v2, Orchard route.
```

Prefer structured event fields such as `eventId`, `eventSequence`, `kind`, `scenarioId`, `proposalVersion`, `agreementId`, `agreementVersion`, `roundId`, `participantId`, and `outcomeId` where relevant. Adapt to actual identities and semantics, and extend both normative and view contracts where a material model change is required. Do not reconstruct authority by parsing the human-readable event sentence.

Use event sequence/identity for ordering and deduplication. A display timestamp alone is not a safe event identity or ordering rule. Late animation callbacks must be cancelled or replaced when a newer snapshot arrives; a delayed commitment flourish must never visually overwrite a later withdrawal. All DOM summaries and scene encodings should settle to the same confirmed revision.

### Current-state, history, practice, and future integrations

The inspected website is a teaching simulation. “Current practice state” is more accurate than a label that implies a synchronized production team. Switching to the four-seat table must clearly disclose a separate simulation. A future connected adapter may add authoritative server revisions and connection health; the present work should define that boundary without claiming to have built it.

If history playback is offered, label it persistently and disable its mutation path. If a historical example can be branched into practice, require an explicit **Start a new practice from this example** action creating a new scenario identity. It must not silently edit the original session. If save/resume is included, preserve proposal and agreement versions, withdrawal, retirement, outcome identities, and the displayed retention contract. Never store a screenshot or animation cursor as the authoritative workshop save.

## Failure tests that matter

The independent verifier should build expected results from the canonical model and acceptance criteria, not from the builder's screen. Use these adversarial cases alongside ordinary learner journeys:

- All participants Ready, none Yes: readiness complete; consent incomplete; commitment absent.
- Review controls checked but not recorded: no completed-review glow.
- All requirements passed but no Commit: no active agreement or action permission.
- v1 active; v2 proposed: two versioned objects; v1 action shown accurately; no v2 consent inheritance.
- Actor says No: explicit response, not silence and not consent; blockers explain effect from actual rules.
- Withdrawal during a commitment animation: final screen settles to PAUSED; no stale active label, success flourish, or usable action.
- Repair resolved: consequences update; permission stays as dictated by canonical state until valid renewed authorization.
- Retirement then history scrub or reload: no grant revival.
- Failed or denied command: receipt shown; no phase advancement, fabricated event, or outcome application.
- Duplicate RETURN or duplicate delivered event: at most one application, stable round/count, one identity in history.
- An outcome contradicts its agreement's scenario: traceable discrepancy, not silently presented as successful completion.
- More events than the initial visible window: full available history remains accessible; any retention limit is stated.
- Switch scenarios during pending interaction or animation: replies cannot update the wrong scene or participant set.
- Toggle Decision/Geometry, move camera, change φ/γ, resize, select participant, or use keyboard: grants, consent, and commitment unchanged unless an explicit existing command was invoked.
- Lose rendering capability or reduce motion: plain-language state and controls remain usable; no authority information exists only in a canvas.
- If an asynchronous adapter is introduced: out-of-order, duplicate, stale and incompatible payloads produce a truthful data-health state; they do not produce guessed authorization.

Browser testing alone cannot prove the command boundary. For permission-sensitive mappings and event identities, include domain/parity tests. Conversely, unit tests alone cannot prove that a person can distinguish v1 from v2 in the actual scene; inspect the real rendered interface.

## Four independent loops for every feature

For **each** implementation feature, record: acceptance criteria, builder, verifier, candidate commit, exact scenario/steps, canonical oracle, UI evidence, failures, revision or justified no-change, and the next candidate. Each loop contains independent verification, a report, and a response to the report. Do not fabricate code changes when a loop finds no defect. After loop four's response, a different agent verifies the final candidate again. Material later changes reopen affected feature and integration checks.

The following is reliability coverage to merge with the other specialists' feature inventory. It is not a limit on the complete implementation scope.

| Feature | Loop 1: normal semantics | Loop 2: version / invalid state | Loop 3: lifecycle / recovery | Loop 4: integrated real use |
|---|---|---|---|---|
| Canonical decision projection | Snapshot matches all visible statuses | Missing/unsupported field never guessed | Projection failure exposes truthful fallback | Scene, inspector, and history share revision |
| Proposal / agreement identity | Select and explain both objects | v1 active alongside unapproved v2 | Withdrawal/retirement binds correct agreement | Learner identifies action target before acting |
| Participant state | Separate readiness and consent | Old-version Yes and current unset coexist clearly | No/withdrawal/membership cases follow model | Keyboard and visual selection expose same facts |
| Review and blockers | Recorded prerequisites visible | Draft flags and recorded review differentiated | Replacement invalidates only what model specifies | Valid next action and denial reason agree |
| Progress / phase | Phase, round, counts correct | Ready is not commit; denied action is not progress | Repair and return-to-planning represented | Full cycle without invented completion percentage |
| Commitment / action rendering | Confirmed receipt drives state | Double-click and denied commit do not fabricate success | Withdrawal overtakes pending animation | Final settled state agrees after rapid interactions |
| Repair / retirement | Causes and consequence records accessible | Resolve repair does not auto-authorize | Retired agreement stays retired through reload/history | New proposal sequence retains old obligations/history |
| Outcomes / RETURN | Outcome points to right agreement and round | Duplicate return applies once | Contradictory/partial outcome stays qualified | Next round and retained learning match canonical state |
| Event history / replay | Event selection explains change | Replay invokes no commands | Long history and stale cursor recover correctly | Current-vs-history distinction remains obvious |
| Scenario isolation | Select parade versus four-seat clearly | State/events never cross tables | Switch mid-animation/pending operation | Repeat full cycle in each supported scenario |
| Geometry / decision controls | Both lenses preserve existing operation meanings | Camera/reframe/selection cannot grant | Extreme coordinates and invalid rendering values recover | Return from Geometry retains exact decision identity |
| Rendering / session continuity | Scene and text load together | Missing render support preserves controls | Reduced motion, visibility, reload contract verified | Long session remains responsive with correct final state |

Keep four evidence-bearing loops for every feature even if one common test covers several features; identify each feature's own oracle and result. Four screenshots of one successful scenario are not four loops. Four test writers who all accept the builder's interpretation are not an independent authority review.

## Release gates and evidence limits

The centerpiece is ready only when a new visitor can correctly say what is proposed, what is currently agreed, who has responded to which version, why the next action is available or blocked, and what changed after an outcome. A verifier must demonstrate these answers on the actual scene in desktop and mobile layouts, with keyboard access and reduced motion, against canonical expected state.

No severity-one authority/version confusion, stale active agreement after withdrawal, duplicate outcome application, crossed scenario state, inaccessible essential state, or unverified final revision may remain. Record material unresolved issues and explicit scope limits rather than claim general production readiness.

This review did not audit authentication, server permissions, real multiplayer identity, mathematical proof, full JS/Python parity, persistence corruption, or all rendering/performance paths. Their tests above are implementation requirements where relevant; they are not claims that those capabilities have already been tested or built.
