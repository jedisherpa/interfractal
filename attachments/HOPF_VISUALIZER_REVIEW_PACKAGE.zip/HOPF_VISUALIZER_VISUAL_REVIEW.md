# Hopf Workshop Visualizer — independent visual design review

Role: visual design, art direction, hierarchy, motion, responsive interaction. Reinspection: 15 September 2026. Site: https://hopf-workshop.vercel.app/. This is a design review and implementation specification, not a report of deployed changes.

## Recommendation

Make the Visualizer the first substantial thing a visitor sees: a beautiful, legible instrument for watching a proposal become an agreement, encountering a changed condition, and learning what happens next. The spectacle should come from seeing the system respond clearly to a meaningful human action.

Use a luminous, spatial decision scene with stable participant positions, an explicit current proposal, visible requirements, and an inspectable history. Set it in a restrained twilight environment that relates to the existing voxel world. Keep mathematical geometry available as a separate, equally polished lens. The process scene is a metaphor; the mathematical view should show the actual geometry faithfully. Neither grants authority.

This supersedes the earlier visual review's suggestion to make geometry subordinate to a guided lesson. Paul's new direction is explicit: the Visualizer is the centerpiece. Teach through its objects and state changes, with short contextual guidance adjacent to the relevant object.

## Reinspected evidence

I revisited the public deployment in an independent browser tab, inspected its visible DOM and screenshots, switched between Hourglass / process and Bundle map, measured the rendered canvas, and ran the explicitly simulated cardboard-dragon demo. I inspected the resulting paused state. No real-world participant action, repository change, or deployment was performed.

| ID | Observed evidence | Design implication |
|---|---|---|
| VV-E01 | Geometry lab is below the large four-seat practice table; the landing hierarchy still presents it as one panel among others. | The main entry needs a stage, not a secondary lab card. Scope switching should sit inside the Visualizer rather than forcing two competing tables onto the page. |
| VV-E02 | Canvas attributes remain 900 × 520; measured CSS display was 838 × 233. Its native aspect ratio is 1.731 while its displayed ratio is 3.597. | Repair sizing before art polish. Geometric proportions are visibly compressed. Inspect renderer compensation in source before deciding the exact fix. |
| VV-E03 | The process image is a black field with very fine, low-intensity cyan/orange loops and funnel outlines; labels are tiny within the image. Its largest meaning-bearing objects are unnamed. | Increase the useful projected size, line hierarchy, contrast, and external HTML labeling. A larger black box alone is insufficient. |
| VV-E04 | Bundle mode shows many fine intersecting curves with dense central overlap. The caption distinguishes mathematical charts from authority, but the visual itself has little foreground/background separation. | Introduce a deliberate geometric layer hierarchy, selection isolation, readable legends, and camera reset. Preserve exact geometry instead of decorating it into false geometry. |
| VV-E05 | Running the dragon demo results in Parade table PAUSED, proposal v2, Maya and Finn yes, Bea no, with a ledger containing commit, simulated action, withdrawal, and blocked action. | The underlying lesson supplies useful state that can drive a much richer process visualization. |
| VV-E06 | In that paused state the process drawing remains a generic pair of loops and funnels; it exposes no participant names, proposal version, withdrawal marker, repair branch, or visibly stated current stage inside the scene. Coordinates and geometric diagnostics remain unchanged in the DOM. | The image cannot presently explain the most important change by itself. Bind a semantic process scene to state and events while preserving the mathematical renderer's independent role. |
| VV-E07 | Most geometry controls have matching gold outlines. Persistent selected state is clearer in the DOM than in the unfocused visual treatment. | Make view selection visibly durable and separate selection from keyboard focus. |
| VV-E08 | The page explicitly says the two tables are separate simulations; sliders are camera/display coordinates; topology does not authorize; Joe is presentation only. | Preserve these boundaries in scene scope, labels, interactions, and implementation. A unified visual shell must not merge their state. |

These findings are desktop observations. I did not inspect source, prove geometry, test native mobile, establish a frame-rate baseline, or verify canonical Joe asset provenance. Proposed outcomes below are design targets, not measured user-study results.

## Art direction: an illuminated workshop instrument

The visual character should feel like an intricate luminous object floating above a small crafted workshop surface. It can belong to Joe's world without requiring a giant character image or a full game engine.

Use a deep blue stage with faint atmospheric depth; a modest faceted or voxel island/table silhouette at its base; crisp luminous geometry above it; solid readable labels in front of it. Warm gold identifies the current proposal and available primary action. Cyan is reserved for selected relationships and geometric inspection. Violet carries ideas or alternate proposals. Mint indicates verified fulfilled conditions. Amber identifies attention, unresolved conditions, and pauses. Refusal uses explicit words and a stable symbol; it must not turn a participant into a villain or a defeated game piece.

Keep the surrounding application chrome quiet. The stage has one strong focal object and four supporting layers. Avoid an unrelated neon cyberpunk dashboard, bloom on every edge, a field of drifting particles, or a dozen animated widgets. The intended beauty is clarity, depth, and responsive cause and effect.

### Proposed tokens

| Role | Starting token | Use |
|---|---|---|
| Stage | `#081421` | Deep blue background; optional subtle radial gradient to `#143447` behind the focal object. |
| Elevated panel | `#132636` | Opaque inspector, controls, and annotation surfaces. Avoid transparency under small text. |
| Primary text | `#F2F7FB` | Main labels and values on the dark stage. |
| Secondary text | `#B7C9D7` | Supporting text; still readable, not faint decoration. |
| Neutral line | `#58778E` | Secondary geometry and interface boundaries where the measured contrast suffices. |
| Current proposal | `#FFD27A` | Main object, current-version plate, focused process path, dark text on filled action. |
| Selection | `#76E0EB` | Selected edge/object; separate from consent state. |
| Fulfilled condition | `#8BE0BC` | Check glyph plus explicit satisfied label. |
| Attention / pause | `#FFCA80` | Pause marker, blocker summary, re-review needed. |
| Idea / alternative | `#BDB3FF` | Upper canopy and uncommitted alternative objects. |
| System failure | `#FFA4A4` | Actual loading or synchronization error, with explanation and recovery. |

These are candidate tokens. Independently measure final composited contrast rather than treating the table as a conformance certificate. Do not use an accent alone to distinguish a state. Text needs its own contrast; a blurred glow cannot serve as a control boundary.

Typography: retain Fraunces for the short page title or scene title; use a readable sans serif at approximately 15–16px for controls, status, and participant labels; use monospace for versions, event IDs, coordinates, and precision diagnostics. Keep mathematical labels large enough to read without canvas enlargement. Do not put essential paragraphs into the rendering surface.

## Exact desktop composition

At a reference width of 1440px, use a compact 56–64px global header and approximately 24–32px page margins. The first main row identifies the selected practice, its simulation status, current proposal version, and view lens. The stage and inspector sit directly beneath.

Use approximately two-thirds of the usable width for the stage and one-third for the current decision inspector, with the inspector normally 340–380px wide and a 20–24px gap. Size the stage to its subject: approximately 480–620px high on a roomy desktop, adapting for smaller heights. Reserve enough room for the selected state and next action to remain visible without scrolling through diagnostics.

The stage itself has five ordered layers:

1. **Quiet environment:** twilight gradient and a restrained faceted/voxel workshop plinth. Decorative assets neither change meaning nor obstruct interaction.
2. **Possibility space:** a faint upper canopy carrying at most the few current alternatives that can be meaningfully inspected. Avoid a cloud of anonymous particles that pretends to represent ideas.
3. **Current agreement space:** the largest luminous toroidal form at the center, carrying the current proposal/version plate and explicit agreement state. It is a symbolic decision scene, labeled accordingly.
4. **Participant and requirement layer:** stable, named participant nodes arranged around the current proposal; requirements are a distinct rail beside the central form, not anonymous extra participants. Edges have defined meanings and interaction targets.
5. **Annotation and history layer:** readable labels, selected-object highlight, current-state summary, and a shallow lower shelf/ribbon of actual recorded events. The lower area represents retained history and release of forms; people do not sink into it when they refuse.

Place the proposal and its current status near the visual center. Use short titles in the scene and the full proposal in the inspector. Keep participant labels anchored at stable screen positions for the default fitted view. Routing edges may bend to avoid overlap; identities must not jump around after each response.

At 3–4 seats, show every participant by name. For a future larger scope, offer an explicit list with filtering and selection; do not hide a blocking participant behind an unexplained aggregated count. Layout decisions for more seats require real supported use cases, not speculative engine work.

The inspector begins with: `Current proposal · v2`, full proposal text, `Paused — Bea withdrew`, and the next permitted step with its reason. A checklist shows evidence/test, authority, safety, and exact-version participant responses separately. The bottom ribbon is an event navigator, with `Now` clearly distinguished from a selected historical event. A small summary such as `2 of 3 current responses are Yes` may accompany named seats; it is never labeled “67% consent” or “67% complete.”

## State-to-visual contract

These are proposed semantic treatments. Implementation must map them to the repository's actual state names and rules; it must not invent protocol states merely to satisfy an animation.

| Meaning | Scene treatment | Plain status / action |
|---|---|---|
| Draft or proposed, no agreement | Warm outlined central plate; open, quiet agreement ring; participants remain visible with unset response glyphs. | `Proposal v1 — awaiting review`; show the next missing requirement. |
| Some review requirements satisfied | Separate requirement badges gain checks one at a time. No central agreement seal yet. | `Safety checked; authority still needed`, based on actual evidence. |
| A participant has not responded | Stable node, open-circle glyph, neutral border and explicit `No response`. | Select to inspect the current proposal response requirement. |
| Exact-version yes | Stable node with check and `Yes · v2`; the relevant response edge becomes solid. | Show who recorded the response and its version when available. |
| Explicit no | Same-sized node with stop/hold glyph and `No · v2`; response edge terminates at a clear hold marker. | Explain the recorded response without blame or a penalty animation. |
| Prerequisites fulfilled, not committed | All requirement badges show their facts; central plate reads `Ready to commit`. Ring remains visibly unsealed. | Explicit `Commit proposal v2` is available if the actual model allows it. |
| Current valid agreement | Ring obtains one clear double-outline/seal treatment, labeled `Agreement v2`. | The model's next permitted action is visible; animation does not commit on behalf of humans. |
| Simulated action recorded | One bounded packet moves along a defined outgoing action path, then becomes a dated event marker. | `Simulated action recorded`; do not keep implying work is ongoing after the event. |
| Participant withdraws / action paused | Participant remains present; their current response edge opens at a withdrawal glyph. The central state changes immediately to `Paused`. | `Bea withdrew — agree a response to prior consequences`; show actual next options. |
| Repair required | A distinct side branch links the affected agreement/event to the repair item. Current state remains readable. | `Repair discussion needed`; no cartoon explosion or collapse. |
| Replacement proposal | New version plate appears; prior version moves to a compact history marker. Current responses visibly become whichever states the real model dictates. | `Proposal changed to v3 — review current responses`; never visually carry old consent forward. |
| Release / retire | Current form contracts gently into a retained-history tile; no history deletion or participant disappearance. | `Retired — history retained`; show any residual obligations from the model. |
| Historical replay | Scene carries an unmistakable `History · event 08 · v2` label and different enclosing frame. | `Return to now`; protocol-changing actions are unavailable in history mode. |
| Loading / unknown state | Stable neutral scaffold, explicit loading or unknown marker; do not display an all-green agreement. | Explain what is loading and preserve a text fallback where possible. |
| Offline / stale synchronization | Freeze claims at the last confirmed state; subtle hatch/frame and timestamp or event marker. | `Showing last confirmed state`; distinguish local simulation from a real synchronized mode. |
| Error | Solid readable error surface and retained last-known scene where safe. | Explain the failed operation and recovery. Do not mark a person as the error. |

The stage must be able to answer: What are we deciding? Which version? Who is involved? What has each person said? What is holding this up? What happened most recently? What can I do next? The correct answers should not depend on understanding a torus.

## Motion vocabulary

Motion is an explanation of a recorded change. It must not fabricate agreement, evidence, activity, or authority.

| Trigger | Proposed animation | Safeguard |
|---|---|---|
| Hover or keyboard selection | 120–180ms outline/label emphasis; edge isolation may dim irrelevant decorative edges. | Identical information available through focus and click; no hover-only content. |
| Recorded state change | 180–300ms treatment change on affected object, followed by stable state. | Text and control availability update immediately from state, independently of animation completion. |
| Proposal replacement | 300–450ms current plate/history transition and explicitly labeled response re-review. | Never move a participant's node or reuse an old yes marker as a new-version yes. |
| Recorded action event | One 400–700ms traversal to its event marker. | Do not replay on rerender, resize, or camera movement. |
| Withdrawal | Response edge opens once; pause and repair text appear immediately. | No explosion, falling avatar, alarm loop, or visible social punishment. |
| Retirement | Form becomes a history tile with a short fade/scale sequence. | History remains reachable; low-motion equivalent uses a direct state change. |
| View-lens change | Brief crossfade of explanatory representations; preserve selected scope and state. | Never morph a symbolic structure into exact geometry in a way that asserts mathematical equivalence. |
| Camera input | Direct spatial response with a stable reset control. | Camera operations cannot mutate protocol or participant state. |

Default to a stationary, beautifully composed scene. If an ambient drift is used at all, make it extremely subtle, optional, paused during inspection, and absent in reduced-motion mode. Do not use constant orbiting to imply progress. Do not use a pulsing green ring to imply health unless it represents a defined and observable fact.

## Interaction aesthetics and functional affordances

Make scene objects inspectable. Clicking or keyboard-selecting a participant, requirement, proposal, or event opens the corresponding structured details in the inspector and emphasizes its related paths. The rest of the scene stays in place. Always provide a conventional HTML equivalent list so the scene is not the sole interaction mechanism.

Use one primary action at a time in the inspector. Its copy includes the relevant version when a version matters. Put secondary operations below it. Separate geometry exploration controls from decision controls. A camera toolbar can offer Fit, Rotate, Zoom, and Reset only if each actually works; never use decorative controls as proof of capability.

Use a proper persistent segmented control for `Decision process` and `Hopf geometry`. The selected lens retains its filled or clearly underlined treatment after focus moves. Keyboard focus uses an additional contrasting outline. `History` is a temporal state with a prominent Now control, not an obscure third lens that silently freezes live work.

The numerical geometry controls remain available in the geometry inspector, with accurate names and explanations. The process view can offer `Why this picture?` to explain the metaphor and the separation from authority. The full doctrine need not be repeated as long caveat paragraphs under every object; the boundary should be visible at the relevant points and truthful in actual behavior.

### Mathematical geometry lens

Keep a large, correctly proportioned scientific drawing. Use three line classes: faint context structures, medium-weight selected charts/surfaces, and a bright inspected fiber or path. Show a small number of labeled selected objects prominently; use a reveal/show-all control for dense context. Label exact objects outside the drawing with leaders or structured legend rows.

Allow selection to isolate a chart, fiber, torus, or path only where the current renderer/model supports it. If a projected object is clipped or discontinuous near a projection singularity, explain it accurately rather than smoothing it into a false closed curve. Preserve existing diagnostics and mathematical checks. The visual designer's process-ring treatment must not change topological linking or normalization.

Keep any symbolic meaning of geometry explicitly separate from actual mathematical properties. A named person's consent strand in the process scene is a UI convention; it is not asserted to be that person's literal Hopf fiber. A satisfying-looking ring is not an agreement predicate.

## Responsive centerpiece

At smaller desktop and tablet widths, preserve useful stage size and move the inspector below the stage before squeezing either into an unusable column. At narrow widths, show a fitted simplified projection with the current proposal, current status, and named participant summary. Full controls and long descriptions live in an ordinary scrolling panel immediately below.

For phones, preserve the centerpiece without forcing a huge 3D canvas above all useful information: compact scope/status row, stage around 300–380px high as content allows, selected-item inspector, next action, then event history. Essential labels remain legible instead of shrinking with the entire drawing. A list view represents the same state and actions.

Avoid hover requirements, tiny node targets, an overlay that hides the selected object, body scrolling trapped by camera gestures, or a horizontally scrolling progress ribbon as the only route to an event. Include a deliberate `Interact with scene` mode only if necessary for touch camera control; ordinary page scrolling should remain predictable.

At 200% zoom and narrow reflow, the text/inspector becomes primary and the drawing remains available. Test actual 320, 390, 768, 1024, and 1440px layouts; supported landscape and reduced-motion states; long names and proposals; and keyboard-only selection. These are requested implementation gates, not tests performed in this review.

## Implementation priorities

1. Fix renderer dimensions and establish a state-to-scene view model with explicit scope/version. Render the same facts in HTML before styling the scene.
2. Promote the Visualizer into the main layout and establish current proposal, state, next action, and history hierarchy.
3. Build one complete process path: initial proposal → review/current responses → commitment → action → withdrawal → repair → retained history, using actual model states and simulated fixture data where appropriate.
4. Add stable participant selection, blocker inspection, event navigation, and faithful historical replay.
5. Apply the art direction, line hierarchy, semantic motion, responsive layouts, and accessible alternatives.
6. Refine the exact geometry lens independently, preserving its mathematical tests and inspecting rendering accuracy.

A static screenshot of a beautiful ring is not completion. The scene must change correctly through the uncomfortable states as well as the successful ones.

## Four independent visual verification loops per feature

Treat each meaningful capability above as a feature and reconcile with the repository inventory. Every feature receives all four loops; do not substitute four reviews of the overall landing page. Each loop is implement/review → independent verification → revise findings, with independent re-verification of the final fourth revision. A no-change revision is acceptable only when the verifier records no actionable defect and the evidence supports it.

| Loop | Independent review task | Evidence and acceptance |
|---|---|---|
| 1 — Meaning and composition | A reviewer who did not build the feature inspects the initial state and its main transition. Ask them to identify current proposal/version, state, relevant people, blocker, and next action from the UI. | Screenshots plus actual interaction, selected version/state captured, misunderstood labels or misleading visual claims logged and revised. This is an expert interpretation check, not a claim of a real novice study. |
| 2 — Difficult states | Exercise no response, no, withdrawal, replacement, old consent, repair, retirement, and history as applicable. Compare scene and text with the authoritative model/fixture. | Every semantic treatment matches its state; people retain stable identities; no false agreement, false progress, erased history, or animation-triggered mutation. |
| 3 — Access, reflow, motion | Independently inspect keyboard/focus, touch targets, text alternatives, actual contrast, reduced motion, zoom, responsive widths, long content, and low-rendering fallback. | Essential meaning survives color removal and motion removal; labels/controls remain usable; geometry preserves intended proportions. Record browser/device and limits. |
| 4 — Whole-story coherence | A fresh verifier replays the complete decision/withdrawal/repair story, swaps views, selects history and returns to now, resizes, and repeats the relevant transitions. | No duplicated event animation, state leakage between tables, stale historical actions, selected-state ambiguity, or new regressions. Revise every remaining issue, then independently verify those revisions against the same build. |

For every cycle keep feature ID, build/commit, reviewer identity, tested environment, exact steps, observed state, screenshot or recording where useful, finding, revision, and retest outcome. Four loops are a minimum, not permission to close unresolved material findings.

## Brief for a reviewable concept prototype

A standalone interactive HTML/SVG concept can communicate this direction before repository work. It should say `Concept · simulated example` permanently. Use the dark palette, large central luminous ring, three stable named seats, a gate inspector, version label, event ribbon, and scenario buttons for `Needs review`, `Ready`, `Agreement`, `Paused`, and `Retired`. Show a selected participant and the reason for a pause. Demonstrate changing a proposal version and resetting current response indicators. Make all scenario controls keyboard-accessible and support reduced motion.

Any SVG curves in that concept are symbolic design graphics. Label them `Decision process metaphor`; do not present them as an independently verified Hopf bundle. The concept need not include Joe if the approved pose assets are not available. A small faceted plinth and restrained cloud-world color cues can establish continuity without inventing a Joe lookalike.

The concept is an executable design illustration. It is not production integration, mathematical proof, real consent, real participants, or a completed four-loop implementation.
