# Hopf Workshop — five independent expert reviews and implementation direction

Prepared for Paul Cooper · 15 September 2026  
Live site: [Hopf Workshop](https://hopf-workshop.vercel.app/)

## The main finding

The workshop has a strong idea and several useful safeguards already working. Its interface makes visitors learn the machinery before they experience the lesson. The most valuable next step is to make the existing behavior understandable through a short guided activity, while repairing the specific accessibility, drawing and state-reporting problems found in this review.

Five separate agents inspected the actual website from different perspectives. They used their own browser tabs and wrote independent reports. Their findings converged on the same direction: **give a newcomer one clear task, show the result of each action, keep the two simulations distinct, and make the advanced mathematics available in a separate depth of explanation.**

This deliverable is a review and an implementation prompt. The site has not been rebuilt or deployed in this task. The four-loop workflow is a requirement for the future implementation agent; those implementation loops have not been performed here.

## What the team actually inspected

| Reviewer | Direct inspection | Principal contribution |
|---|---|---|
| Clarity and information architecture | Entrance, navigation, four-seat actions, drawing choice, dragon demonstration, repair, Explore | Eight findings about first use, terminology, action order, state visibility and recovery |
| Visual design | Desktop screenshots, layout and typography measurements, canvas proportions, image crop, selected-button appearance | Ten findings about attention, task width, drawing fidelity and visual hierarchy |
| Accessibility | Keyboard activation and focus, DOM semantics, labels, computed colors, status announcements, sliders | Ten findings, including reproduced keyboard focus loss and measured contrast failures |
| Reliability | Successful and blocked paths in both simulations, replacement, withdrawal, repair, retirement, RETURN and reload | Six findings about version attribution, reviews, outcomes, inspectable state and session behavior |
| Learning and mathematical explanation | Drawing modes, reframe, linking, holonomy, theta, Explore, dragon demonstration and repair | Eight findings about lesson sequence, explanations, numerical interpretation and provenance |

The five reports contain **42 specialist findings**, including overlaps. The synthesis below groups those into a smaller implementation agenda. Agents represent expert perspectives; this was not a human participant study or independent professional certification.

The parent reviewer also inspected the live entrance and the demonstration → repair → blocked-action sequence, and read the matching repository's README, integration contract, discipline rules, learning-packet contract, implementation plan, package scripts, Vercel route configuration and historical verification record. Repository `main` was observed at `cf8326aa497c490dd074db2c98c2224a6175435f`. The deployed source commit was not established, and the repository's executable test suite was not run during this review.

The browser work was desktop-based. Actual phone devices, the full responsive width matrix, screen-reader speech, multiple browser engines, performance under load, complete mathematical correctness and Python/JavaScript parity remain unverified here. The historical repository report describes earlier mobile and automated checks; those are not new results from this team.

## What is worth keeping

The cardboard-dragon scenario is an effective starting point. It gives people a concrete project, a proposed route, named participants, and a reason to care when plans change. The workshop's sky, cabin and voxel character make the setting recognizable. There is no need to discard that identity to make the interface simpler.

More importantly, the inspected workflows already demonstrate the distinctions the workshop is trying to teach:

| Exercised situation | Observed behavior | Why it matters |
|---|---|---|
| Four people marked Ready; review recorded; consent missing | Commitment remained blocked | Being ready did not count as agreeing |
| All required readiness; Close round | Entered COORDINATE without a commitment | Round closure did not manufacture agreement |
| Begin ACT before commitment | Blocked | A phase transition did not substitute for permission |
| Explicit simulated consent and commitment, then ACT | Simulated action became available | There was a meaningful permitted path |
| One recorded outcome, then RETURN | Entered round 2; one outcome applied | The return operation carried learning into another round |
| RETURN immediately repeated | Blocked; round and applied count unchanged | The same pending result was not applied twice in this sequence |
| Dragon demonstration; Bea withdrew | Further action was blocked | Withdrawal had an operative consequence |
| Repair recorded after withdrawal | Repair blocker disappeared; consent remained missing | Addressing consequences did not make Bea agree again |
| Release / retire, then Act | Action blocked | Retirement did not leave an apparently usable agreement |

These are bounded observations. They support preserving the existing behavior; they do not establish that every possible sequence is correct or that the application is an authenticated real-world authority system.

## The most important changes

### 1. Give the entrance a concrete purpose and one starting action

The opening is attractive, but the first interactive section is a four-seat practice table calling itself a “second” simulation before the visitor has seen the three-person lesson. It introduces Ready, Yes, review flags, Commit, Close round, ACT and RETURN at once. An inspected page had 38 buttons, four sliders and three checkboxes. Those counts are not inherently wrong; the problem is that they appear before a clear task and learning path.

Suggested opening:

> Help a small crew make a plan they can trust. Try an idea, check it, ask each person, and see what happens when someone needs to stop. Then explore the geometry behind the workshop.

The primary action should start the guided practice. Free practice and the geometry lab should remain directly available. A short, plain simulation notice can explain that the learner controls fictional characters and that these choices do not record real people's consent.

Keep the three-person dragon lesson and the four-seat round rehearsal as distinct activities. The first teaches proposals, agreements, action, withdrawal and repair. The second adds readiness, coordination phases, outcomes and RETURN. The same character names can remain, provided the active scenario and its state are unmistakable.

### 2. Turn the dragon demonstration into a sequence people can follow

The current demonstration runs through the whole story immediately and ends PAUSED. It has actually shown a successful agreement, simulated action, withdrawal and a correctly blocked further action. The visitor has to reconstruct that story from ledger entries.

A learner-paced sequence would make this existing behavior useful. Introduce the problem, ask a prediction, let the learner perform one action, show the result, and explain it before moving on. After withdrawal, say that the safeguard worked. After repair, explain that the response to earlier consequences was recorded but consent was not restored.

Provide replay and a deliberate fresh attempt, with their effects stated. If the lesson has a Back control, it should revisit an explanation or replay a clearly identified demonstration state; it must not rewrite the authoritative event history to make the story look tidy. A refusal or decision to stop should remain a legitimate learning outcome, not a wrong answer that prevents completion.

The learning reviewer proposed a roughly four-minute script as a design starting point. Its duration has not been validated and should not become a promise on the homepage until timed against the implemented lesson.

### 3. Repair keyboard focus before declaring the experience easy to use

The accessibility reviewer reproduced a concrete failure: activating “Maya ready” or “Maya yes” in the four-seat table, and the first “Yes” in the Parade table, dropped focus to the page body. After the readiness action, the next Tab returned to the first seat control.

That makes the central activity unnecessarily difficult for keyboard users. Keep the control's identity stable across updates, or restore focus to the logically equivalent control. Test every actor and applicable Yes, No, Ready and Withdraw action, including later proposal and round states. The required result is observable: the user stays in place, sees a focus indicator and can move to the expected next control. This follows W3C's guidance on predictable focus order. [W3C: Focus Order](https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html).

### 4. Make text, focus and selection clearly visible

Some enabled labels are too faint. The accessibility reviewer calculated contrast intervals using the inspected foreground colors and the panel's alpha-composited gradient backgrounds. Green Act/RETURN text was about 2.18–2.27:1; cyan labels about 1.77–1.84:1; small red action text about 3.84–3.99:1. These are below the 4.5:1 normal-text target. The yellow focus outline was about 1.46–1.52:1 against the adjacent panel. These are bounded CSS calculations, not an exhaustive pixel audit of every state. [W3C: Contrast Minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html), [W3C: Non-text Contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html).

Retain the bright colors as accents and use darker text and focus tokens. Do not make refusal look like a user error merely because it uses red. Separate persistent selection from transient keyboard focus: after focus moved away, the visual reviewer found the two geometry buttons looked the same even though Bundle map was pressed.

Most buttons already have generous height. Preserve that advantage. Improve the 13px monospace action labels and reserve monospace for values, identifiers and technical records.

### 5. Preserve the proportions of the geometry

The visual reviewer measured a canvas with a 900×520 backing size displayed at approximately 838×233 in one desktop state. The aspect ratios differ substantially, and the screenshot showed shallow forms and tiny internal labels. Source-level renderer compensation was not inspected, so this establishes a sizing mismatch and a visible concern rather than a mathematical proof that every plotted shape is wrong.

The implementation should inspect the renderer and use a consistent responsive sizing model. Preserve the intended geometric projection, reconcile CSS and backing-store dimensions, handle device pixel ratio, and put essential explanatory labels in readable HTML outside the drawing. Test the actual appearance at narrow and wide sizes; simply making the canvas fit a box is insufficient.

### 6. Show the proposed version and the active agreement separately

This is the most important reliability finding to interpret carefully. The reliability reviewer committed v1 of the bridge plan, then proposed v2 of an orchard plan. The interface displayed ACTIVE beside the new v2 proposal and missing consent/review for that proposal. Pressing Act still performed the old bridge action, recorded with a v2 event prefix.

The repository explicitly says that a new proposal should not erase an existing active agreement. Continuing the old agreement may therefore be correct. **The observed problem is ambiguous state and event attribution, not demonstrated execution of the unconsented orchard plan.**

Show a current proposal card and a separate active agreement card. Name the agreement and version that Act will use. If an event carries both current proposal context and executed agreement identity, show both distinctly. Preserve the old agreement's valid behavior while making the new draft's missing consent visible.

Relatedly, the three review checkboxes remained checked after replacement even while the new version's recorded review was missing. They appear to be editable draft inputs, but look like completed requirements. Either clear them for the new draft or label them explicitly as unrecorded inputs. The learner should never have to infer why a checked box and a “missing” message coexist.

### 7. Make outcomes match the action they describe

The four-seat successful cycle committed “Carry the cardboard dragon over the bridge,” then “Record Maya's outcome” produced “Maya: completed — checked orchard walk.” No action had changed that table's proposal to the orchard.

Bind outcome wording and identity to the actual participant, round and committed agreement. A contrary outcome can be valid evidence in a learning system, but then the UI must explain that it contradicts the plan. It should not appear as ordinary successful completion of a different route. Test underlying attribution as well as the sentence on screen.

### 8. Give every action a readable result and the next useful step

The four-seat overview reports Round, Ready and Last RETURN, but does not prominently show each seat's consent to a version or the active agreement. Its visible log shows only the latest six events. The underlying full history was not inspected; the problem is that a visitor cannot inspect the entire retained sequence through the current visible surface.

Use participant rows showing readiness and consent separately. Put action-specific reasons beside the action: a failed Close round should explain missing readiness, while a failed Commit should explain its own prerequisites. Offer a full accessible history in an expandable detail view.

The four-seat updates and linking recomputation lack a dedicated programmatic status announcement in the inspected DOM. The Parade ledger already has a polite live region. Give each independent activity a concise announcement channel; preserve the ledger as navigable history without repeatedly announcing the whole log. Actual screen-reader speech must be verified during implementation. [W3C: Status Messages](https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html).

### 9. Give the active task enough room

At approximately 1363×936, the visual reviewer measured the geometry panel at about 897px wide and the Parade table at 377px. Both stretched to about 1570px high. The result was a crowded proposal/consent/repair column beside a large unused lower area. Geometry began below the initial viewport after the large four-seat section.

Give the selected activity the main workspace. Use independent panel heights and minimum readable widths rather than a rigid large-graphic/small-controls split. Put the current instruction, action and feedback together. On narrow screens, stack them in a coherent order and keep expert details optional.

The hero image also loses important parts of its composition, including the top of Joe's hat, in the observed shallow crop. Choose an intentional scene crop or a compact complete guide pose. The reviewers did not independently establish the art's canonical provenance; preserve the existing source and verify approved assets before replacing Joe.

### 10. Teach what each geometric operation changes and preserves

The lab exposes interesting operations, but the expected observation is not explained. Reframe records that common phase changed while proposal and permission did not. Carry records a lift change in radians. Explore synchronizes display and protocol coordinates. The numerical readouts include holonomy, Chern integral, linking and a tiny residual.

Each operation needs an understandable before/after explanation. Keep the mathematical definitions precise and available: parameters, units, methods, expected results, tolerances and sign conventions. Do not call every slider a literal camera movement without checking its model meaning. Do not substitute a familiar integer for independent verification of a numerical method.

The diagram's text equivalent should explain relevant relationships and current changes, not only list the objects pictured. Provide a “How this model works” route to the rules, mathematical explanation and versioned verification context. The source repository is private; publication of source material must be intentional, and public explanatory pages should contain appropriate workshop content rather than indiscriminately exposing repository documents.

### 11. Define fresh attempts, RETURN and reload as different things

The reliability reviewer completed practice, reloaded, and saw both tables return to their initial state with only the initial proposal visible. That can be acceptable for a temporary simulation. The site does not clearly state this session policy or offer an obvious on-page fresh attempt.

Choose and explain the intended contract. A deliberate fresh attempt can create a new practice session; replay can demonstrate a known story; RETURN must retain its domain meaning. If local save/resume is added, validate stored versions and ensure paused or retired agreements cannot return as active. A backend or cross-device system is not necessary merely to explain an intentionally temporary workshop.

### 12. Reconcile the planned default with the live default

The live page started on Hourglass / process. The inspected `docs/DISCIPLINE.md` and B0 implementation plan say Bundle map should be the default. This is a confirmed live/documentation discrepancy. It does not by itself prove whether the source, plan, tests or deployment is responsible.

The implementation agent should compare the current source and deployment, reproduce the default in a fresh session and settle the discrepancy explicitly. The process drawing may remain useful as a clearly labeled metaphor. It must stay distinguishable from the exact topology view.

## Recommended structure

| Experience | What the visitor gets | What remains available |
|---|---|---|
| Entrance | Practical purpose, simulation context, one primary start action | Direct links to free practice and geometry |
| Guided dragon practice | One step at a time: idea, review, consent, action, withdrawal, repair, debrief | Inspectable versions and event history |
| Free practice | Full three-person controls with clear state and recovery | All existing proposal, review, consent, repair and release behavior |
| Four-seat round rehearsal | Distinct activity teaching Ready, COORDINATE, agreement, ACT, outcome and RETURN | Every seat's state, action-specific blockers and full session history |
| Geometry lab | Correctly proportioned drawing and focused observations | Complete parameters, calculations, methods and mathematical detail |
| How the model works | Plain rules, definitions, scope and honest verification context | Appropriate versioned sources and advanced explanations |

The recommendation is to reorganize access and explanation, not to remove existing capabilities. Keep direct expert access, preserve both separate simulations and use the real protocol for the guided lesson.

## Implementation priorities and traceability

P1 means address before accepting the revised core experience. P2 means necessary product improvement, with exact severity depending on the intended contract. No critical security breach was established in this review.

| Work package | Priority | Specialist findings it resolves |
|---|---|---|
| Keyboard focus and visible focus | P1 | A11Y-01, A11Y-03 |
| Contrast, action hierarchy, persistent selection | P1 | A11Y-02; V-04, V-05, V-06 |
| Geometry proportions and label readability | P1 | V-01; A11Y-08; LEARN-07 |
| Active agreement, proposal and event attribution | P1 | QA-01; C4; LEARN-06 |
| Entrance, navigation and activity separation | P1 | C1, C2, C5; V-02, V-03, V-08; A11Y-09; LEARN-01, LEARN-02 |
| Guided demo and repair explanation | P1 | C3; LEARN-03, LEARN-04 |
| Review evidence and version presentation | P2 | C6; QA-02 |
| Outcome attribution and round guidance | P2 | QA-03, QA-05; C4; V-09 |
| Full history, participant state and announcements | P1/P2 | QA-04; C4; A11Y-04, A11Y-05 |
| Coherent drawing controls, slider units and explanations | P2 | C7; A11Y-06, A11Y-07, A11Y-08; LEARN-05, LEARN-06, LEARN-07 |
| Responsive layout, art framing and touch verification | P2 | V-03, V-07, V-10; A11Y-10 |
| Restart/reload policy and recovery | P2 | C8; QA-06 |
| Provenance and documented default | P2 | LEARN-08; root repository/live comparison |

Several findings belong to more than one work package. Each original reviewer report retains its own evidence, reproductions, acceptance criteria and limitations.

## How the implementation prompt enforces the four loops

The companion prompt contains a 46-feature seed inventory spanning the entrance, guided lesson, both simulations, every geometry operation, accessibility, history, parity, integration compatibility and provenance. The implementation agent must expand it for independently testable child features and any current capability not already represented. Forty-six seeds imply at least 184 feature loops before expansion; these are not 184 feature implementations or a completed test count.

For each feature, the required sequence is:

1. Implement and run builder checks.
2. Independent review 1 → respond/revise → independent check of that response.
3. Independent review 2 → respond/revise → independent check of that response.
4. Independent review 3 → respond/revise → independent check of that response.
5. Independent review 4 → respond/revise → independent check of the fourth response.
6. Confirm acceptance still applies to the final integrated candidate.

The initial implementation does not count as a loop. Each feature needs separate evidence for all four loops, with author and verifier identities, candidate hashes, findings, revisions and closure. At least two independent verifiers must contribute across its cycles. A final whole-site review is additional.

If a verifier finds nothing to fix, the prompt requires an explicit evidence-backed response and a fresh relevant challenge; it forbids inventing bugs or making pointless edits just to increase the count. A late shared change reopens affected acceptance. Missing evidence, unavailable required tests and self-approval cannot be marked as passes.

The prompt also preserves the existing Python reference model, JavaScript parity, version-bound consent, agreement retention, withdrawal and repair distinctions, RETURN behavior and `hopf-weopoly-learning/v1` practice contract. It confines the work to the workshop and existing compatibility seams. It does not turn this design task into an unbounded rebuild of WeOpoly, Joeville or the wider portfolio.

## Source and evidence notes

Primary evidence is the live website observed on September 15 and the five separately authored reports supplied with this package. Source documentation was inspected through the connected repository, not inferred from filenames alone:

- [Repository README](https://github.com/jedisherpa/hopf-workshop/blob/cf8326aa497c490dd074db2c98c2224a6175435f/README.md): purpose, mathematical interpretation, model invariants and run instructions.
- [Integration contract](https://github.com/jedisherpa/hopf-workshop/blob/cf8326aa497c490dd074db2c98c2224a6175435f/INTEGRATION.md): separate sequencing, permission, simulated seats and RETURN semantics.
- [Discipline rules](https://github.com/jedisherpa/hopf-workshop/blob/cf8326aa497c490dd074db2c98c2224a6175435f/docs/DISCIPLINE.md): display/protocol distinctions, invariants and planned bundle default.
- [Current implementation plan](https://github.com/jedisherpa/hopf-workshop/blob/cf8326aa497c490dd074db2c98c2224a6175435f/plans/B04-B06-week1-learning-cohort.md): boundaries, Week 1 Mission 1 anchor and separation of current/future work.
- [Learning-packet contract](https://github.com/jedisherpa/hopf-workshop/blob/cf8326aa497c490dd074db2c98c2224a6175435f/docs/LEARNING_PACKET.md): simulated practice and validation requirements.
- [Historical verification record](https://github.com/jedisherpa/hopf-workshop/blob/cf8326aa497c490dd074db2c98c2224a6175435f/VERIFICATION.md): earlier claimed test results, explicitly not rerun for this audit.

These repository links require authorized access because the repository is private. No credentials or private access URLs are included. Implementation should re-resolve current source and deployed identities before changing the application.

The accessibility recommendations use primary W3C guidance. The implementation should verify [reflow](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html), [target size](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html), coherent [tabs](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/) or an appropriate simpler pattern, and meaningful [complex-image alternatives](https://www.w3.org/WAI/tutorials/images/complex/). Responsive declarations and automated scores alone will not establish that a person can complete the workshop.
