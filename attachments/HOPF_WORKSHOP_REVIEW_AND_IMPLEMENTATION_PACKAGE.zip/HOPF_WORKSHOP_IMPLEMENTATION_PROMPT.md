# Hopf Workshop — implementation and independent verification prompt

Prepared for Paul Cooper · 15 September 2026

Copy this whole document into the coding agent working on `jedisherpa/hopf-workshop`. Attach `HOPF_WORKSHOP_EXPERT_REVIEW.md` and the five specialist reviews when available. This prompt is self-contained enough to begin if those attachments are absent; record missing evidence and inspect the current site yourself.

## 1. Outcome and central question

Implement a clear, attractive, accessible, functionally reliable Hopf Workshop at `https://hopf-workshop.vercel.app/`. A curious newcomer should understand what the workshop is for, know where to start, complete a short meaningful practice, see why an action succeeds or stops, and choose whether to explore the mathematics in greater depth. An experienced visitor should still reach the full geometry lab and both practice simulations quickly.

Central question: **Can someone use the workshop to distinguish an idea, a person's readiness, explicit consent to an exact proposal, an active agreement, action, withdrawal, repair, and retained learning—without needing to understand the code or advanced topology first?**

Do the implementation, use the running interface, commission genuinely independent verification, revise against findings, and independently verify the revisions. Complete **at least four full verification-and-revision loops for every feature**. Four reviews of the whole site do not satisfy this requirement. Four agents looking at one unchanged screenshot do not satisfy it. The fourth revision must receive its own independent verification.

This is an execution prompt. Continue through implementation and reviewable delivery; do not stop at another plan. Preserve the product's purpose and existing mathematical and protocol distinctions.

## 2. Team and independence

Use actual separate agents if the environment supports them. Roles are responsibilities, not claims to professional accreditation or human participation.

| Role | Responsibility | Independence rule |
|---|---|---|
| Integrator / product lead | Discover scope; maintain feature inventory, dependency map, issues, evidence and integration branch | Cannot substitute personal confidence for independent acceptance |
| Experience designer and writer | First-use journey, plain-language explanations, navigation, progressive disclosure, guided lesson | Cannot sign off their own design or copy |
| Visual and accessibility implementer | Layout, typography, colors, canonical art, responsive behavior, focus and semantics | Cannot verify their own affected features |
| Protocol / geometry engineer | Preserve normative Python, JavaScript parity, versioned agreements, display separation and computations | Cannot independently certify changes they authored |
| Independent usability / accessibility verifier | Use the running site from acceptance criteria; inspect screens and keyboard behavior | Does not edit feature implementation while verifying it |
| Independent reliability / mathematical verifier | Test valid and invalid sequences, state transitions, parity and numerical claims | Derives expectations from contracts and math, not only implementation output |
| Final integration reviewer | Test the assembled candidate and challenge unresolved claims | Has not authored the final integrated changes under review |

Combine compatible implementation responsibilities when agent limits require it. Preserve the author/verifier separation for each feature and revision. Sequence independent work when parallelism is unavailable. A verifier who supplies a code patch becomes an author of that patch; assign a different verifier to accept it. Rotate independent perspectives across loops. At least two different independent verifiers must contribute to each feature across its four loops.

Verifiers first receive the feature contract, relevant source rules, candidate identity and user tasks. They should attempt the task before reading the builder's claimed success narrative. Then inspect the patch and test evidence. They must be able to reject a feature. The builder cannot change a FAIL to PASS or erase the failed record.

Use isolated worktrees or branches and bounded file ownership. Do not run competing editors in the same working tree. Freeze a candidate while it is being verified. Independent verification means a separate execution context and a real tool-backed inspection, not a renamed section in one agent's self-review. If the environment cannot supply independent agents or reviewers, complete useful implementation and self-tests, record `INDEPENDENT_VERIFICATION_BLOCKED`, and do not claim the four-loop requirement is complete.

## 3. Establish the actual source baseline

Confirm the repository, remote, branch, dirty state, current commit and deployment mapping before changing files. Preserve unrelated work. Inspect applicable `AGENTS.md` and relevant available skills. Use the supported browser skill for actual browser interaction; a terminal build is insufficient evidence of usability. Do not assume Next.js, React, a database, authentication, or a framework migration is needed.

The review found a small static HTML/JavaScript teaching application with a Python reference model. On 15 September 2026, repository `main` was observed at `cf8326aa497c490dd074db2c98c2224a6175435f`. The live deployment's source SHA was **not established**. Re-resolve both before treating findings as current.

Read, in this order, the user's current instructions; applicable repository instructions; the normative contracts/model and their authoritative explanations; existing test expectations checked against those contracts; current implementation; current plans and verification records; and this review's observations. Record contradictions instead of silently treating live behavior or stale tests as intended behavior.

Confirmed repository entry points to inspect:

- `README.md`, `INTEGRATION.md`, `docs/DISCIPLINE.md`, `docs/LEARNING_PACKET.md`, `plans/B04-B06-week1-learning-cohort.md`, `VERIFICATION.md`.
- `hopf_model.py`, `hopf.js`, `weopoly_hopf.py`, `weopoly_hopf.js`, `learning_packet.py`, `learning_packet.js`, `workshop.html`.
- `package.json`, lockfile, `vercel.json`, `fixtures/`, `scenes/`, `docs/visual/` and all applicable tests.
- Existing geometry, protocol, parity, learning-packet, rehearsal and UI tests. Inventory any object/correct/dispose or other model features that the present UI does not expose.

The observed `vercel.json` rewrites `/` to `/workshop.html`. The observed package scripts are `npm test`, `npm run test:ui`, and `npm start`; inspect their current contents and browser requirements before executing. The observed test script runs Python unit tests, Node Hopf tests, Node rehearsal tests, Python parity, and the feature walk. It does not by itself prove every standalone test file or UI scenario is covered. Explicitly include learning-packet and browser checks as appropriate.

Historical `VERIFICATION.md` claims are historical evidence only. Re-run required gates on your candidate. Do not copy its passed counts or mobile claims into a new verification report.

## 4. Preserve these meanings

1. **Python is normative. HTML is a view. Topology does not authorize.** Keep the JavaScript port faithful to the reference; do not duplicate a competing permission engine inside UI handlers.
2. Geometric display, camera movement, reframe, confidence, suggestions, readiness, lesson progress and a completed round cannot create participant consent or institutional authority.
3. Display coordinates and protocol coordinates remain distinguishable. The existing explicit Explore operation is the point where a chosen exploratory state enters the protocol. A changed representation must not silently sign, commit, or retire anything.
4. Consent is associated with the relevant actor and exact proposal version. A new proposal does not erase an existing active agreement; action uses the committed version and its applicable stamps. Same-version invalidation must be handled according to the normative rules.
5. Withdrawal stops further participation immediately as specified. Repair addresses consequences; it does not restore someone's consent. No one has to agree to keep participating in order to have their withdrawal respected.
6. The three-person parade and four-seat rehearsal are separate simulation instances. Keep their participants, states, agreements, outcomes and logs separate unless an explicit, tested transfer is part of an approved contract.
7. In the rehearsal, PLAY, COORDINATE and ACT are phases. RETURN is a command, not a fourth phase. Closing a round and making a Hopf commitment are different operations. RETURN preserves history and applies pending outcomes once; it does not revive retired agreements.
8. These are simulated seats, not authenticated people or classmates' consent. No agent, tutorial, animation, packet, or route parameter may turn practice into real consent. **Humans attest. Agents do not ratify.**
9. Keep the process metaphor separate from the exact bundle drawing. Existing B0 planning and `docs/DISCIPLINE.md` require Bundle map as the default; the review saw Hourglass / process selected on first load. Reconcile this discrepancy explicitly. Introducing a new guided entrance must not quietly redefine the lab's required default.
10. Preserve the repository's mathematical conventions and nonclaims: numerical sampling is a check, not a proof; phase is not an entire event history; geometry does not prove ethical governance or a literal psychological/topological correspondence. Keep formulas, tolerances, sign conventions and edge-case limitations available in the advanced explanation.
11. Preserve the existing `hopf-weopoly-learning/v1` contract and `simulated=true`. The lesson anchor is Joeville Season One Week 1 Mission 1, “Name the work,” with WeOpoly `learning-community / organize`. Discover present contract tests; do not silently bump the packet schema or infer real enrollment, membership, Captain's Log attestation or TA assent from a practice packet.
12. Preserve the existing Wizard Joe art and provenance. If additional Joe assets are required, use established canonical assets from their verified source; no generated lookalike. Use exact rendered geometry for mathematical diagrams, not generated imagery. Wizard Joe may orient learners but cannot make decisions or speak consent for real people.

Keep these distinctions easy to find at the relevant decision point. Do not require every visitor to read a wall of technical disclaimers before beginning.

## 5. Scope and authorization

Implement and verify the workshop's design, teaching, accessibility, UI reliability and supporting tests/documentation in `hopf-workshop`. Keep the existing architecture unless a concrete defect warrants a bounded refactor. No framework rewrite for appearance alone.

The project has wider WeOpoly/Joeville plans. Read them to preserve seams and scope. This prompt does not authorize implementing all future roadmap work, editing other repositories, integrating real group authority, building new accounts or payments, or wiring CueBlock, TAWarRoom, BTC, Portfolio Control Room or Sovereign production services. Existing contract compatibility is in scope; new cross-repository production behavior is not.

Local edits, isolated branches, tests, local preview and a reviewable patch are part of this task. Use existing session authorization for remote commits, draft PRs and preview deployment when it applies. Do not infer permission for a production deployment or merge solely from an instruction to implement a prompt. Complete and verify the candidate before any final approval that is actually required. Do not repeatedly ask permission for routine reversible implementation or testing.

Do not transmit real personal data through the practice controls. Use clearly fictional test text. Test exceptional and invalid inputs in local/preview environments. Do not delete existing user work, rewrite shared history, weaken checks, or replace real integration behavior with fake success states.

## 6. Findings to reproduce before fixing

These are observations from the September 15 review, not a guarantee about the current deployment. Reproduce and update their status.

| ID | Observation | Required response |
|---|---|---|
| H01 | First screen presents a four-seat control bank before explaining a first task; it calls itself a “second” table before the three-person activity | Provide an understandable entrance and explicit lesson choice |
| H02 | Roughly 38 buttons, four sliders and three review checkboxes coexist; primary, secondary and blocked actions are weakly distinguished | Introduce meaningful hierarchy and phase-specific guidance while retaining advanced access |
| H03 | Participant Ready/Yes keyboard activation in the four-seat table and Yes in the parade table can drop focus to the page body; next Tab can restart at the first seat | Preserve focus and stable control identity across updates in both tables |
| H04 | Four-seat status changes lack a dedicated live announcement and per-seat current consent is hard to inspect | Provide concise live status and actor/version state |
| H05 | Canvas backing size was 900×520 while displayed at about 838×233 in one desktop observation | Preserve geometry proportions, handle device pixel ratio, and make figure labels readable |
| H06 | Existing plan requires default Bundle map; live entrance showed Hourglass / process | Reconcile required default, source, deployment and docs |
| H07 | Dragon demo rapidly appends the whole walk and ends PAUSED after withdrawal, without staged explanation or an obvious fresh-attempt control | Provide a learner-paced demo, debrief and distinct restart semantics |
| H08 | Green, cyan, yellow and small text/focus treatments show contrast concerns; geometry switch is a tablist containing ordinary pressed buttons | Measure actual contrast and correct semantics/focus, with keyboard and assistive checks |
| H09 | Committed bridge proposal can produce a canned Maya outcome mentioning a checked orchard walk | Bind outcome identity and wording to the actual committed version and scenario |
| H10 | Blocked actions are recorded, but recovery advice often appears as technical ledger text | Show what happened, why, and the next available action in plain language |
| H11 | First four-seat region, geometry region and narrow parade column produce an unusually tall page; large graphics panel stretches beside a crowded control column | Give the active task and its explanation coherent space; avoid layout-induced empty regions |
| H12 | Numerical results have little explanation of units, expected values, approximation, or what remains unchanged | Add plain-language interpretation and accurate optional technical detail |
| H13 | Both simulations have no obvious on-page reset/save policy; reload and replay expectations need explicit definition | Define fresh attempt, demo replay, RETURN, reload and history separately |
| H14 | After committing v1 bridge and proposing v2 orchard, ACTIVE appears beside v2; Act records the old bridge action with a v2 event prefix | Separate draft proposal from active agreement and record the executed agreement version unambiguously; do not cancel v1 merely to simplify the display |
| H15 | Review checkboxes remain checked after replacement while the new version's recorded review is missing | Distinguish editable review inputs from recorded version-specific evidence; reset or explicitly label retained draft values |

Strengths to retain: missing review/consent blocked the tested commitments; readiness did not count as consent; Close round could enter COORDINATE without an agreement but ACT remained blocked; withdrawal blocked action; repair did not itself restore consent; RETURN applied one pending outcome and a repeated RETURN did not apply it again. These observations are bounded checks, not a comprehensive reliability certification.

## 7. Experience to implement

Create a friendly, compact entrance with a clear practical promise and one dominant first action. Suggested wording, subject to faithful editorial improvement:

> Help a small crew make a plan they can trust. Try an idea, check it, ask each person, and see what happens when someone needs to stop. Then explore the geometry behind the workshop.

Primary action: **Start the guided practice**. Secondary choices: **Practice freely** and **Explore the geometry**. Explain once, prominently: “You control fictional practice characters. Their choices do not record anyone's real consent.” Use a time estimate only after observing the actual lesson duration.

Offer clear navigation between Guided practice, Free practice and Geometry lab. Put the three-person dragon story first for newcomers. Offer the four-seat round rehearsal as the next exercise, with its distinct purpose: readiness, agreement, action and returning with learning. Returning visitors can go directly to either simulation or the lab. State must survive ordinary view switching within a session unless the user deliberately starts a fresh attempt.

Guide learners through a short sequence: meet the crew and proposal; predict whether confidence is enough; inspect an understandable review; distinguish Ready from agreeing to a named version; make and act on an explicit simulated agreement; see withdrawal stop action; address consequences without restoring consent; review what the ledger retained. Connect geometry after this first concrete experience, while keeping a direct lab route.

Every step has one clear task, a visible result, a short explanation and a way to continue. Accept “no” and stopping as legitimate outcomes. Do not reward users for consenting or make refusal a failure. A demo may use pre-scripted fictional responses if those are clearly identified as demonstrated responses; it must not masquerade as the learner's or another person's decision.

Use plain-language labels with technical names in supporting text. Examples: “Try these coordinates” with “Explore” explained; “How sure are you?” for Belief; “Check the proposed plan” for review; “Make this agreement” with Commit in detail; “Try the agreed action” for simulated Act; “Record what happened” for an outcome; “Return to planning” with RETURN explained. Do not label RETURN “Reset” or label Ready “I agree.” A rename is acceptable only if the underlying distinction remains clear and tested.

## 8. Visual and interaction requirements

Retain the workshop's sky, ice, voxel cabin and Wizard Joe character. Improve usability through spacing, scale, contrast, typography and focus. The entrance should show the title, practical promise and start action at common laptop sizes without making the artwork a barrier. Preserve meaningful artwork framing at narrow and wide widths; never stretch it. Do not animate Joe or add audio merely to satisfy a visual redesign.

Use a readable interface font for controls and instructions, a restrained display treatment for headings, and monospace for values and technical records. Begin around 16–18 CSS px for body copy and 14–16 px for action labels, then validate in context. Use consistent spacing and measure long-form copy to avoid overly wide lines. These are design starting points, not substitutes for testing zoom and reflow.

Use one visually dominant valid next action per active step. Use secondary styling for alternatives, text-plus-symbol status for success/blocked/paused/retired, and distinct treatment for release/restart. Color alone must never identify status or actor. Avoid a large grid of equally emphasized buttons.

Normally hide irrelevant later-step controls behind progressive disclosure, without removing capability. If a blocked operation remains visible to teach a rule, deliberately present it as “Try why this is blocked” or provide an accessible explanation of its unavailable state. Domain guards still apply under every entry path. Do not fix blocked-action confusion by making invalid operations succeed.

Give every participant a coherent card or row with name, simulated identity, readiness where applicable, current consent, relevant version and action controls. Give the proposal, active agreement and pending replacement distinct visible identities. Show a compact next-step summary beside the controls; retain the full event ledger in accessible detail.

Use a correctly scaled, responsive drawing surface. Keep its logical aspect ratio consistent with the mathematics. A responsive canvas must reconcile CSS size, backing-store size and pixel ratio; do not just squeeze a fixed bitmap to fit. Adjacent explanatory labels and a text alternative must remain readable without inspecting tiny canvas lettering.

## 9. Feature inventory: minimum seed, never a coverage ceiling

Create a living feature register before coding. Each independently testable feature gets a stable ID, contract, acceptance criteria, author, verifier assignment, dependency list, reproduction evidence and four loop records. Split compound entries below when their behaviors are implemented or accepted separately. Add every discovered existing feature and every new feature; none may silently disappear because it is absent from this seed.

Map **every original specialist finding** (C1–C8, V-01–V-10, A11Y-01–A11Y-10, QA-01–QA-06, LEARN-01–LEARN-08), each H finding above, and every newly discovered issue to named feature IDs and numbered acceptance criteria. Record a disposition: reproduced defect, proposed enhancement, already resolved with current evidence, not reproduced with the attempted steps, or outside this task with a specific reason. Do not use a broad feature title as proof that the detailed finding was addressed. For example, QA-01/H14 needs F13, F14 and F38 criteria for the executed agreement version; QA-02/H15 needs explicit draft-input versus recorded-review criteria. An overlapping finding can share a fix, but keeps its own traceable disposition.

| Feature | Minimum acceptance contract |
|---|---|
| F01 Purpose, identity and entrance | A fresh visitor can see what to try and that it is simulated; canonical Joe remains intact |
| F02 Navigation and direct access | Guided, free and lab views are reachable by keyboard; switching views does not silently reset practice |
| F03 Guided lesson sequence | Learner-paced steps expose action, result and explanation; refusal is an accepted path |
| F04 Demo playback and debrief | Demo is clearly fictional, pausable/stepwise as designed, replayable and explains the final stopped state |
| F05 Three-person proposal entry | Nonempty and unusual text handled safely; proposal version visibly changes with a new proposal |
| F06 Belief/confidence | Accessible value and plain meaning; even maximum confidence creates no consent or agreement |
| F07 Bounded test review | Review status and its version are explicit; changing relevant evidence has contract-defined effects |
| F08 Required authority review | Simulated authority check remains distinct from confidence, geometry and real institutional assent |
| F09 Safety review | Missing/withdrawn applicable safety blocks action as defined; a new draft does not corrupt an older agreement's stamps |
| F10 Per-person Yes and No | Each actor's exact-version response is visible and independent; test every participant and response |
| F11 Per-person withdrawal | Each applicable actor can stop; resulting state, action block and consequences are visible and retained |
| F12 Commit | Requires the correct current version's gates; invalid attempts explain reasons without creating agreement |
| F13 Simulated Act | Uses the actual active committed version; blocks before commit, after withdrawal and after retirement |
| F14 Replacement proposal alongside agreement | New candidate and old agreement remain distinguishable; old consent never silently attaches to new wording |
| F15 Geometric suggestion to proposal | Suggestions have clear provenance and require explicit promotion; never grant consent or action |
| F16 Repair response | Validates empty/long input appropriately; explains what repair resolves; never restores consent |
| F17 Release / retire | Has a clear effect and availability; retains historical agreement and consequences; later actions remain blocked |
| F18 Four-seat readiness | Each seat's readiness is visible; all required active seats being ready permits the separate explicit Close round command; readiness alone does not advance phase and Ready never means Yes |
| F19 Four-seat consent | Each actor's exact proposal/version response is inspectable; independent of readiness; keyboard survives updates |
| F20 Four-seat review | Toy review inputs are understandable and version-scoped; bulk demonstration is labeled rather than pretending human review |
| F21 Four-seat commitment | Permission gate remains distinct from round phase transition; visible agreement matches committed proposal |
| F22 Close round | Correct prerequisites and phase change; closing alone creates no Hopf agreement |
| F23 Begin ACT | Correct phase and active agreement required; invalid orders are explained and do not mutate permission |
| F24 Record outcome | Outcome references actual committed proposal/version, relevant participant and action; no canned wrong route |
| F25 RETURN | Shows completed transition and retained learning; pending outcomes applied exactly once; repeated invalid use cannot duplicate effect |
| F26 Simulation isolation | Activity switching, demo replay and fresh attempts cannot change the other table's consent or agreement |
| F27 Bundle/process switch | Correct default; correct control semantics; selection unmistakable; exact geometry and metaphor stay distinct |
| F28 Responsive geometry rendering | No distorted proportions; drawing/text remain usable across tested widths and pixel ratios |
| F29 Theta control | Accessible name/value/units; ordinary and endpoint cases handled; display does not grant permission |
| F30 Phi control | Accessible name/value/units; selector changes as contracted; periodic endpoints handled |
| F31 Gamma control | Accessible name/value/units; common-phase invariance explained and verified; no consent effects |
| F32 Explicit Explore | Display/protocol relationship is visible before and after; only intended exploratory state changes |
| F33 Reframe by pi/2 | Representation/invariance result explained; proposal and applicable permissions remain intact |
| F34 Linking recomputation | Action returns a labeled finite approximation or understandable unavailable/error state; never a moral/protocol score |
| F35 Carry once / holonomy | Shows what returns and what changes, with units and correct convention; history and grants handled correctly |
| F36 Numerical explanations | Hopf coordinates, holonomy, Chern and torus residual have optional precise definitions and honest expectations |
| F37 Status and recovery guidance | Every success/block/pause has human-readable cause and next action; screen-reader announcements do not require log hunting |
| F38 Event history | Records remain inspectable, ordered and version-attributed; short summary does not substitute for full retained history |
| F39 Fresh attempt, replay and reload | Deliberate restart is distinct from RETURN; retention policy is visible; state loss is never represented as saved history |
| F40 Keyboard and accessible semantics | All features operable; focus stays logical after updates; controls expose correct roles/names/states |
| F41 Responsive layout, contrast and motion | Reflow, zoom, focus, contrast and optional motion meet the stated targets across affected states |
| F42 Python/JS contract parity | Shared scripted walks match canonical expectations; protocol bug fixes handled in both implementations where relevant |
| F43 Existing learning-packet compatibility | Golden fixtures and reject rules remain valid; practice never becomes enrollment or human assent |
| F44 Entry route, loading, fallback and release evidence | Root and supported direct routes load the right build; missing asset/JS/computation failures are intelligible |
| F45 Existing model-only capabilities | Inventory object/correct/dispose and other existing features; preserve/test them, expose only when current scope requires; no silent regression |
| F46 How this model works / provenance | Learners can reach accurate rules, mathematical explanations and versioned verification context; links resolve and match claims; verifier traces one UI transition to its normative rule and test evidence; no indiscriminate exposure of private repository content |

Actor variants are mandatory cases, not sampling opportunities: test Maya, Finn, Bea and Sam wherever they exist; test Yes, No and Withdraw where supported. A shared reusable control may have one feature contract, but its loop evidence must enumerate all actor instances and their state isolation. New semantics need a new child feature, not a vague “covered by component test.”

Mark `UNCHANGED_RETAINED` features explicitly; retaining a feature still requires its four independent verification loops for this task. A truly inapplicable branch requires an evidence-based reason. `NOT_RUN`, missing browser coverage or unavailable tooling is not `NOT_APPLICABLE` and is not a pass.

## 10. The four-loop procedure — mandatory per feature

First implement the feature against its contract and run builder checks. That initial implementation is **not** loop 1.

For every feature F, run four successive cycles:

1. Freeze candidate C(F,1). Independent verifier V1 uses the interface and relevant tests, records PASS/FAIL/BLOCKED findings with reproduction and evidence. Builder revises against V1. V1 or another independent verifier tests the revised candidate and closes loop 1 only after checking the actual revision and affected regressions.
2. Freeze the next candidate C(F,2). Independent verifier V2 performs a new review emphasizing usability, keyboard, accessibility and narrow layouts, as relevant. Builder revises. An independent verifier verifies those revisions and the complete feature contract. Close loop 2.
3. Freeze C(F,3). Independently challenge invalid order, edge values, repeated commands, state/version boundaries, recovery and isolation. Builder revises. Independently verify the revision and full feature contract. Close loop 3.
4. Freeze C(F,4). Independently test the feature within the assembled experience on the intended release candidate, including responsive/visual coherence and realistic neighboring actions. Builder revises. Independently verify the fourth revision, affected dependencies and full feature contract. Close loop 4.

These emphases add coverage. They do not limit a verifier from reporting any defect in any loop. Each loop's acceptance covers the whole feature contract plus its new challenges. At least four distinct independent review rounds and four independent post-response closure checks are required for each feature. The final site audit is additional and cannot substitute for any feature loop.

For each finding: reproduce, record root cause or bounded hypothesis, make a focused correction, add a meaningful regression when warranted, inspect the updated UI, then obtain independent re-verification. A verifier's initial FAIL remains in the history. A loop can close only when the revised result is independently accepted and all its blocking findings are closed.

If a review finds no defect, it must still apply a fresh, relevant challenge and document the result. The builder must respond explicitly. Never fabricate a bug or make pointless code churn just to produce four commits. A warranted refinement can concern the implementation, explanation, recovery, accessibility or a material gap in verification. A justified “no code revision warranted” must be independently accepted and accompanied by the new coverage evidence; it does not remove the requirement for four review rounds and four closure checks. Do not label an empty repeated run a revision.

Maintain both the input and revised candidate identities. Use commit SHA plus clean-worktree state; if temporary uncommitted verification is unavoidable, capture a reproducible tree/content hash. Record verifier identity, environment, exact actions/commands, observed outcomes, artifacts, findings, revision references, and closure verdict. UI screenshots alone cannot prove protocol behavior; passing unit tests alone cannot prove visible usability.

A loop is `CLOSED` only if:

- Initial independent review exists and ran against its recorded candidate.
- Builder response addresses every finding with a patch or evidence-backed disposition.
- Independent closure ran against the revised/accepted candidate, not the previous one.
- No unresolved blocking finding remains; accepted limitations are explicit and within scope.
- Relevant actor variants, states and dependency regressions are covered.

Shared changes invalidate stale acceptance. Reopen every affected feature when a later patch changes its behavior, layout, labels, semantics or dependencies. Keep historical loops; re-run the impacted checks and close acceptance against the final candidate. You need not repeat unrelated earlier experiments merely because a different file changed, but provide an explicit impact analysis. Final acceptance cannot point only to an older build.

## 11. Test matrices and meaningful evidence

Test complete tasks using browser/computer interaction. Include fresh entrance → guided lesson → refusal/withdrawal → repair → debrief; complete three-person commitment; replacement while an older agreement remains active; four-seat readiness → COORDINATE → commit → ACT → outcome → RETURN; and geometry exploration that leaves permissions unchanged.

For both tables cover happy paths and negative paths: no reviews; partial reviews; no consent; partial consent; one No; all required Yes; duplicate Yes; withdrawal before/after commitment as defined; proposal change; relevant same-version safety change; attempted action on a paused/retired agreement; repair without restored consent; release with unresolved consequences as defined; empty and long text; repeated clicks; and rapid sequential input. Use the normative contract to determine expected denials. Never “repair” a correct denial into a successful action.

For four-seat sequences specifically cover all-ready/no-consent; all-consent/not-ready; Close round without commit; Begin ACT before commitment; outcome before ACT; repeated outcome where supported; RETURN with/without eligible outcomes in each applicable phase; repeat RETURN; and the next round with retained prior history. Distinguish harmless duplicate attempts, multiple legitimate outcome records and true double application from the actual contract. Do not invent idempotency behavior where the contract intentionally allows repeated records.

For geometry test the documented default, drawing switch, all three sliders with keyboard and pointer, endpoints, periodic angles, display/protocol mismatch, explicit Explore, reframe, suggestion promotion, linking and holonomy. Use repository derivations/fixtures and independently calculated expected values with declared tolerances. At theta=60 degrees the documented connection gives a 90-degree latitude holonomy; check conventions before using it as an oracle. Numerical linking is approximate; Chern sign is convention-dependent. Test valid finite output, handling of singular/degenerate cases, and an explanation when a visualization cannot show a valid limit.

For each changed feature, test its relevant visual and interaction states across this target matrix:

| Dimension | Required coverage |
|---|---|
| Narrow phones | 320 CSS px reflow check; representative 360/390px layouts and touch-equivalent controls |
| Tablet and laptop | Approximately 768px, 1280/1366px and 1440px; both short and tall viewports where the task depends on vertical space |
| Zoom / reflow | 200% text/zoom behavior and 400% desktop reflow equivalent, with documented treatment of essential two-dimensional geometry |
| Browser engines | Current Chromium plus Firefox and WebKit/Safari where tools are available; record actual versions and any unavailable engine |
| Input | Pointer, full keyboard path, touch/device check where available, no drag-only essential operation |
| Assistive behavior | Semantic inspection plus available real screen-reader check; label an unavailable screen-reader run honestly |
| Display preferences | Reduced motion, high-contrast/forced colors where supported, device pixel ratio changes for geometry |
| State | Initial, in-progress, blocked, valid, paused, repaired, retired, reload/re-entry and fresh attempt as applicable |

WCAG 2.2 AA is the accessibility target, not a claim based on one automated scan. Check normal text contrast of at least 4.5:1 (qualifying large text 3:1), meaningful non-text UI contrast, visible and unobscured focus, names/roles/states, status messages, logical order, keyboard operation and reflow. Aim for 44px primary touch controls as a product target; WCAG 2.2 AA's target-size criterion is 24×24 CSS px with defined exceptions, not a universal 44px AA rule. Explain exceptions and actual measurements accurately. Cite current primary W3C guidance in the verification documentation.

If you choose true tabs, implement the complete tab/tablist/tabpanel relationship, selection, focus and keyboard pattern. Otherwise use an honestly labeled group of pressed buttons. Do not attach a tablist role to ordinary buttons and call it complete.

Preserve stable focus across state updates. Keep participant context in each accessible name or group; raw repeated “Yes” controls must not require sight to identify the actor. Announce concise meaningful outcomes rather than re-announcing an entire growing ledger. Do not announce cosmetic camera frames continuously.

For reliability and performance, record page-owned console exceptions separately from browser-extension/automation errors. Check asset loading, startup failures and responsive rendering. Use reproducible timings and byte sizes to identify actual bottlenecks; do not fabricate Lighthouse, Core Web Vitals, mobile-device or production traffic measurements. Do not add monitoring that transmits personal data solely for this audit.

Manual browser tests may be supplemented by automated end-to-end tests and meaningful unit/property/parity tests. Avoid assertions that merely mirror implementation constants or confirm that a button exists. Assert user-visible outcomes, legal state transitions and invariants. Do not remove a failure, weaken an assertion or mark a test skipped to make a dashboard green.

## 12. Order of implementation

1. Establish repository/deployment identity; capture current screenshots and complete feature inventory; reproduce the review findings; run baseline tests and distinguish existing failures.
2. Fix correctness and access barriers: wrong outcome attribution, focus loss, canvas distortion, misleading/missing state, and any newly reproduced protocol regression. Preserve normative contracts.
3. Build the entrance, navigation and shared visual/semantic foundations; integrate them early so later feature acceptance tests the actual shell.
4. Implement the guided dragon journey, explicit review/consent/version presentation, stopped-state explanation, repair and debrief; keep free practice available.
5. Improve four-seat rehearsal UI and keyboard stability; preserve its separate state and clear phase/commit distinction.
6. Improve lab controls, default drawing, proportional rendering, text alternatives and layered mathematical explanations.
7. Define and implement deliberate fresh-attempt/replay/reload behavior. Prefer an explicit local-practice retention policy over an unjustified new persistence backend. If local restore is added, version and validate its data, handle corruption, and never imply cross-device durability.
8. Complete four independent loops per feature as features stabilize; integrate continuously, invalidating affected acceptance after shared changes.
9. Run final complete-story acceptance, all required regression gates and source/deployment checks. Close docs, remaining limitations, rollback notes and a reviewable handoff.

Keep the register current; this sequence is dependency guidance, not permission to postpone all verification to the end. Do not add new lesson content or cross-repository features simply because existing plans mention future work.

## 13. Durable records and completion gate

Use existing project tracking conventions where present. Otherwise create a compact, discoverable work package such as:

```text
docs/ux-review/
  README.md
  baseline.md
  feature-register.json
  findings.md
  finding-to-feature-map.md
  decisions.md
  verification/
    F01/loop-1-review.md
    F01/loop-1-response.md
    F01/loop-1-closure.md
    ... four loops for every feature and any child feature ...
  final-acceptance.md
  HANDOFF.md
```

Store screenshots/traces under a suitable evidence directory with descriptive identifiers. Keep the records small enough to use; link to immutable evidence rather than copying huge logs everywhere. Redact secrets from artifacts. Failed findings and superseding decisions remain traceable.

Each loop record must contain at least:

```json
{
  "feature_id": "F24",
  "loop": 1,
  "reviewer": "actual-independent-agent-id",
  "authors": ["actual-author-agent-id"],
  "input_candidate": "commit-or-reproducible-tree-hash",
  "initial_verdict": "FAIL",
  "findings": ["finding-id"],
  "review_evidence": ["artifact-or-command-record"],
  "builder_response": "response-record-path",
  "revision_candidate": "revised-commit-or-tree-hash",
  "closure_reviewer": "actual-independent-agent-id",
  "closure_verdict": "PASS",
  "closure_evidence": ["artifact-or-command-record"],
  "status": "CLOSED"
}
```

Values above are illustrative, not completed evidence. Initialize real records as `NOT_STARTED`, never pre-fill PASS. Add timestamps, environments, tested actor/state variants and dependencies in the actual schema.

Implement a small ledger-validation gate appropriate to the repo that fails if an in-scope feature or child feature is missing any of loops 1–4, has an author accepting their own work, lacks revision/closure evidence, remains blocked, or has stale final acceptance. Validate that at least two independent verifiers contributed to the feature. A ledger checker verifies record completeness, not truth; final independent reviewers must inspect actual artifacts and run the product.

The handoff must identify the last verified candidate, current branch/worktree, uncommitted work, commands to resume, unfinished features/loops, known blockers and the next concrete action. Checkpoint before context loss. Continue from that checkpoint without rewriting history or restarting completed work.

## 14. Final independent acceptance

A feature is complete only after four closed loops, all required criteria passing, and acceptance still applicable to the integrated candidate. The site is complete only when every in-scope feature meets that condition and final whole-experience checks also pass.

The final independent reviewer must:

- Start from a clean visitor state and complete both practice experiences and relevant lab actions using the UI.
- Recheck denial, withdrawal, versioning, outcome attribution, RETURN exactly-once effects and simulation isolation.
- Verify the newcomer path, visual consistency, keyboard progression, narrow layout, zoom/reflow, meaningful announcements and readable diagrams.
- Verify the final source identity, required tests, parity, packet compatibility, production root rewrite and asset references.
- Inspect the feature ledger and a meaningful sample of raw artifacts from every feature, not just a summary count. Any suspicious record requires direct reproduction.
- Distinguish verified outcomes from assertions, historical checks, unrun tests, unavailable environments and actual human testing.

An expert-agent walkthrough is not a human usability study. If no novice human participated, say so. Do not claim a child understood the lesson, a screen-reader user succeeded, or four people consented because agents simulated them. A recommended later human click-through can remain a clearly identified validation limitation; it is not an excuse to stop the authorized build and independent agent checks.

No unresolved critical/high issue or broken core journey may pass. A minor known limitation may be explicitly accepted within the feature contract, with severity and consequence stated; not silently hidden. If full acceptance is blocked by an unavailable required environment, give a useful verified candidate and a precise incomplete status, not “production ready.”

## 15. Delivery and communication

Give short progress updates centered on what now works, what failed and what the next independent check will settle. Do not send the user every tool call or repeatedly ask whether to continue. Stop only for an actual missing authorization, indispensable unresolved product choice, access boundary, or external dependency that cannot be resolved safely; finish all unaffected work first.

Deliver the implemented branch/patch and preview or local run instructions; concise description of the new experience; before/after evidence; complete feature register; per-feature four-loop matrix; independent review and revision records; test results on the final candidate; known limitations; and deployment/rollback notes. Open a reviewable draft PR if authorized in the working session. Deploy production only when that action is authorized; verify the deployed build if deployment occurs.

The user-facing completion message should lead with the usable result, identify the preview/PR, state how many features completed four loops, state the final candidate identity, and disclose any unverified scope. Never say four loops were completed when only four global rounds were run.

## 16. Start now

Inspect the actual repository and live site. Establish the baseline, assign the independent team, enumerate the features, and begin with the highest-impact reproduced issues. Implement, independently verify, revise, independently verify the revision, and repeat for at least four loops per feature. Keep the mathematical model inspectable, the learner's task simple, and every authority boundary faithful to its contract.

Primary accessibility references: [WCAG 2.2](https://www.w3.org/TR/WCAG22/), [target size](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html), [status messages](https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html), [reflow](https://www.w3.org/WAI/WCAG22/Understanding/reflow.html). Recheck current primary guidance when implementing.
