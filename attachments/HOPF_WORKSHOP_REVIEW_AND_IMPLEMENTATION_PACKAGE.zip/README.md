# Hopf Workshop review and implementation package

Prepared for Paul Cooper · 15 September 2026

Start with **HOPF_WORKSHOP_EXPERT_REVIEW.md** for the consolidated findings.

Give **HOPF_WORKSHOP_IMPLEMENTATION_PROMPT.md** to the coding agent working in `jedisherpa/hopf-workshop`. Attach the expert review and the `reviews/` directory for the full evidence and acceptance criteria. The prompt contains 46 starting features, requires the inventory to expand for discovered capabilities, and requires at least four independent review/revision loops per feature with independent checks after the revisions.

The five specialist reviews are:

- `reviews/clarity-review.md`
- `reviews/visual-review.md`
- `reviews/accessibility-review.md`
- `reviews/reliability-review.md`
- `reviews/learning-review.md`

`reviews/prompt-independent-verification.md` records a separate check of the prompt and the resulting corrections. Its closure section identifies the reviewed final documents.

This package contains an audit and an execution prompt. It does not contain a rebuilt site or evidence that the future implementation loops have already been run. Live-site observations, repository documentation, design recommendations and untested areas are distinguished in the reports.

The website was inspected at https://hopf-workshop.vercel.app/ on September 15, 2026. The repository main commit observed was `cf8326aa497c490dd074db2c98c2224a6175435f`; the deployed source SHA was not established. Re-resolve the current baseline before implementing.
