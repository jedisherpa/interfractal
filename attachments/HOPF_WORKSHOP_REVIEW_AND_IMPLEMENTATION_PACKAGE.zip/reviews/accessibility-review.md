# Hopf Workshop — independent accessibility and inclusive-interaction review

Reviewer role: Accessibility and inclusive interaction specialist  
Review date: September 15, 2026  
Inspected deployment: https://hopf-workshop.vercel.app/  
Browser tab: `4`, retained as `a11yTab` in the supported browser runtime  
Evidence scope: Live desktop browser interaction, rendered DOM, computed CSS, focus state, and screenshots. No deployed changes. No repository inspection.

## Assessment

The workshop has a useful foundation: native controls, explicit text for participant consent, labeled regions, meaningful image alternatives, and a readable primary text color. Accessibility needs to become part of the interaction model before visual polishing is considered complete. In particular, activating a participant control removes keyboard focus, several enabled action labels are too faint, and the four-seat practice table provides no programmatic announcement of its changes or blocked actions.

These are observed defects in basic workshop journeys, not hypothetical edge cases. They should be P1 release criteria. This review is a focused audit, not a declaration of full WCAG conformance. A screen reader, mobile touch device, browser zoom/reflow matrix, forced-colors mode, or reduced-motion preference was not tested in this runtime.

## What was tested

| Test | Observed result |
|---|---|
| Open the public root route | Page loaded with four-seat practice, geometry lab, and Parade table. Document title is “The Hopf Workshop”; document language is `en`. |
| First keyboard Tab from initial page | Focus reached “Maya ready.” A yellow 3px outline with 3px offset appeared. |
| Enter on “Maya ready” | Ready readout became Maya and the four-seat ledger recorded `ready v1 Maya: true`; focus became `BODY`. |
| Tab immediately after that action | Focus restarted at “Maya ready,” rather than progressing naturally to “Maya yes.” |
| Enter on “Maya yes” | Four-seat ledger recorded `consent v1 Maya: true`; focus again became `BODY`. |
| ArrowRight on “Hourglass / process” | Focus stayed on that button; drawing selection stayed unchanged. Its parent advertises `role="tablist"`. |
| Enter on “Bundle map” | Selection changed, caption changed, and canvas accessible label changed appropriately. Focus stayed on `map-bundle`. |
| ArrowRight on theta slider | Input changed from `1.05` to `1.06`; displayed theta changed 60.2° to 60.7°. Display coordinates updated while protocol coordinates remained unchanged. Focus stayed on the slider. |
| Enter on the first Parade “Yes” button (Maya) | Visible Maya status became `yes`; Parade live ledger recorded consent; focus became `BODY`. |
| Enter on Parade “Commit” with prerequisites missing | Commit was blocked, reasons remained visible, and a `blocked` entry appeared in the existing polite live ledger. Focus stayed on Commit. |
| Enter on “Commit four-seat proposal” with prerequisites missing | Commit was blocked and a reason was appended to the four-seat ledger. No live/status/alert ancestor exists for that ledger or blockers. Focus stayed on the button. |
| Enter on “Recompute linking” | Linking readout changed from “tap recompute” to `1.000822`; no status/live region announced the result. Focus stayed on the button. |
| Inspect exposed fields, controls, headings, and graphics | Four native ranges; three labeled checkboxes; labeled proposal input and repair textarea; one H1 and three H2s; named regions; canvas image alternative; decorative SVGs hidden from accessibility. |
| Inspect captured warnings/errors | Sampled errors came from a `chrome-extension://` content script. They are browser-extension noise and are not attributed to the workshop. |

## Strengths to preserve

1. The main workshop controls are native buttons and form controls. The theta slider already works with an arrow key; the drawing and Commit buttons activate with Enter.
2. The consent states use words such as `unset`, `yes`, and `no agreement`. Meaning is not exclusively encoded with red/green colors.
3. The page has a useful heading hierarchy and named sections. The geometry and Parade sections live in a main landmark.
4. Proposal and repair fields have associated visible labels, as do the native checkboxes and sliders.
5. The canvas has `role="img"` and a drawing-specific accessible label. Switching from process to bundle updates that label along with the visible caption.
6. Decorative background SVG artwork is `aria-hidden="true"`. The hero image has descriptive alternative text. This is a substantially better starting point than an unlabeled canvas-only application.
7. Parade events already feed an `aria-live="polite"` region. Retain the history, but improve the announcement strategy and extend equivalent feedback to other panels.
8. Primary navy text `#1E3A5F` on the panel backgrounds has strong calculated contrast, approximately 10.53–10.95:1 across the inspected gradient endpoints.

## Ranked findings and acceptance criteria

### A11Y-01 — P1: Participant actions discard keyboard focus

**Confirmed behavior.** Activating “Maya ready,” “Maya yes,” and the Parade table's first “Yes” with Enter all left `document.activeElement` equal to `BODY`. After “Maya ready,” the next Tab returned to the first control, “Maya ready.” The row appeared to be replaced during rendering; that is an implementation inference, not a source-code finding.

**Impact.** A keyboard user loses their location after each choice. Completing several participants' choices becomes repetitive and error prone; a user may repeat the previous choice because focus restarts at the beginning. This is particularly serious in an interface whose central lesson is explicit individual choice.

**Implementation.** Keep keyed participant controls stable during updates, or restore focus to the same logically equivalent control when a rerender is necessary. Do not automatically advance to a different participant or change a decision as a side effect of restoring focus. If an action intentionally removes its own control, move focus to a clearly related next step and announce the result.

**Acceptance criteria.** In both tables, keyboard-activate every ready/consent/no/withdraw control in every applicable state. Focus remains visible on the activated control or a documented logical successor; it never silently drops to the document body. The next Tab and Shift+Tab follow the expected neighboring control. Run this again after replacement proposals, withdrawals, repair, and round return. Preserve the ability to distinguish readiness from consent.

**Standards relationship.** Test against WCAG 2.4.3 Focus Order and 2.4.7 Focus Visible. The confirmed focus-reset behavior needs correction; final criterion-level conformance judgment should include the completed workflow. [W3C: Focus Order](https://www.w3.org/WAI/WCAG22/Understanding/focus-order.html).

### A11Y-02 — P1: Enabled action labels and status accents have inadequate text contrast

**Confirmed styles.** Several small texts use colorful accents directly as foreground colors on very pale translucent panels. Buttons are 13px regular text. Mode labels are 13px bold, which still require the normal-text threshold.

**Calculation method.** Rendered CSS reports panel fill `rgba(243,251,255,0.92)` over a body gradient from `rgb(126,200,248)` to `rgb(238,247,255)`. Alpha-composited endpoint backgrounds are approximately `(233.64,246.92,254.44)` and `(242.60,250.68,255)`. The ranges below calculate the W3C sRGB contrast formula at both endpoints. They are deliberately bounded estimates from CSS rather than claims of exact sampled pixels at every coordinate; the listed failing pairs remain below their required thresholds throughout that interval.

| Observed use | Text color | Calculated contrast interval | Required normal-text threshold |
|---|---|---:|---:|
| Enabled RETURN and Act buttons | `#3DBF5A` | 2.18–2.27:1 | 4.5:1 |
| Enabled No, Withdraw, Bea withdraws; lower-cone label | `#E23B5A` | 3.84–3.99:1 | 4.5:1 |
| Upper-cone label | `#5EC8E6` | 1.77–1.84:1 | 4.5:1 |
| Torus-table label and amber small status text | `#C47A3A` | 3.10–3.23:1 | 4.5:1 |

**Implementation.** Introduce separate accessible foreground tokens for actions, danger, success, and small labels. Keep bright colors as fills, borders, decorative accents, or larger graphic elements where appropriate. A dark foreground on a tinted pill can preserve the palette while improving readability. Do not solve this by making all actions look disabled.

**Acceptance criteria.** Every enabled text/control state has at least 4.5:1 for normal-size text and 3:1 for qualifying large text. Check default, hover, focus, selected, consent, blocked, active, repair, and returned states on actual composited backgrounds. Disabled controls have a standards exception but must remain understandable. Do not flag the large branded “Hopf” word as a required logo contrast violation without establishing whether the logotype exception applies. [W3C: Contrast Minimum](https://www.w3.org/WAI/WCAG22/Understanding/contrast-minimum.html).

### A11Y-03 — P1: The supplied yellow keyboard focus outline is too faint

**Confirmed behavior and styles.** First Tab shows a custom solid 3px `#F0C93A` outline, offset by 3px, around “Maya ready.” That yellow has only approximately 1.46–1.52:1 contrast against the inspected panel background interval. The ring exists, which is good, but it is weak against the pale panel.

**Implementation.** Use a dark outline with strong contrast, or a two-tone focus treatment that remains visible against every component and background. Do not remove the default outline until its replacement is verified. Check focused range inputs separately; theta currently showed a browser-generated dark outline, so do not incorrectly replace it with the failing yellow ring.

**Acceptance criteria.** The authored focus cue reaches at least 3:1 against the adjacent background and remains visible during scrolling, rerenders, dialogs, sticky UI, and selected states. Test every interactive element. Do not describe the WCAG 2.2 AAA Focus Appearance area requirement as an AA requirement. The immediate AA concern here is the contrast of an authored focus indicator under 1.4.11, in combination with focus visibility. [W3C: Non-text Contrast](https://www.w3.org/WAI/WCAG22/Understanding/non-text-contrast.html).

### A11Y-04 — P1: Four-seat feedback is silent to assistive technology

**Confirmed DOM and behavior.** The only live region is `#ledger` in the Parade table. The four-seat `#round-ledger`, `#round-ready`, `#round-blockers`, and phase/readout updates have no `aria-live`, status/alert role, or live ancestor. After blocked four-seat Commit, focus remained on the button; the rendered reason appeared elsewhere. After readiness and consent changes, focus dropped to BODY, compounding the missing feedback. Recompute linking also updated a readout without an announcement.

**Impact.** Users who cannot visually monitor scattered readouts can have no clear confirmation of their action or why it failed. The protocol may be enforcing the correct rule while the interface feels broken.

**Implementation.** Give each independent workshop panel a stable concise announcement channel. Announce events such as “Maya is ready; consent is still needed,” “Maya said yes to proposal 1,” or “Cannot commit: bounded test, authority, safety, and current consent are missing.” Keep the detailed ledger as navigable history. Use polite status announcements for normal results and reserve assertive interruption for truly urgent information. Avoid repeatedly rereading the complete ledger or every slider increment.

**Acceptance criteria.** For successful, blocked, failed, and withdrawn actions, an independent screen-reader test hears the correct concise result once, without focus theft. Geometry operations with delayed or material results announce completion. A retained history remains discoverable and readable independently. DOM checks prove status regions exist before updates; actual NVDA/Chrome or VoiceOver/Safari checks prove behavior. This live review did not use either screen reader. [W3C: Status Messages](https://www.w3.org/WAI/WCAG22/Understanding/status-messages.html).

### A11Y-05 — P2: Repeated decision button names lose participant context

**Confirmed DOM.** Parade table has three buttons named “Yes,” three named “No,” and three named “Withdraw.” The visible participant name is a preceding `strong` element inside a plain `div.person`. The controls have no `aria-label` or `aria-labelledby`, and the participant card is not a fieldset or a named group.

**Impact.** Visual proximity communicates ownership, but a buttons list or sequential keyboard announcement does not reliably tell the user whose consent will change. The four-seat table's “Maya yes” naming is a better precedent.

**Implementation.** Give participant cards meaningful group semantics with a participant legend/name, and make each action name explicitly attributable: “Yes, Maya consents,” “No, Maya declines,” “Withdraw Maya's consent.” Preserve visible label words in accessible names. Make the current decision discoverable without relying on color or a faraway ledger. If using radio controls for a mutually exclusive decision, keep withdrawal as a distinct lifecycle action if that matches the domain model.

**Acceptance criteria.** An accessibility tree and screen-reader buttons list can distinguish every participant action. Keyboard traversal communicates participant, proposal version where relevant, and action. Spoken and visual labels remain consistent. Avoid adding ARIA to a button that falsely describes it as a checkbox or toggle unless the interaction actually has that persistent state.

**Standards relationship.** Consider 1.3.1 Info and Relationships, 2.4.6 Headings and Labels, and 4.1.2 Name, Role, Value. These are currently named controls, so describe the defect as missing contextual attribution rather than claiming every button has no accessible name. [W3C: Labels and Instructions](https://www.w3.org/WAI/WCAG22/Understanding/labels-or-instructions.html).

### A11Y-06 — P2: Geometry switch mixes two incompatible semantics

**Confirmed DOM and behavior.** Container is `role="tablist" aria-label="Geometry drawing"`; children are native buttons with `aria-pressed`, not `role="tab"`. There is no selected tab/tabpanel relationship. ArrowRight does not move selection or focus. Enter on Bundle map works and updates its pressed state.

**Implementation.** The simplest fix is a labeled `role="group"` containing two toggle buttons with accurate `aria-pressed`, or native radio controls. This is a drawing mode choice, so a full tabs widget is optional. If the redesign intentionally uses tabs, implement the whole tabs interaction pattern, including tab roles, selected state, roving focus, arrow keys, associated panels, and consistent activation behavior.

**Acceptance criteria.** Exactly one coherent pattern appears in the DOM and keyboard behavior. Both choices remain reachable, current selection is exposed, and activating a choice preserves focus and updates the drawing alternative/caption. [W3C ARIA Authoring Practices: Tabs](https://www.w3.org/WAI/ARIA/apg/patterns/tabs/).

### A11Y-07 — P2: Geometry controls expose radians while visually presenting degrees, and labels need explanations

**Confirmed behavior.** Theta's native value is `1.06`, its visible output is `60.7°`, its accessible label text is “θ 60.7°,” and it has no `aria-valuetext`. Phi and gamma similarly expose ranges `0` to `6.2832` with a 0.01 step while displaying degrees. Slider labels are only Greek letters plus changing values. “Belief” gives no explicit meaning for 0 versus 1.

**Impact.** The same control offers different unit conventions to different audiences. A screen reader can announce a raw numeric range/value alongside a changing degree-bearing name. Beginners also cannot tell what changing each dimension does before experimenting.

**Implementation.** Provide stable accessible names with ordinary language plus the mathematical symbol, e.g. “Theta, latitude angle.” Provide explicit current-value text such as “60.7 degrees,” keeping radians in optional advanced detail if necessary. Confirm mathematically correct names with the geometry owner; do not invent theta/phi/gamma interpretations. Explain that these controls explore the display and that “Explore these coordinates” is a separate protocol action. Add concise descriptions for Belief's endpoints and why it does not replace consent.

**Acceptance criteria.** Screen readers announce a stable meaningful name, current value in the displayed unit, and usable range. Arrow keys and Home/End behave as documented. Mathematical content and displayed state remain correct. A beginner can say what a control changes and what it cannot authorize. [W3C ARIA Authoring Practices: Slider](https://www.w3.org/WAI/ARIA/apg/patterns/slider/).

### A11Y-08 — P2: Geometry alternatives identify the drawing but do not yet teach its current meaning

**Confirmed strengths and limitation.** Process and bundle have useful one-sentence accessible labels and visible captions. Bundle label says it contains northern and southern solid-torus charts and linked Hopf fibres. The page also provides numeric readouts. However, there is no structured explanation of the currently shown state, which displayed features correspond to those readings, or what just changed after an operation. The screenshot shows a dark canvas with thin low-luminance geometry and very small drawn text; a quantitative canvas contrast audit was not performed.

**Implementation.** Add an accessible “Describe this view” section associated with the canvas. Explain the currently selected drawing, relevant relationships, current parameters, and the consequence of the latest operation in plain language. Keep the same information available visually. Mathematical formulae should have meaningful spoken/text representations. Preserve the explicit distinction between geometric analogy and authorization.

**Acceptance criteria.** A user who does not look at the canvas can complete the learning task using its text equivalent and controls. The nonvisual explanation remains synchronized after mode switches, exploration, reframing, carrying, and recomputation. Independently verify meaningful diagram contrast, line weights, and the readability of internal annotations at all target sizes; no claim of canvas contrast conformance is made here. [W3C: Complex Images](https://www.w3.org/WAI/tutorials/images/complex/).

### A11Y-09 — P2: Navigation landmarks and density need a coherent route through the workshop

**Confirmed DOM.** Four-seat practice is outside the main landmark, even though it is substantial primary interactive content. It has its own named region, so it is not completely undiscoverable. No links or skip link are present. Initial keyboard focus starts in practice, while jumping to main would land after that whole table. There are many controls before geometry and Parade interactions.

**Implementation.** Put all primary workshop activities inside the main landmark and give the user clear section navigation or skip links for introduction, guided practice, geometry, and history. Establish one recommended learning entry and progressively reveal advanced controls, while preserving direct access for experienced users.

**Acceptance criteria.** Landmark and heading navigation reflect the same learning architecture as the visual design. A keyboard user can reach each major activity without traversing every prior action. Repeated components receive clear context. Missing a skip link on this single route is not, by itself, asserted as a confirmed WCAG 2.4.1 failure; the requested improvement addresses observed navigation burden.

### A11Y-10 — P3: Touch targets need an explicit verification pass, especially sliders

**Observed dimensions.** Buttons are approximately 55 CSS pixels high. Checkbox native boxes are 13×13, but their associated label targets are approximately 34px high, so reporting 13×13 as the whole target would be misleading. Geometry range inputs are 16px high and their containing labels 21px high, with approximately 29px between row starts.

**Implementation.** Keep generous button targets and make slider manipulation forgiving. Consider separate increment/decrement buttons or a numeric input for precise setting, especially for motor impairments. These must preserve exact semantics and validate boundaries.

**Acceptance criteria.** Measure actual effective target areas and spacing, including labels and any equivalents, against WCAG 2.5.8's 24×24 minimum-or-spacing rule and its exceptions. Use approximately 44px targets as a usability design goal where practical, not as a false blanket AA requirement. Do not claim the existing sliders fail 2.5.8 solely because their visible range box is 16px tall; spacing/equivalent-control rules need full evaluation. Test on actual touch devices. [W3C: Target Size Minimum](https://www.w3.org/WAI/WCAG22/Understanding/target-size-minimum.html).

## Accessibility requirements for the requested four-loop implementation process

Apply four distinct independent verification-and-revision loops to **each feature**, not four passes over the homepage alone. The builder cannot certify their own feature. Each loop records feature ID, build/commit, setup, exact actions, expected and actual result, evidence, defects, revision, and verification of that revision. If a loop finds no defect, record that outcome honestly and expand to the next prescribed risk; do not invent a cosmetic change to manufacture a revision.

| Loop | Independent accessibility focus | Required revision/recheck |
|---|---|---|
| 1 — Basic operability | Accessibility tree, native semantics, unique names, initial focus, keyboard happy path, core contrast | Fix concrete failures; independently rerun failed actions and adjacent controls on the revised build. |
| 2 — State transitions and recovery | No/withdraw, missing prerequisites, replacement proposal, repair, repeated activation, focus retention, announcement accuracy | Fix lost focus, stale labels, missing status, and incorrect or duplicate events; independently replay the same state transitions plus a fresh alternative sequence. |
| 3 — Inclusive presentation and devices | Screen reader/browser pair, keyboard-only flow, 200%/400% zoom, 320 CSS-pixel reflow where applicable, touch targets, forced colors, reduced motion when motion exists | Repair clipping, unusable controls, lost meaning, or excessive motion; repeat on the affected real environment and an adjacent breakpoint/state. |
| 4 — Integrated independent regression | A reviewer who did not implement the feature completes the full learning task from fresh state using the accessible route, then repeats it with divergent consent and recovery | Repair cross-feature regressions; perform final independent evidence-backed verification on the final artifact. Any change after this verification invalidates affected evidence and must be rechecked. |

Real assistive-technology and device checks that the execution environment cannot perform must be marked **blocked/unverified** with exact outstanding steps, not passed through inference or an automated score. Automated checks can supplement this process; they cannot prove focus behavior, meaningful explanations, cognitive usability, or actual spoken announcements alone.

## Recommended immediate implementation order

1. Preserve participant-control focus and fix authored focus contrast.
2. Correct low-contrast foreground tokens across all active states.
3. Implement accessible per-panel event feedback, participant attribution, and coherent drawing-switch semantics.
4. Clarify slider names/units and provide synchronized diagram explanations.
5. Reorganize landmarks/navigation and verify device/reflow/AT behavior throughout the feature loops.

The result should allow a person to understand what is being proposed, choose deliberately, hear or see the exact result, and recover from a blocked action without losing their place. That is also the workshop's conceptual promise.
