# Hopf Workshop: first-time usability, information architecture, and plain language review

Reviewed live at https://hopf-workshop.vercel.app/ on 15 September 2026. Specialist lens: help a person with no prior knowledge understand the purpose, make a meaningful first move, and interpret the result. This is an expert inspection with real browser interactions, not a participant usability study. No numerical usability score is claimed.

## Overall assessment

The workshop has a distinctive visual identity, a concrete cardboard-dragon story, and unusually careful distinctions between geometry, readiness, consent, and permission to act. Those are useful foundations. The main difficulty is that the site presents the working controls and internal vocabulary before it teaches a visitor what they are trying to accomplish. Improving that order should be the first design task.

The strongest existing teaching moment is already implemented: a group agrees, takes a simulated action, someone withdraws, and further action is blocked. The current demonstration reveals that whole story at once in an event log. Turn it into a short, inspectable sequence with a visible explanation of what changed and why. A visitor should leave understanding one practical principle and having seen it work.

## Evidence and coverage

Browser session: reviewer-owned tab 3, `clarityTab`. Final verified URL remained https://hopf-workshop.vercel.app/ throughout. The initial desktop viewport was approximately 1363 by 936 CSS pixels. Observed document height after demonstration: 2799 pixels. DOM inspection found 38 buttons, four sliders, three checkboxes, and no links. These counts describe this inspected build and are not general usability limits.

I performed these actions through the rendered website:

1. Opened the entry page and inspected its initial screenshot, headings, regions, instructions, labels, and controls.
2. Clicked **Maya ready**. The READY summary changed from `none` to `Maya`, and an event recorded `ready v1 Maya: true`.
3. Clicked **Close round** with only Maya ready. Closure was blocked and the event log explained, `Each active participant must record their own readiness. Absence is not consent.`
4. Clicked **Maya yes**. The event log recorded `consent v1 Maya: true`.
5. Clicked **Record toy review flags**. The missing-check summary reduced to `explicit current-version consent missing`; the event log recorded evidence, authority, and safety as true.
6. Switched **Hourglass / process** to **Bundle map**. The illustration's accessible description and explanatory paragraph changed to the solid-torus/chart presentation.
7. Clicked **Run cardboard-dragon demo**. The three-person table immediately showed proposal v2, checked review flags, Maya and Finn yes, Bea no, a paused status, and an event history covering initial blocked commitment, replacement proposal, review, three consents, commitment, simulated action, withdrawal, and blocked further action.
8. Clicked **Resolve repair** with its supplied demonstration text. A repair event was added; the repair-related blocker disappeared, while missing consent remained. The table stayed paused.
9. Clicked **Explore these coordinates**. Display/protocol coordinates became equal. The event log stated `Changed exploratory coordinates; permissions unchanged`. Consent and paused state remained visibly unchanged.
10. Inspected the demonstration's lower-page screenshot and recorded button/heading/link/input inventory using a read-only DOM query.

I did not validate mathematical derivations, inspect source code, test persistence across reload, perform real multi-person authentication, test on physical mobile devices, or run a screen-reader study. I did not change a deployed file, create an account, publish anything, or act for real participants. All interactions were the site's explicitly presented teaching simulations.

## Strengths to retain

- **The concrete story.** Carrying a cardboard dragon over a bridge is much easier to reason about than an abstract coordination transaction. The orchard alternative and withdrawal provide real narrative consequences.
- **The governing distinction.** `Geometry can suggest a route; it cannot sign a name` is memorable and useful. Keep the distinction visible when suggestions become proposals.
- **Defensive behavior in the inspected scenarios.** Incomplete readiness blocked closure; withdrawal left the demonstration paused; resolving repair did not silently restore missing consent; exploratory coordinates did not change permissions.
- **Traceability.** The event log provides an inspectable history instead of concealing transitions. Preserve it as an optional detail view and as a source for a human-readable timeline.
- **Current proposal and per-person states in the three-seat table.** Proposal version, wording, and named people are present. Build clearer learning interactions around this information.
- **Visual personality.** The blue palette, serif heading, and voxel scene give the workshop character. A simpler interface can retain those features.

## Ranked findings and implementation acceptance criteria

### C1 — High: there is no clear first task or guided path

**Observed.** The initial screen offers a poetic introduction and three mode labels, then a four-seat control panel. The document contains 38 buttons. There is no prominent start action, step indicator, explanation of the intended learning outcome, or visible guided sequence. The three workshop modes are generic text in the inspected DOM, not navigation controls.

**Reproduce.** Open the root URL in an initial state and identify the first instruction telling an unfamiliar person what to do and why. Compare that with the number of actions offered immediately.

**Interpretation.** A new visitor must infer the objective, select an experiment, and decode the vocabulary before experiencing a useful result. This is a plausible comprehension risk, not a measured abandonment rate.

**Recommended implementation.** Lead with one plain purpose statement and a primary **Start the dragon lesson** action. Offer **Explore freely** as a secondary choice. Show the current step, the next useful action, and a short explanation next to the relevant controls. Keep the full sandbox available to experienced users.

**Acceptance.** On desktop and narrow mobile layouts, a new visitor can see what this is, the intended learning outcome, and one clear starting action without interpreting mathematical symbols. The start action enters a finite guided experience. Each step has an explicit objective, a reversible action or observation, and a visible result. A verifier can finish the guided experience with no repository documentation or hidden instructions.

### C2 — High: the two simulations appear in a confusing order and have unclear boundaries

**Observed.** The first interactive section is **Four-seat practice table PLAY**. Its first sentence is `A second simulated table, not the three-person parade below.` The three-person **Parade table** appears later beside the geometry lab. Both tables reuse Maya, Finn, and Bea; one adds Sam and distinct readiness/round/ACT/RETURN controls. The four-seat table sits outside the page's `main` element in the inspected snapshot.

**Reproduce.** Open the root page and read from the first interactive heading through the two table descriptions. Note where the table called second appears and when the first scenario is explained.

**Interpretation.** The relationship between the tables currently has to be learned through exclusions and specialist distinctions. Reused names make accidental cross-table assumptions more likely. This does not establish an underlying state-isolation bug.

**Recommended implementation.** Present separate, explicitly named learning choices: **Lesson 1: make and revise a group agreement** and **Lesson 2: coordinate a four-person round**. Keep their state, history, membership, and resets visibly distinct. Explain the specific additional concept taught by the second lesson. Put both interactive learning experiences within the main content structure.

**Acceptance.** The active scenario always identifies its participants and proposal version. Switching scenarios does not imply shared consent, readiness, history, or authority. A verifier can state which table an action affects before pressing it. There is a direct way to return to the lesson chooser without losing or silently transferring state. Keep all existing protocol distinctions; do not merge their semantics just to reduce screen space.

### C3 — High: the demonstration ends in a paused state without explaining that this is its teaching success

**Observed.** **Run cardboard-dragon demo** immediately filled the event log with a complete sequence and left the table **paused**, showing Bea no and two blocking conditions. There was no step-by-step narration or separate explanation that the safeguard had worked. The demonstrated events included a successful commitment and simulated action before withdrawal blocked another action.

**Reproduce.** From an untouched three-seat table, click **Run cardboard-dragon demo** and inspect the status, visible guidance, and log. In the inspected viewport the demo action was near the bottom of a long, narrow control column.

**Interpretation.** A visitor may interpret paused/error-styled output as a failed demo rather than the intended lesson. The most useful narrative is hidden in a technical timeline.

**Recommended implementation.** Offer a controllable story with **Next**, **Back**, **Replay**, and **Try it yourself**. After withdrawal, say: `Bea withdrew. Further action stopped. The group's earlier agreement is still part of the history, but it no longer permits another action.` Distinguish completion of the lesson from active permission to act. Provide a summary of what the visitor observed.

**Acceptance.** The visitor sees each state transition and why it happened. Pause/resume and manual advance are available if animation is used. The concluding screen names the successful safeguard without falsely saying the group has an active agreement. Replay is deterministic and clearly states which demonstration state it resets. The raw history remains inspectable.

### C4 — High: readiness and consent have uneven current-state visibility

**Observed.** **Maya ready** changed the READY summary. **Maya yes** added consent to the four-seat ledger, but the current four-seat overview still consisted of Round, Ready, and Last RETURN. The action label remained **Maya yes**; there was no equivalent prominent per-seat consent summary. A blocked **Close round** appended its explanatory reason to the event history while the existing generic blocker summary continued to list commitment prerequisites.

**Reproduce.** Click **Maya ready**, **Maya yes**, then **Close round** while other seats are not ready. Compare the summaries with the history and determine which requirement blocked the particular action.

**Recommended implementation.** Give each simulated seat a small status card showing readiness and consent as separate fields, with the exact proposal version. Show feedback for the action just attempted near that action. Provide an available-next-actions summary derived from canonical state. Explain that the visitor is role-playing the seats; this is not real participant authentication or authorization.

**Acceptance.** A visitor can determine each participant's readiness and consent without reading the event log. A blocked round closure explains its own missing prerequisites, while a blocked commitment explains the commitment prerequisites. Changes are announced accessibly and do not rely on color alone. A new proposal must not inherit consent from an earlier version. Copy never treats readiness as a yes.

### C5 — Medium-high: teaching language and implementation language occupy the same level

**Observed.** Initial text includes `Hopf commit`, `RETURN`, `TAWar authority`, `Record toy review flags`, `Begin ACT`, `Python is normative`, and `HTML is a view`. Geometry metrics include `Holonomy this θ`, `Chern integral`, and `Torus residual` without plain explanations in the inspected view. Repeated disclaimers about what geometry does not authorize appear in the heading, diagram descriptions, paragraphs, and footer.

**Reproduce.** Read the page as someone unfamiliar with the portfolio, the mathematical vocabulary, or the software implementation. Locate the definitions available before the first interaction.

**Recommended implementation.** Use everyday action names first, with exact technical terms in short explanations and expandable details. Keep the authority boundary at decision points, where it helps someone make a meaningful distinction. Move implementation provenance into **About this model**. Use glossary links or definition buttons for mathematical terms; preserve their exact meanings.

**Acceptance.** Every specialist term required to complete the basic lesson has an available definition at its first relevant use. No mandatory action requires knowledge of TAWar, Python, or protocol identifiers. Expert mode preserves formulas, values, source provenance, and exact terms. A mathematical reviewer approves technical explanations before release.

### C6 — Medium-high: review controls state requirements without teaching what evidence satisfies them

**Observed.** The three-seat review presents **Bounded test**, **Authority**, and **Safety** as checkboxes. The four-seat control **Record toy review flags** sets those checks together, as shown by the event log. Neither inspected surface explains the corresponding story evidence before setting the checks.

**Reproduce.** Inspect the initial checkbox labels and then use **Record toy review flags**. Observe which evidence is visible to the learner versus the resulting flags.

**Interpretation.** A demonstration can accidentally teach that governance means checking boxes. This is a teaching-content issue; the inspection did not establish what the underlying validator requires beyond the visible flags.

**Recommended implementation.** Ground each check in the dragon story: what small test occurred, who has permission to decide, and what safety question was reviewed. Identify example evidence as supplied simulation evidence. Let advanced users inspect the exact check representation.

**Acceptance.** Every review check shows its evidence source and what that check means in this simulation. The lesson requires observing or choosing the relevant evidence before recording its review. No UI implies that a checkbox, agent, or geometry creates real-world authority. Removing a prerequisite still blocks the relevant simulated action.

### C7 — Medium: geometry needs a clearer educational bridge to the coordination story

**Observed.** The geometry panel displays several numerical diagnostics and three symbol-only parameter labels. **Explore these coordinates** synchronizes Display and Protocol values, with a useful permissions-unchanged event. A route suggestion is visible. The inspected experience does not first explain what a learner should notice in that relationship.

**Reproduce.** Open the lab, switch to **Bundle map**, inspect the metrics, and select **Explore these coordinates**. Compare the changed values with the story's unchanged permission state.

**Recommended implementation.** Add a short guided observation: `Change the view. Notice what moves. The group's agreement stays the same.` Then separately teach when exploratory coordinates are recorded and when a suggestion is proposed. Show only the few values needed for the chosen exercise; retain complete numerical diagnostics in an expert drawer. Mathematical wording must be reviewed rather than inferred from button behavior.

**Acceptance.** A visitor can identify the difference between view manipulation, an exploratory-coordinate change, a route suggestion, a new proposal, and consent. UI tests verify that display-only manipulation leaves protocol/authority state unchanged, and that adopting a new proposal follows existing version/consent rules. Do not simplify by making geometry automatically commit a proposal.

### C8 — Medium: there is no visible recovery or orientation path for exploration

**Observed.** The inspected page had no links or named reset action. It offered a demonstration button but no clearly described **Restart this lesson**, **Reset this table**, or **Back to lessons** control. Logs were rendered as dense monospaced events; in the lower-page screenshot, the narrow right column also required a scrollable log and textarea beside a large blank area in the left panel.

**Reproduce.** Run the demo, resolve repair, and look for a visible action that restores an identified initial state while explaining what history will be retained or cleared.

**Recommended implementation.** Add explicit scenario-level recovery and navigation. Separate current status, suggested next step, and history. Use the page width for the story and participants, reserving a compact, expandable space for diagnostics. Avoid a layout whose column heights force large empty regions beside narrow reading areas.

**Acceptance.** Reset clearly identifies the affected simulation and its treatment of local history. A user can return to the chooser and resume or restart deliberately. No user-entered work disappears on an unrelated mode switch. The useful status and next action are visible without scrolling an event log. Responsive validation covers the lesson, free exploration, expanded history, and repair states.

## Proposed first-success journey

1. **Arrival:** `Explore how a group turns an idea into a shared agreement—and what happens when someone changes their mind.` Primary action: **Start the dragon lesson**. Add a short simulation notice: `You are role-playing a fictional group. These actions do not authorize anything outside this workshop.`
2. **One concrete choice:** Show the dragon and bridge proposal with the three participants. Ask the learner to predict whether enthusiasm alone allows the group to act. The next action reveals the missing checks and consent, with ordinary-language explanations.
3. **Evidence and agreement:** Show the supplied orchard-route evidence. Walk through review, a new version, and explicit choices for each fictional participant. State the version each person accepts.
4. **A successful simulated action:** Show that the checks and current agreement permit one simulated action. Explain exactly what was allowed.
5. **A changed mind:** Have Bea withdraw through an explicit learner action. Attempting another simulated action stops. Explain that the system is working as intended.
6. **Repair and next choice:** Present the earlier consequences and the example response. Show that addressing them does not automatically renew consent. Allow the learner to try a new proposal, replay, or inspect the timeline.
7. **Connect to the geometry:** Offer a focused view-change exercise, then the more detailed geometry lab. Demonstrate visibly that geometry can inform a proposal while participants' permission remains separate.
8. **Advance:** Offer the distinct four-person round lesson with readiness, closure, action, and RETURN explained in sequence. Keep its ledger separate and its additional concepts explicit.

This sequence is a recommendation, not a claim that the current site implements it. The mathematical and protocol owners should approve any relationship asserted between these learning experiences.

## Sample wording for implementation review

| Current label | Proposed learner-facing wording | Constraint |
|---|---|---|
| Four-seat practice table PLAY | Four-person round: practice together | State that all seats are fictional in this demo; do not imply real authentication. |
| Parade table | The dragon parade: make an agreement | Preserve exact active proposal and version. |
| Maya ready | Mark Maya ready for this round | Show readiness separately from consent. |
| Maya yes | Maya agrees to proposal v1 | Substitute the live version; do not imply assent to later versions. |
| Record toy review flags | Record the example checks | Show the supplied evidence and explain the three checks. |
| Commit | Record this agreement | Verify against canonical commit semantics before replacing wording. |
| Act | Try the agreed action | Label the action simulated and preserve its authorization guard. |
| RETURN | Review the outcome and begin the next round | Use only if canonical behavior matches; explicitly preserve the ledger. |
| Belief | Confidence in this idea | Explain that confidence does not grant permission; validate the intended scale. |
| Resolve repair | Record the agreed response to earlier consequences | Do not imply that entering text establishes real agreement. |
| Run cardboard-dragon demo | Watch the dragon story | Make the story staged, replayable, and clearly separate from free exploration. |
| Python is normative. HTML is a view. | About this teaching model | Preserve exact provenance inside the expandable detail. |

## Verification requirements specific to this review

For every accepted feature above, the implementing team should execute the requested four distinct implementation–independent-verification–revision cycles. Give each cycle a different lens: basic unfamiliar-user journey; counterexamples and misunderstood states; keyboard/mobile/assistive presentation; and cross-feature regression after integration. The independent verifier must operate the rendered application from a clean scenario, compare it to explicit acceptance criteria, and provide reproducible evidence. Revisions must address actual findings; if a cycle finds none, record the evidence and a justified no-change result rather than inventing edits.

The decisive usability test is practical: can a person with no prior context explain what changed, what did not change, who agreed to which proposal, and why the next action is allowed or blocked? Expert reviewers can inspect the interface for these conditions; a real first-time participant test would add evidence this review does not claim to supply.
