# Hopf Workshop — independent learning and mathematical explanation review

Review date: September 15, 2026. Reviewer role: learning experience and mathematical explanation specialist. Inspected public deployment: https://hopf-workshop.vercel.app/ . Independent browser tab: `7`, named handle `learningTab`.

## Judgment

The workshop has a worthwhile, unusually precise lesson inside it: changing perspective, feeling confident, satisfying review requirements, obtaining current consent, taking action, withdrawing, and repairing consequences are different operations. The interface already exposes several of those distinctions in its actual behavior. Its main teaching weakness is that it presents the machinery before giving a learner a concrete task, and it presents mathematical outputs before teaching the learner how to interpret them.

A new visitor currently has to infer both the subject of the workshop and the order of operations. The intended transformation should be stated simply: **practice how a group turns an idea into an agreement, acts, and responds when someone changes their mind; then explore what the geometry helps illustrate.** A short guided activity can make that experience accessible without flattening the underlying concepts.

This is an expert review, not a novice usability study. Statements about likely confusion are explicitly inferences, not observations of actual learners. I did not inspect source code, verify the normative Python implementation, audit authentication, certify the mathematical calculations, or test real collaboration. All observed actions were within the displayed teaching simulation.

## What I inspected

I independently opened the deployed page and read the full rendered interface. I inspected the initial desktop layout, switched from Hourglass / process to Bundle map, invoked Reframe by π/2, recomputed linking, carried once around a latitude, advanced θ with the keyboard, explicitly explored the new coordinates, ran the cardboard-dragon demo, and resolved the displayed repair response. I compared rendered state and ledger entries after these actions.

The site offers a four-seat practice table, a geometry lab, and a separate three-person Parade table. The same initial cardboard-dragon proposal appears in both tables, but they expose different operations. The four-seat table is positioned before the other two experiences and describes itself as a second simulation relative to the three-person parade below.

## Strengths to preserve

1. **The proposal is understandable.** Carrying a cardboard dragon over a bridge is concrete enough to support an elementary explanation of a coordination problem.
2. **The authority boundary is prominent.** The page says that geometry can suggest a route but cannot sign a name. The process drawing is identified as a metaphor rather than the bundle, and the footer separates topology from authorization.
3. **The displayed protocol is richer than a simple vote counter.** The observed demo distinguishes review, versioned consent, commit, simulated action, withdrawal, and subsequent blocked action.
4. **The demo shows that confidence alone is insufficient.** It records belief at 1, then a blocked operation because evidence, authority, safety, and current consent are missing.
5. **Withdrawal has visible consequences.** In the demo, Bea withdraws after simulated action; the table becomes paused, and another action is blocked.
6. **Repair is distinct from renewed consent.** Clicking Resolve repair removed the repair blocker, while Bea remained “no” and the table remained paused with explicit current-version consent missing. This is an especially important distinction to retain.
7. **Display and protocol coordinates are explicitly distinguished.** A new θ value changed the display. Explore these coordinates synchronized the displayed and protocol π(z) readouts and logged that permission was unchanged.
8. **The advanced subject matter is available.** The lab exposes coordinates, holonomy, a Chern integral, linking, and a residual. These can support a serious advanced track once their conventions and interpretation are made accessible.

## Evidence and prioritized findings

### LEARN-01 — The first meaningful task is absent from the entrance

**Priority:** High. **Observed:** The hero gives a motto and three metaphorical labels: Upper cone / Generate ideas, Torus table / Keep a promise, and Lower cone / Release a form. The next major section is the Four-seat practice table with 14 buttons, including readiness, consent, toy review flags, commit, Close round, Begin ACT, outcome, and RETURN. It introduces Hopf commit and TAWar authority before introducing those terms.

**Reproduction:** Open the root URL in a fresh tab and read the first screen and first table.

**Inference:** A learner without Paul’s project context is likely to ask: What am I practicing? Which button comes first? Am I changing anything real? What does success look like? The interface answers the last question less clearly than it explains what the simulation is not authorized to do.

**Recommendation:** Put a positive explanation and one primary task before the control panels. Suggested direction: “Help Maya, Finn, and Bea move a cardboard dragon. Try a plan, check what it needs, and see what happens when someone changes their mind.” Offer “Start the 4-minute practice” and a secondary “Explore the lab.” State that these are fictional people in a simulation and that no real agreement is created. Preserve the deeper boundaries in relevant explanations rather than requiring the first paragraph to carry every project distinction.

**Acceptance:** A first-time learner can identify the goal, fictional context, first action, and expected completion without inspecting a ledger or external documentation. Validate with at least five actual novice participants if available; require at least four to complete the first activity and explain its key distinction without facilitator intervention. Agent role-play may prepare this test but must not be reported as human validation.

### LEARN-02 — Two similar tables compete before the learner understands either

**Priority:** High. **Observed:** The Four-seat practice table precedes the three-seat Parade table. Both initially propose carrying the cardboard dragon over the bridge. They share Maya, Finn, and Bea; the first adds Sam. The first describes itself as a second table relative to content further down the page. Its initial controls and state remain separate when the Parade demo runs.

**Reproduction:** Compare both tables before and after Run cardboard-dragon demo.

**Inference:** Visitors may assume the four seats and three seats are inconsistent views of one group or that buttons in one table should affect the other. The explanatory paragraph prevents a literal contradiction, but it requires visitors to understand the second table before they have seen it.

**Recommendation:** Give the activities clear purposes and separate entry points: a three-person agreement lesson and a four-person round practice. Introduce the three-person lesson first, then offer the four-seat variation as a next activity if that matches the canonical product plan. Preserve both underlying models and their separate state. Do not silently merge their rules or participant identities.

**Acceptance:** Each activity states its participant count, learning goal, state ownership, and relationship to the other. Switching activities never copies consent or state implicitly. The selected activity has one visually dominant action. A learner can correctly answer whether consent in one table applies to the other.

### LEARN-03 — The automatic demo compresses the lesson into a ledger

**Priority:** High. **Observed:** Run cardboard-dragon demo immediately generated a sequence of events and ended at Parade table PAUSED. In this inspection the new events were belief=1, blocked operation, replacement proposal v2, review flags, consent from all three participants, commit, simulated action, Bea withdrawal, and blocked action. There was no displayed stepper, pause control, prediction question, or completion debrief. The final state explains missing current consent and unresolved previous consequences, but a learner must read ledger entries to reconstruct how it happened.

**Reproduction:** From the initial Parade state, click Run cardboard-dragon demo, then inspect the resulting status, consent cards, and ledger.

**Inference:** The demo demonstrates the correct distinctions too quickly for many novices to learn them. The final PAUSED state may look like failure rather than the intended instructional outcome.

**Recommendation:** Build a deterministic, stepwise lesson around the existing demonstrated behavior. Before each transition, explain the situation and ask for a prediction; let the learner perform the next relevant action. Include pause, replay, and a documented reset of the disposable simulation. Preserve a fast-run option for expert inspection. Introduce withdrawal and repair as successful learning milestones.

**Acceptance:** The learner can inspect every state transition before continuing. The demo labels scripted participant choices as simulated choices. At its conclusion, the learner can explain why high belief did not authorize action, why consent belongs to a version, and why Bea’s withdrawal pauses action. A fresh replay reproduces the same expected sequence. A fast-run mode and the guided mode must use the same actual protocol transitions or a verified equivalent, not separate contradictory mock logic.

### LEARN-04 — Repair needs an explanation of what has and has not changed

**Priority:** High. **Observed:** After the demo, Resolve repair added a repair ledger entry using the provided response. The “previous consequences need an agreed response” blocker disappeared. Bea still showed “no,” the table stayed PAUSED, and the remaining blocker was explicit current-version consent missing.

**Reproduction:** Run the demo, then click Resolve repair with the default repair response; compare the blocker list and consent cards.

**Inference:** The distinction is sound, but the button label may lead a beginner to expect the whole group process to resume.

**Recommendation:** Provide an explicit result: “The response to earlier consequences is recorded. This does not restore Bea’s consent.” Offer the allowed next actions according to the normative model, without implying that the learner should pressure Bea to say yes. If the simulation lets one user record an agreed response on behalf of fictional people, keep that simulation assumption visible.

**Acceptance:** Repair cannot silently restore consent, resume an agreement, or rewrite the action history. Feedback names both the resolved condition and any remaining condition. The test suite includes this observed sequence and verifies it against the intended model.

### LEARN-05 — Mathematical output needs an interpretation layer

**Priority:** High for teaching; medium for general navigation. **Observed:** The lab initially displayed holonomy 90.4372°, Chern integral -1.00000003, residual 5.55e-17, and Linking |Lk| “tap recompute.” Recompute linking produced 1.000829. Neither the labels nor nearby text explained what result was expected, what precision meant, which orientation convention was used, or whether the value was a numerical approximation. Carry once around this latitude recorded “base returned; lift acquired 1.578427 rad.”

**Reproduction:** Open Geometry lab, select Bundle map, click Recompute linking and Carry once around this latitude, and inspect the numerical readouts and ledger.

**Inference:** Many novices will treat the numbers as decoration. An advanced user may reasonably want a method, sign convention, error bound, and a reference before treating the readouts as mathematical evidence. The screenshot and readouts alone do not establish correct topology or a correct numerical method.

**Recommendation:** Add a plain-language layer and an advanced details layer. Each numerical result should state what it measures, units, expected behavior under the model’s conventions, numerical method, and an appropriate tolerance or convergence diagnostic. Present a negative Chern result with its declared orientation convention, not as intrinsically wrong or right. Explain why an approximately integral result can differ slightly from the ideal value. Keep “topological fact,” “numerical demonstration,” “process metaphor,” and “authorization rule” visibly distinct.

**Acceptance:** Independent mathematical verification must inspect the normative source and derivation, identify coordinate/sign/orientation conventions, and compare actual computations with independently obtained expected results over ordinary and edge cases. It must not approve values merely because they are close to familiar integers. A plain-language explanation is available without losing formulas, precision, or method details for advanced users. No green verified badge appears without real supporting evidence.

### LEARN-06 — Controls do not teach what changes and what stays invariant

**Priority:** High. **Observed:** Reframe by π/2 logged “Changed common phase; proposal and permission unchanged.” The visible π(z) readouts and slider labels were unchanged in the immediate inspected state. Carry logged a lift change in radians. Moving θ with ArrowRight changed the display readout; Explore these coordinates subsequently made display and protocol readouts match and logged “permissions unchanged.”

**Reproduction:** Record the initial readouts; click Reframe; inspect the log and readouts. Carry once and inspect the new event. Move θ one keyboard increment, inspect the display/protocol distinction, then click Explore.

**Inference:** The distinction between a coordinate manipulation, change of frame, carried lift, suggestion, and proposal is pedagogically central but hard to infer from the existing labels. “Sliders are camera” may also be interpreted literally as view-only camera movement; implementation review must establish whether that phrasing accurately describes all the quantities affected.

**Recommendation:** Pair each operation with a short before/after explanation: “Changed: … / Kept: … / Requires a separate action: …” Where practical, highlight the relevant geometric object and the corresponding readout. Explain θ, φ, and γ first in simple words and then in the exact mathematical convention used by the implementation. Avoid renaming a mathematical variable based only on this UI review.

**Acceptance:** For each geometry operation, a verifier can identify all intended affected state, invariant state, and downstream permission state, and compare observed changes against independently derived expectations. A learner can explain why a new geometric suggestion still requires a proposal and current consent. A keyboard and a non-visual route must expose equivalent before/after information.

### LEARN-07 — The bundle diagram is not yet a sufficient explanation of the bundle

**Priority:** Medium. **Observed:** The selected Bundle map rendered thin colored curves against a dark panel, with small embedded text. The visible caption was “Two solid tori joined rim to rim on the Clifford torus. Each chart carries a circle. This drawing is not a grant.” Its accessible image label names northern and southern solid-torus charts, the equatorial Clifford torus, and two linked Hopf fibres.

**Inference:** This is useful vocabulary for a prepared reader but does not teach a novice what to look at. The compressed phrase “joined rim to rim” needs careful explanation of the actual boundary identification; a static image cannot establish that gluing map. A beginner may also conflate the process hourglass with the mathematical construction despite the disclaimer.

**Recommendation:** Add a reveal sequence: identify the represented base, highlight one fiber, select another represented point/fiber, then show the relationship. Introduce the two chart regions and shared boundary with labels large enough to read outside the drawing. Clearly identify which views are illustrations, projections, chart schematics, or numerical renderings. Keep the process metaphor in a separate named lesson rather than suggesting that the cones literally constitute the Hopf bundle.

**Acceptance:** A specialist verifies the schematic and captions against the canonical mathematical definition. Plain-language and technical captions agree. The diagram has a useful static/text equivalent and does not depend on color alone. Any gluing description includes the actual intended relationship rather than relying on a suggestive shape.

### LEARN-08 — Expert provenance is declared but not actionable in the inspected interface

**Priority:** Medium. **Observed:** The footer says “Teaching model v0.2. Python is normative. HTML is a view. Topology does not authorize. Wizard Joe is presentation only.” The inspected rendered page did not expose a corresponding source link, derivation, model reference, or explanation of what Python being normative means for a learner.

**Inference:** The statement helps maintain claim discipline but does not let a curious or skeptical reader verify the relationship between the displayed simulation and the governing model.

**Recommendation:** Put technical provenance behind “How this model works,” with verified links and exact version information that actually match the deployed build. Explain normative in ordinary language. Link the mathematical definitions, simulation rules, and validation evidence separately. Do not claim the browser executes the Python model unless source inspection proves that architecture.

**Acceptance:** Every provenance link resolves to the intended version and supports the associated claim. An independent verifier can trace a representative UI transition to the normative specification and corresponding test evidence. Learners need not read technical provenance to complete the first activity.

## Proposed first lesson: four minutes, with optional depth

This is a recommended design, not a description of existing behavior. The exact transition sequence must be reconciled with the normative model before implementation.

**0:00–0:30 — Meet the group.** Introduce Maya, Finn, Bea, and their cardboard dragon. Explain the simple task and that the learner is trying fictional actions. Ask: “What would the group need before moving the dragon?”

**0:30–1:15 — Confidence is one input.** Let the learner increase confidence and attempt to commit. Present the resulting blockers in plain language. State the lesson directly: confidence says how strongly someone believes something; it does not establish evidence, authority, safety, or another person’s consent.

**1:15–2:15 — Make an agreement for this plan.** Introduce the replacement orchard route, review conditions, and the fictional participants’ explicit choices. Let the learner inspect the proposal version before committing. Show that consent is attached to that version. Do not turn the activity into a reward for accumulating yes votes; a no should be a valid, understandable outcome.

**2:15–3:15 — Act, then honor a change.** Perform one simulated action. Bea withdraws. Ask the learner to predict whether another action can continue. Show the paused state and separate discussion of earlier consequences. Let the learner inspect what the ledger retains.

**3:15–4:00 — Repair does not replace consent.** Record the simulation’s repair response. Explain why the prior consequence condition is resolved while Bea’s consent is not restored. Offer a short transfer question using a different concrete project.

**Optional next lesson — Geometry as a way to explore.** Open the geometry lab only after the learner understands the protocol. Let them reframe, explore a coordinate change, and compare what changes with what is preserved. End by asking whether the geometry has agreed on anyone’s behalf. Offer formulas and numerical evidence for readers who want the advanced track.

## Suggested feature contracts for the implementation prompt

| Feature | Observable learning outcome | Evidence required for acceptance |
|---|---|---|
| First visit orientation | Learner identifies task, simulation status, and first action | Fresh-session browser walkthrough and real novice test when available |
| Activity separation | Learner distinguishes three-person agreement practice from four-seat round practice | Independent state-isolation checks and comprehension task |
| Guided dragon lesson | Learner explains belief, review, consent, action, withdrawal, and repair separately | Step-by-step browser evidence, deterministic replay, model transition checks |
| Versioned agreement teaching | Learner understands that a changed proposal needs its own valid consent | Model-aligned negative tests and UI explanation test |
| Repair feedback | Learner understands that resolving earlier consequences does not restore consent | Observed demo → withdrawal → repair sequence plus invariant assertions |
| Coordinate explanations | Learner identifies what Explore, Reframe, and Carry change and preserve | Before/after browser evidence and independent mathematical/model expectations |
| Mathematical result interpretation | Reader can interpret values, units, approximation, and conventions | Mathematical derivation review, independent expected values, numerical tolerances |
| Accessible diagram lesson | Equivalent conceptual understanding is possible without color or visual animation | Keyboard/non-visual walkthrough and specialist caption review |
| Technical provenance | Advanced reader can locate exact model and verification evidence | Verified source/version links and one traced UI transition |

## Four verification loops for these features

Use four complete loops **for each feature**, with a genuine independent verifier in every loop. The builder’s own demonstration is evidence but is never the independent verdict. A useful division is:

1. **Correctness and boundaries:** verify the normal lesson, prohibited transitions, state invariants, and the explicit distinction between geometry and authority. Revise against concrete failures.
2. **Novice comprehension:** independently perform the task from a clean first visit, inspect language, sequence, feedback, and recovery. Use real people for claims about human comprehension. Revise.
3. **Equivalent access and adverse states:** verify keyboard/non-visual usage, reduced motion, narrow display, interruption, wrong choices, repeated actions, stale proposal consent, and resumption where supported. Revise.
4. **Integrated release candidate:** a fresh verifier repeats the learning journey and adversarial cases against the exact revised build, checks remaining defects and regressions, and compares the evidence with acceptance criteria. Revise any findings and reverify the resulting build.

Each loop requires a dated verdict, tested build identity, cases attempted, observed results, severity, and specific revision evidence. If a loop finds no defect, record that fact with its coverage; do not fabricate a change just to satisfy a count. A failed fourth loop is not a release gate passed: its revision must be independently retested, and further loops continue until the feature meets the stated gate. Four loops are the minimum floor, not permission to ship a known failure.

## Limits and next evidence needed

No claim is made that the current mathematical implementation is correct or incorrect. Numerical values and visuals were observed, not certified. Source/model inspection is necessary before changing formulas, coordinate conventions, topology descriptions, or state transitions. Mobile layouts, screen readers, persistence, real multiuser operation, and backend authority enforcement were outside this specialist’s bounded review; they should be covered by the other reviews or explicitly marked untested. The observed front-end demonstration of consent boundaries is not evidence of secure real-world authorization.
