# Hopf Workshop implementation prompt — independent package verification

Reviewer: independent prompt/package verifier, agent `/root/prompt_verifier`  
Date: 15 September 2026  
Scope: implementation-prompt quality and consistency with the five specialist reviews. No site implementation, browser execution, mathematical certification, or additional human usability testing was performed by this reviewer.

## Result

The prompt provides a strong, enforceable interpretation of the requested four loops per feature. It requires four separate independent initial reviews, four independent closure checks after builder responses, at least two independent verifiers per feature, and an additional final integrated acceptance. It explicitly prevents the fourth revision from being delivered without independent verification. It preserves failed findings, records candidate identities, reopens affected acceptance after later changes, and does not invent revisions when no defect is found.

The remaining recommendations below tighten feature contracts and coverage. None establishes a new defect in the deployed website. The parent is revising the package concurrently; this report preserves the recommendations and records the corrections directly observed during review.

## Ranked actionable findings

### PV-01 — Medium: readiness wording can imply an automatic phase transition

**Location:** §9, F18, read together with F22; §4 item 7 and §11's four-seat sequences.

**Text reviewed:** “all required active seats ready closes round.”

**Concern:** This compresses the readiness prerequisite and the explicit Close round command into one statement. Elsewhere the prompt correctly preserves separate readiness, closure, commitment, and action operations. An implementer following F18 literally could automatically advance phase when the last seat becomes ready, contradicting the explicit action sequence.

**Revision:** Say: “Each seat's readiness is visible; all required active seats being ready satisfies the readiness prerequisite for explicit Close round. Readiness alone does not advance the phase or count as consent.” Confirm the exact phase rule against the normative contract, as already required by §3.

**Acceptance:** A test records all required readiness while remaining in the current phase until the explicit allowed Close round action is performed. The test does not infer commitment from either readiness or closure.

**Status at review:** Sent to the integrator for correction.

### PV-02 — Medium: user-facing technical provenance lacks an explicit feature contract

**Location:** §9 feature register, with related §3 source discovery and §4 items 1 and 10. Specialist source: learning review LEARN-08.

**Concern:** The prompt tells builders to inspect authoritative source and preserve advanced explanations, but does not explicitly require the visitor-facing “How this model works” feature recommended by the learning specialist. This is a distinct discoverability and trust requirement. Internal source inspection alone will not make the displayed provenance actionable for a visitor.

**Revision:** Add a dedicated feature for an optional “How this model works” surface that explains the normative model in ordinary language and links the simulation rules, mathematical definitions, and actual versioned validation evidence. Each link must resolve to evidence supporting its associated claim. Expose only verified build/version identity; do not invent the live deployment's SHA or imply that the browser executes Python.

**Acceptance:** An independent verifier follows the links from the running interface and traces one representative UI transition to the authoritative rule and relevant test evidence. The basic lesson remains usable without reading this material. This feature receives its own four loops.

**Status at review:** Sent to the integrator for correction.

### PV-03 — Low: specialist findings need explicit disposition mapping

**Location:** §6 findings, §9 feature register, §13 durable records.

**Concern:** The H table deliberately compresses many specialist observations. Most recommendations are present elsewhere, but the package does not explicitly require an accountable mapping from every specialist finding to a feature and acceptance criterion or an explained disposition. Without that mapping, later agents may miss detail while claiming comprehensive implementation.

**Revision:** Add a compact mapping for C1–C8, V-01–V-10, A11Y-01–A11Y-10, LEARN-01–LEARN-08, and QA-01–QA-06, plus findings discovered during implementation. Record mapped feature IDs, acceptance criteria, current status and any evidence-backed decision to defer, reject or narrow a recommendation. Findings are not automatically extra independent features, but their disposition must be visible.

**Acceptance:** The final reviewer checks that every original specialist finding has a traceable disposition and that no unresolved high issue was hidden by aggregation into a broad feature.

**Status at review:** Sent to the integrator for correction.

## Corrections already observed during independent review

| Issue | Initial gap | Correction observed | Disposition |
|---|---|---|---|
| QA-01 proposal/agreement/event version ambiguity | §6 did not explicitly reproduce an active v1 bridge agreement alongside proposed v2 orchard, with the bridge action logged under a v2 prefix | New H14 explicitly describes the sequence and requires unambiguous executed-agreement attribution while preserving intentional v1 activity | Prompt coverage gap closed; website defect still requires implementation and testing |
| QA-02 retained checked review inputs | The earlier finding list did not directly name checked draft controls versus missing recorded review for the replacement version | New H15 explicitly distinguishes editable review inputs from recorded version-specific evidence and allows reset or clearly labeled draft retention | Prompt coverage gap closed; website behavior still requires implementation and testing |
| A11Y-01 focus loss in both tables | H03 originally named only four-seat Ready/Yes, although the specialist also reproduced Parade Yes dropping focus | H03 now explicitly names four-seat and Parade behavior and requires stability in both tables | Prompt coverage gap closed; accessibility defect still requires implementation and testing |

These corrections were read directly from the revised prompt. They are not claims that the deployed website changed.

## Mandatory-loop and claim-discipline checks

| Check | Assessment |
|---|---|
| Four loops for every feature, including discovered child features and retained functionality | Explicit in §§1, 9, 10, 13 and 14 |
| Actual author/verifier separation | Explicit in §2; separate agents/contexts, patch authorship rule and at least two verifier identities |
| Independent check of the fourth revision | Explicit in §10 loop 4; an additional final site audit is required |
| Failed history preserved | Explicit in §§2, 10 and 13 |
| No fabricated cosmetic revisions to manufacture four commits | Explicit, with independently accepted builder disposition and fresh coverage required |
| Repeated screenshots cannot stand in for independent testing | Explicit in §§1, 10 and 11 |
| Final candidate identity and stale-evidence handling | Explicit in §§10, 13 and 14 |
| Unsupported human, mobile, screen-reader or production-readiness claims prevented | Explicit in §§11 and 14; unavailable environments are distinguished from PASS |
| Historical verification distinguished from new tests | Explicit in §3 |
| Live deployment SHA not assumed from repository SHA | Explicit in §3 |
| Geometry cannot supply consent or authority | Repeated explicit invariant in §4 and test requirements |
| Existing v1 agreement versus newly proposed v2 distinguished | Explicit in §4 item 4 and F13–F14; H14 now names the observed misleading event labeling |
| Current task remains an audit and future execution prompt | Package contains proposed implementation requirements; this verification did not execute them |
| Scope bounded to workshop design and reliability | §5 excludes unrelated portfolio production integrations and unnecessary framework migration |

The accessibility and mathematical specialist reviews correctly qualify their evidence. Their proposed human-comprehension criteria, approximate diagnostic contrast calculations, and unverified numerical interpretations must remain labeled as recommendations or bounded observations in the synthesized report. The implementation prompt generally preserves these distinctions.

## Evidence inspected

- `deliverables/HOPF_WORKSHOP_IMPLEMENTATION_PROMPT.md`, all sixteen sections and the 45-feature seed as initially supplied, plus H03/H14/H15 amendments visible during this review.
- `reviews/clarity-review.md`.
- `reviews/visual-review.md`.
- `reviews/accessibility-review.md`.
- `reviews/learning-review.md`.
- `reviews/reliability-review.md`.

The five specialist reviews explicitly did not inspect repository source. Therefore, the synthesized report should separately attribute repository SHA, Python-normative status, default Bundle-map planning requirements and learning-packet compatibility details to the parent's source inspection, rather than suggesting those claims were established by the five browser reviewers. This is an attribution requirement, not a finding that those source claims are false.

## Append-only closure — revised prompt and synthesis

**Date:** 15 September 2026  
**Reviewer:** `/root/prompt_verifier`  
**Verdict:** **PASS for this package-review scope.** PV-01, PV-02 and PV-03 are closed. No remaining factual or claim-consistency issue was found within the requested closure scope.

This closure follows an independent reread of the revised implementation prompt and the complete synthesized expert review. It supersedes the earlier “sent to the integrator” statuses without deleting them. It does not certify the deployed website, mathematical implementation, or completion of the future implementation loops.

| Finding/check | Revised evidence inspected | Closure |
|---|---|---|
| PV-01: readiness versus explicit closure | §9 F18 now explicitly says readiness alone does not advance phase and permits the separate Close round command; F22 preserves its own prerequisites and phase-change rule | PASS |
| PV-02: visitor-facing provenance | §9 F46 requires accessible rules, mathematical explanations and versioned validation context; links must resolve and match claims; verifier must trace one UI transition to its normative rule and test evidence. The universal four-loop requirement includes F46 | PASS |
| PV-03: complete finding disposition | §9 now enumerates every original reviewer-ID range, each H finding and newly found issues; each maps to feature IDs, numbered acceptance criteria and an evidence-backed disposition. §13 includes `finding-to-feature-map.md` | PASS |
| Earlier H03/H14/H15 corrections | Both-table focus loss, executed-agreement version attribution and draft-versus-recorded review remain explicit | PASS |
| Synthesis counts and loop description | Five reviewer groups total 42 findings: 8 + 10 + 10 + 6 + 8. The 46 feature seeds require at least 184 loops before feature expansion. These are expressly future requirements, not completed results | PASS |
| Synthesis source attribution | Parent repository inspection is identified separately from specialist browser work. Repository SHA is distinguished from the unestablished deployed commit; executable tests are expressly not rerun | PASS |
| Synthesis reliability interpretation | Retained active v1 after proposed v2 is distinguished from an alleged consent bypass; event-version ambiguity and mismatched outcome text are stated accurately against the reliability report | PASS |
| Synthesis evidence limits | Desktop scope, unavailable mobile/screen-reader/multi-engine checks, numerical noncertification, bounded contrast calculations, unverified source-character fidelity and unvalidated lesson duration remain explicit | PASS |
| Current-task claim discipline | The synthesis explicitly states that the site was not rebuilt or deployed and the four implementation loops were not performed in this audit | PASS |

### Examined artifact identities

SHA-256 values were obtained with the shell command `sha256sum` for the exact two files reread:

```text
2a7a12f1164b76b3d45a7ca72a9ce7a359c102ebc3da6f3dece06f788350f50a  deliverables/HOPF_WORKSHOP_IMPLEMENTATION_PROMPT.md
5e3f417d1fa27e7234856220bd5e45c6a73e789cf8f35a0fdba82c88f0e7952f  deliverables/HOPF_WORKSHOP_EXPERT_REVIEW.md
```

Both paths are relative to `/workspace/scratch/f010e12589ff`. This acceptance applies to those content identities. A material later edit requires an appropriately scoped recheck. Repository facts in the synthesis were checked for correct attribution and consistency with the supplied review package; this closure did not independently rerun the parent's repository inspection.
