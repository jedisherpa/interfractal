# Independent functional reliability review

Reviewer role: QA, state transitions, error recovery, and evidence traceability. Observed live on 2026-09-15 at https://hopf-workshop.vercel.app/ in a separate browser tab, ID 6. This review exercised the public teaching simulation through visible controls. It did not change the website code, inspect hidden runtime state, call private endpoints, or make real-world commitments.

## Assessment

The teaching model enforced several important boundaries correctly during this review: readiness did not become consent; closing a round did not become commitment; ACT required commitment; duplicate RETURN did not apply the same outcome again; withdrawal paused an agreement; repair did not automatically restore action; retirement blocked action. Preserve these behaviors.

The largest reliability problem visible to a learner is knowing exactly which proposal, agreement, review, and action a displayed state refers to. The three-seat replacement flow can show an ACTIVE heading beside an unapproved v2 proposal, then perform the still-active v1 action while recording it under a v2 event label. The four-seat surface also hides essential state behind a rolling text log. These issues can make a functioning rule system feel inconsistent and can teach the wrong lesson about what was authorized.

This is a bounded browser review, not a security audit or proof of full implementation correctness. Findings below separate UI evidence from inferred causes.

## Confirmed strengths

1. Four-seat commitment from the initial state produced a visible denial listing bounded test, authority, safety, and current-version consent as missing.
2. Close round before readiness was denied with “Each active participant must record their own readiness. Absence is not consent.”
3. Begin ACT during PLAY was denied because it is available during COORDINATE.
4. All four Ready clicks plus recorded review flags still left “explicit current-version consent missing.” Commit remained blocked.
5. With all seats ready, Close round moved PLAY to COORDINATE without creating commitment. Begin ACT was still denied with “Hopf commit is required before ACT; readiness is not authorization.”
6. Four explicit Yes clicks, Commit, Begin ACT, Record Maya's outcome, and RETURN completed a cycle. The result was PLAY, round 2, Ready none, and Last RETURN “r1: 1 applied.”
7. A second RETURN was denied and left round 2 and the applied-outcome count unchanged.
8. Three-seat Act before agreement was denied. Review plus all three Yes clicks and Commit produced ACTIVE; Act then recorded a simulated action.
9. After proposing a replacement, the three consent displays reset to unset and commit blockers again required review and consent for the replacement.
10. Bea withdraws moved the existing agreement to PAUSED. Resolve repair removed the repair blocker but did not restore action automatically. After new review, all three fresh Yes clicks and Commit, v2 became active.
11. Release / retire produced RETIRED; Act was denied afterward.

## Findings and acceptance criteria

### QA-01 — The proposal, active agreement, and action version are visually conflated

Severity: P1 for user trust and teaching correctness. Confidence: high in the observed behavior; the permissibility of continuing v1 requires the normative model contract and should not be casually changed.

Reproduction:

1. On the three-seat table, check Bounded test, Authority, and Safety, then Record review.
2. Select Yes for Maya, Finn, and Bea; Commit; Act.
3. Click Propose replacement with the default orchard text.
4. Observe ACTIVE beside “v2: Carry the dragon through the checked orchard route,” three unset consent states, and missing-review/current-version-consent blockers.
5. Click Act.

Observed event: “09 simulated_action v2 Carry the cardboard dragon over the bridge.” The earlier committed action was the v1 bridge route. A later withdrawal record clarified “Bea stopped participation in agreement v1,” but the event prefix was again v2.

Interpretation: continuing an independently retained v1 agreement may be intentional and safe. The interface does not clearly explain this separation, and the event label suggests a v2 action even though its body describes v1. This is not evidence that the unconsented orchard proposal itself executed.

Required implementation: show separate current proposal and active agreement cards, each with its version and status; bind Act's visible label and confirmation context to the actual agreement/action; record both proposal context and executed agreement version when both matter. Do not silently retire v1 just to remove the UI contradiction.

Acceptance: an independent verifier repeats this sequence and can identify, before clicking, which action will occur and under which agreement. The resulting event unambiguously references that agreement. New proposal consent is never mistaken for old agreement consent, and old authorization is never copied to the new proposal.

### QA-02 — Review controls visually retain old approvals after replacement

Severity: P2. Confidence: high.

After the QA-01 replacement, the Bounded test, Authority, and Safety checkboxes remained checked while the status said bounded test not passed, required authority missing, and safety check missing or blocked. Clicking Record review again cleared these blockers. The controls appear to be editable draft inputs, but that distinction is not expressed.

Required implementation: distinguish draft review inputs from recorded review for a particular version. Prefer resetting draft controls on replacement unless a clearly labeled draft-preservation design is intended. Show “Not recorded for v2” until submitted and display the recorded version afterward.

Acceptance: a learner never sees checked controls that look like completed requirements while their corresponding recorded requirements remain missing without an adjacent explanation. Replacement cannot reuse recorded review silently.

### QA-03 — Four-seat outcome text does not match the committed scenario

Severity: P2. Confidence: high.

The successful cycle committed “Carry the cardboard dragon over the bridge.” Record Maya's outcome then logged “Maya: completed - checked orchard walk.” RETURN accepted and applied this toy outcome. No UI action changed the four-seat proposal to an orchard route.

Required implementation: make the sample outcome consistent with the committed action, or explicitly identify it as contrary evidence and teach how discrepancy is handled. Associate outcomes with the relevant round, agreement version, participant, and event identity. Do not merely change a label while leaving mismatched identifiers beneath it.

Acceptance: the full cycle produces outcome text that accurately represents the scenario and can be traced to the authorized agreement. A deliberately contradictory outcome is clearly presented as a discrepancy rather than routine completion.

### QA-04 — Four-seat state is hard to verify without reconstructing a rolling log

Severity: P2. Confidence: high.

The four-seat summary displayed Round, Ready names, and Last RETURN. It did not display persistent per-seat current-version consent or an active agreement summary. After clicking all Yes controls, the current status was only “consent: Sam: true.” The visible ledger retained the most recent six events: earlier proposal and review records fell out as later events arrived. The statement “RETURN keeps the ledger” therefore cannot be fully inspected through the available visible history.

The four-seat surface also exposes only Yes for consent; there are no visible No or Withdraw controls. The three-seat table does offer these controls. This is a public teaching-surface omission, not proof that the underlying domain model lacks withdrawal.

Required implementation: a compact participant matrix should show readiness separately from consent, with version and timestamp/event reference where useful. Show the current agreement, review state, phase, and next valid action independently of notifications. Add an expandable full history and suitable export for the teaching session. Provide safe ways to explore No/withdrawal, or deliberately link to the three-seat lesson that teaches them.

Acceptance: after more than six events, a verifier can inspect the entire session sequence through the UI; it is clear which seats said Yes to which proposal; Ready never visually substitutes for Yes; all actions have an explicit target. The design accurately labels any history retention limits.

### QA-05 — The workflow presents valid and invalid actions with little step guidance

Severity: P2. Confidence: high.

The four-seat panel showed Commit four-seat proposal, Close round, Begin ACT, Record Maya's outcome, and RETURN as enabled from the initial PLAY state. Guard denials were correct, but the order had to be discovered by trying controls and reading a dense text trail. Commit appears before Close round in the button order, though the teaching cycle benefits from an explicit PLAY → COORDINATE → ACT → RETURN explanation. This is not a request to weaken or remove domain denials.

Required implementation: a phase stepper and short next-step guidance; prerequisites attached to each action; clearly distinguish an ordinary guided action from a deliberate “try a blocked action” lesson. Keep denial explanations accessible even when controls are disabled.

Acceptance: a first-time user can complete a cycle with one obvious next step at each phase. Independent adversarial checks still prove that invalid ordering is rejected below the UI layer.

### QA-06 — Reload clears the session with no visible persistence contract

Severity: P2 if learner progress is intended to survive visits; P3 if explicitly ephemeral practice. Confidence: high in observed reset.

After round 2 in the four-seat table and a retired v2 agreement in the three-seat table, browser Reload returned the four-seat table to PLAY round 1, Ready none, Last RETURN dash and only the initial proposal event. The three-seat table returned to v1, no agreement, unset consents, unchecked review controls, and its initial proposal event. No in-page reset/persistence explanation or export control was present in the inspected DOM.

This is acceptable for a transient toy only if taught clearly. “RETURN keeps the ledger” should specify whether that means only the current page session.

Required implementation: choose and communicate the session contract. If progress should persist, implement versioned local save/resume with migration and corruption recovery appropriate to a teaching tool. If intentionally ephemeral, say so before the learner invests effort and offer restart plus useful export. Never restore a retired agreement as active.

Acceptance: reload behavior matches the stated contract and is independently tested. Export/resume preserves event identity and retirement/withdrawal state when supported; no stale approvals silently reappear.

## Interaction coverage inventory

| Surface / scenario | Result | Evidence limit |
|---|---|---|
| Four-seat initial Commit | Correctly denied, four prerequisite categories | UI only |
| Close round without readiness | Correctly denied | UI only |
| Begin ACT during PLAY | Correctly denied | UI only |
| Ready all + review without Yes | Commit correctly denied | UI only |
| Ready all → Close round | COORDINATE without commitment | UI only |
| Begin ACT before commit | Correctly denied | UI only |
| Yes all → Commit → Begin ACT | ACT reached | UI only |
| Record Maya's outcome → RETURN | Round 2; one outcome applied; readiness cleared | Outcome detail mismatched committed scenario |
| Duplicate RETURN | Denied; count/round unchanged | Rapid concurrent double-click not tested |
| Three-seat initial Act | Correctly denied | UI only |
| Three-seat review + Yes all + Commit + Act | Active agreement; simulated action recorded | UI only |
| Three-seat proposal replacement | Consents reset and fresh review needed | Active agreement/proposal display and event-version ambiguity found |
| Replacement while v1 active → Act | Existing bridge action recorded under v2 event prefix | Contract interpretation requires normative model |
| Bea withdraws → Resolve repair → Act | Paused; repair resolved; Act remains denied | Repair text used supplied sample |
| Fresh v2 review + Yes all + Commit | v2 active | UI only |
| Release / retire → Act | Retired; Act denied | Recommit-retired and replacement-after-retirement not exercised |
| Reload | Both tables reset to initial state | No hidden storage inspection |
| Browser console sample | Only extension-origin errors in sampled warning/error logs | No assertion that all site console paths are error-free |

## Independent verification requirements for implementation

For every feature, complete at least four evidence-bearing cycles, with implementation and verification performed by different agents. A cycle is implementation/revision at a recorded candidate commit, independent UI and relevant domain tests at that exact candidate, a written failure report, then revision driven by that report. Do not call four screenshots of one success path four cycles. Do not require pointless edits when a verifier finds no defect: record no-change with evidence and still perform the next independently designed cycle.

Suggested focus sequence for each feature: (1) ordinary task and semantics, (2) invalid ordering and denied actions, (3) lifecycle transitions, version changes and recovery, (4) cross-feature regression and accessible use. At least one fresh verifier should challenge the builder's interpretation of each authority or versioning feature. Following the fourth revision, independently verify the final candidate again so the delivered code is not an unverified last change. Any material late change reopens affected feature and integration checks.

Use explicit oracles: phase, proposal version, agreement version/status, consent version for every participant, review version, outcome identity, ready set, round number, and history event references. Preserve the invariant that geometry/display state does not authorize; readiness is not consent; review is not consent; closing a round is not commitment; repair is not renewed authorization; and retirement does not revive in place. Browser tests demonstrate the interface; normative-model and parity tests establish behavior below it.

## Untested risks

No mobile device or touch-specific testing, screen-reader session, complete keyboard traversal, multi-browser compatibility, long-session performance, full mathematical correctness, JS/Python parity, persistence corruption, user-controlled malformed input, rapid/concurrent event race, offline mode, or external integration testing was performed by this reviewer. No real multiplayer identity assurance, authentication, server-side permissions, security or data-protection claims are supported by this review. Those must have explicit owners and evidence in the implementation phase where applicable. Another reviewer's evidence can complement this inventory but must remain separately attributed.
