# Hopf Workshop — independent visual design and responsive interaction review

Reviewer role: visual design, hierarchy, interaction affordances, and responsive layout. Review date: 15 September 2026. Public deployment reviewed: https://hopf-workshop.vercel.app/. Browser tab: 5.

## Verdict

The workshop has a recognizable visual identity and a substantive working teaching interface. Its strongest ingredients are the sky palette, voxel character scene, expressive serif headings, named participants, explicit agreement states, and a real geometry drawing. The principal design problem is allocation of attention: a large secondary practice table occupies the entrance, while the geometry and main learning scenario appear below it; the main scenario is then compressed into a narrow column. Many controls look equally important, although their meaning and consequences differ substantially.

The highest priority visual repair is more fundamental than taste: the geometry canvas is displayed at an aspect ratio different from its native drawing dimensions. Preserve geometric proportions before adding new visual effects. After that, organize the screen around one understandable learning task and reveal specialized controls as the learner reaches them.

This review does not establish production reliability or mobile readiness. It records desktop observations and supplies explicit criteria for future verification.

## Evidence and scope

I inspected actual full-page and viewport screenshots, the rendered accessibility-oriented DOM, and read-only computed layout/style measurements. I opened Bundle map and verified its displayed caption and pressed state changed. I then moved focus away and inspected both view buttons again. I did not alter the underlying protocol or run a consequential workflow.

The initial viewport measured 1363 × 936 CSS pixels. The page measured 2745 pixels in height and did not exceed the viewport horizontally at that width. Native mobile sizing or browser viewport control was not advertised in this browser interface, so I did not emulate phones or claim responsive testing. Screenshots were viewed for analysis; they were not exported into this report.

Evidence labels:

- **V-E01 — Initial desktop composition:** hero 1363 × 233; header height 221; four-seat section starts at y=475 and is 577 pixels high; Geometry lab begins at y=1086, below the first viewport.
- **V-E02 — Main columns:** Geometry lab initially 897 pixels wide, Parade table 377 pixels wide; both sections stretch to 1570 pixels high. The geometry controls end far above the bottom of their panel, leaving a large empty area, while the parade controls occupy a tall stack.
- **V-E03 — Canvas:** native attributes width=900, height=520; initial display about 853 × 233 and subsequent display 838 × 233 after scrollbar-related available-width change. Native aspect 1.731; subsequent displayed aspect 3.597. Screenshot shows very shallow geometry and very small embedded labels.
- **V-E04 — Type and controls:** headings use Fraunces, h1 55px and h2 34px; prose uses Source Serif 4 at 21px/34px; button text uses IBM Plex Mono at 13px. Most buttons are 55px high, with pale yellow outlines.
- **V-E05 — View state:** Bundle map changes the canvas accessible description, caption, and aria-pressed. With focus moved away, both view buttons have the same transparent background, 1px gold border, weight 400, and no visible outline. Pressed state is not persistently distinguished by these styles.
- **V-E06 — Hero asset:** rendered image uses object-fit:cover and object-position:50% 40%; natural dimensions 1792 × 1008; rendered height 233px. Screenshot visibly cuts off the top of Joe's hat and much of the scene described by its alternative text. Current source: /docs/visual/B1_two_wants.jpg.
- **V-E07 — Action color/state:** Act and RETURN use #3dbf5a text; No and Withdraw use #e23b5a; outlines mostly #f0c93a; mode label Upper cone uses #5ec8e6; card surface is rgba(243,251,255,.92). Parade Commit is filled gold while the initial status says bounded test, authority, safety, and consent are missing.
- **V-E08 — Forms and information density:** Parade input width is 333px at the inspected desktop width; the proposal visibly truncates inside a single-line field. The three participant cards and their nine response buttons share this narrow column. The initial page exposes two tables, two proposal/commit workflows, and many unexplained protocol or mathematical terms.

## What should be preserved

The sky and pale surface palette relates the interface to Joe's world. Fraunces gives it a storybook identity without forcing the whole application into novelty lettering. Named participants make agreement more concrete than anonymous counts. The geometry view has an accessible description and an explanatory caption, and switching the view demonstrably changes both. The distinction between display coordinates and protocol coordinates is visible. The page tells learners that readiness and consent differ and that topology does not grant authority. These are valuable teaching constraints.

Most buttons already offer generous vertical hit areas, and the observed desktop page had no horizontal page overflow. Preserve those strengths while revising hierarchy. Canonical character fidelity was not verified against the source pose repository in this review; retain existing provenance and have implementation agents verify Joe against the approved assets before replacing or composing any character image.

## Ranked findings and implementation direction

### V-01 — P1: Restore correct canvas proportions and readable geometric labels

**Observed:** V-E03. A 900 × 520 drawing is presented in a box about 838 × 233. Unless the renderer compensates elsewhere, this nonuniform display scaling distorts geometric relationships. The native/display mismatch itself is directly observed; the renderer's internal compensation has not been inspected. The screenshot independently confirms compressed-looking forms and tiny labels.

**Implement:** Inspect the rendering code. Use one coherent canvas sizing model: measure the actual container, set drawing dimensions in CSS pixels, size the backing store for device pixel ratio, and use a corresponding transform; or preserve the intrinsic aspect ratio explicitly. Never stretch a fixed backing image into an unrelated ratio. Place instructional text and legend labels in accessible HTML outside the drawing, leaving only essential spatial annotations inside. Provide a fitted starting view and a reset-view control if camera changes can lose the subject.

**Accept when:** independent reviewers compare the expected projection with the displayed image at all required sizes; known circles/projections retain the intended relationship; every necessary label is readable; no content clips; resizing or zooming does not blur, squash, or change protocol state. Screenshot-based shape checks must be paired with inspection of the rendering dimensions, not inferred from passing unit tests.

### V-02 — P1: Give the entrance one clear next action

**Observed:** V-E01 and V-E08. The first viewport spends its area on art, title, explanatory language, and the second simulated table. The actual geometry begins below the fold. The opening text presumes familiarity with a three-person parade the visitor has not yet seen.

**Implement:** Use a compact welcome area containing a plain outcome, estimated lesson duration only if supported by actual content, and one primary action such as Start the guided workshop. Offer clearly subordinate direct entry into the geometry lab and advanced practice. Put a short explanation in Joe's voice next to a verified canonical pose. Introduce the cardboard-dragon task before displaying its controls. Distinguish the primary lesson and four-seat practice by names, persistent scope badges, and separate visible containers or views.

**Accept when:** at desktop and phone widths a new visitor can locate the primary action without hunting; before acting they can state what they are learning, whether the table is simulated, and which practice they entered. Test this with a reviewer who was not involved in writing the interface. Do not claim a novice usability result merely because an implementation agent says the copy is clear.

### V-03 — P1: Allocate enough width to the real task

**Observed:** V-E02 and V-E08. The narrow Parade table contains participant decisions, proposal editing, prerequisite checks, commitment, action, repair, retirement, and a ledger. It stretches the adjacent geometry panel without using that space productively.

**Implement:** Make the active practice workspace the main content area. On wide screens, a stage/geometry area and a sufficiently wide task panel may sit together; choose proportions from minimum readable content widths rather than a fixed large visual/small controls split. Use start alignment and independent panel heights. On smaller screens, stack stage, current instruction, relevant controls, then ledger. Display three participant decisions as spacious cards or compact rows as width permits. Use wrapping textareas where proposals must be read and edited in full.

**Accept when:** no critical proposal or consent information is hidden by avoidable field clipping; long names and realistic long proposals fit or wrap; controls do not collide; no dead stretched column remains; every supported viewport presents the current task and its feedback in a usable reading order.

### V-04 — P1: Make actionable, blocked, selected, and destructive-looking states distinct

**Observed:** V-E04, V-E05, and V-E07. The view selector loses visible selection when focus leaves. Most actions share a gold outline. Commit looks like the main ready action while the status says prerequisites are missing. This review has not tested whether attempting that action is correctly rejected by protocol logic.

**Implement:** Establish semantic variants: primary next step, secondary action, selected view, neutral response, attention needed, disabled/unavailable, and destructive action where genuinely destructive. Keep keyboard focus visually separate from persistent selection. Show each unmet prerequisite adjacent to the relevant step, with a plain route to resolve it. If pedagogically useful blocked actions remain available, label them as a demonstration and provide an immediate explanation; otherwise disable them with an accessible reason. Do not automatically mark authority, safety, or participant consent simply to make the interface look complete.

**Accept when:** a user can distinguish focus from selection after blur, identify the next allowed action, and understand why an action is unavailable without clicking randomly. Independent verification must show visuals and accessible state agree with actual transitions, including rejection paths.

### V-05 — P1: Repair contrast in semantic colors

**Observed:** V-E07. Bright green and cyan labels are visibly weak on pale cards; yellow borders are also faint. As an indicative calculation against the opaque #f3fbff surface, green text is about 2.28:1, cyan 1.84:1, red 4.01:1, and gold 1.53:1. Actual cards are translucent over a gradient, so these are diagnostic estimates rather than a complete conformance measurement. Orange title emphasis against the top sky color is about 1.86:1; its exact rendered background also varies.

**Implement:** Retain the hues as decorative accents, but choose darker role-specific text and border tokens. Use dark ink on gold fill; use deep green for action text on pale surfaces; use a tested red for refusal/withdrawal labels without making legitimate refusal feel like user error. Do not encode consent or blocking in color alone. Validate final composited colors, focus indicators, and controls at every state.

**Accept when:** the independent accessibility reviewer provides actual contrast measurements for the final UI, including gradient/translucent compositions and hover/focus/disabled treatment where applicable. Use the project's accessibility target, recommended WCAG 2.2 AA, and distinguish essential control boundaries from decorative borders.

### V-06 — P2: Bring action text into the same reading experience as the lesson

**Observed:** V-E04. A 21px serif body sits beside 13px monospace action text, mathematical readouts, and mode labels. Tall buttons with small widely spaced text make the interface simultaneously spacious and difficult to scan.

**Implement:** Keep Fraunces for a small number of headings. Use a readable text face for controls, preferably 15–16px or more at the default size. Reserve monospace for coordinates, logs, and identifiers. Use a restrained type scale and consistent label weight. Break long caveat paragraphs into short contextual guidance attached to the relevant action; retain the full conceptual explanation in an expandable learning/reference area.

**Accept when:** button labels remain readable at ordinary viewing distance and 200% zoom; long labels wrap without truncation; body and controls form an obvious hierarchy; mathematical values retain sufficient precision without dominating the novice task.

### V-07 — P2: Show the character composition intentionally

**Observed:** V-E06. A wide shallow crop chops off the hat and hides most of the island/cabin narrative described by the image.

**Implement:** Choose whether this asset is a full scene or a decorative banner. For a scene, use a responsive art container preserving the relevant composition, potentially with approved crops for width classes. For a compact guide, use the canonical Joe pose library and keep a small complete character next to the instruction. Record source assets and verify character continuity. Supporting scene art may vary; Joe's appearance must follow approved provenance.

**Accept when:** Joe's intended identifying features remain visible in every approved crop; no unintended image stretch occurs; alternative text describes what is meaningfully presented; decorative imagery does not push the starting action out of reach.

### V-08 — P2: Separate learning controls from expert diagnostics

**Observed:** V-E08. Chern integral, holonomy, linking magnitude, torus residual, display/protocol coordinate differences, and authority explanations are exposed together with the story task.

**Implement:** Keep basic geometry interaction and a short explanation immediately available; put detailed numeric diagnostics in an explicitly labeled advanced panel. Use friendly labels paired with their accurate mathematical terms, not inaccurate replacements. Introduce one meaningful relation at a time and show what changed after an interaction. Preserve the mathematical model and protocol boundary; the interface should disclose complexity in stages.

**Accept when:** the beginner route can be completed with understandable instructions while expert reviewers can still inspect all current diagnostics and definitions. No diagnostic or existing capability disappears without a documented equivalent route.

### V-09 — P2: Turn initial blockers into a readable checklist

**Observed:** initial status is a long sentence separated by middle dots, marked by a red rule. In the narrow panel this becomes a tall paragraph. It states what is missing but supplies little visual correspondence to where the visitor should act.

**Implement:** Use a compact, semantically structured prerequisite list associated with the current proposal version and table. Show distinct states such as missing, satisfied, withdrawn, or invalidated. Give each actionable missing item a direct navigational connection to its relevant control. Only use an assertive error treatment after a failed attempted action or a genuinely urgent condition; the normal starting state can be neutral guidance.

**Accept when:** prerequisite changes update the correct list immediately; changed proposal versions invalidate the appropriate checks/consents; initial state looks like the start of a lesson; blocked attempts clearly explain the next step.

### V-10 — P2: Verify mobile and zoom as real product states

**Observed:** no desktop horizontal overflow at the measured width. Mobile, touch, narrow reflow, browser zoom, and screen-reader behavior were not tested in this review.

**Implement and verify:** add a width matrix including 320, 375/390, 768, 1024, and 1440 CSS pixels, portrait and landscape where relevant, plus 200% browser zoom and 400% reflow inspection. Real touch verification or a supported device environment should supplement desktop responsive tooling. Keep control targets generous, avoid nested scrolling that hides feedback, and ensure the canvas is not the only way to learn its information.

**Accept when:** evidence exists for each matrix condition, with screenshots and actual interactions; the report records tested browsers/devices and untested areas. A responsive CSS declaration is not proof of responsive behavior.

## Suggested design system

Keep a small semantic palette: sky background, opaque pale content surface, navy ink, muted readable secondary ink, gold emphasis with navy text, deep green success, deep red attention, and a separate clearly visible focus token. Use roughly 8/12/16/24/32px spacing steps and fewer nested outlined boxes. Give active task cards more visual emphasis than diagnostics. Show proposal version, simulated scope, current stage, and next action together.

Suggested page sequence: compact identity and start/resume action; short task introduction; current stage and progress; active scene plus its current controls; outcome/feedback; optional ledger; optional geometry details and secondary practice entry. This is a proposed direction, not an instruction to delete functionality or combine the two tables' state.

## Four independent verification loops per implemented feature

Treat V-01 through V-10 as candidate feature/work packages, but derive the final feature inventory from the actual repository so no existing behavior is omitted. For every feature, record four distinct implement → independently verify → revise cycles, followed by the required independent check of the final revision. Rotate or otherwise separate the verifier from the person/agent that made the implementation; do not use a builder's self-rating as independent verification.

1. **Loop 1, meaning and main path:** verify the feature's user purpose, basic visual hierarchy, and an actual successful interaction. Revise documented findings.
2. **Loop 2, states and failures:** independently inspect blocked, empty, loading, error, selected, and recovery states as applicable. Revise documented findings, preserving protocol integrity.
3. **Loop 3, access and reflow:** independently run keyboard, contrast, zoom, narrow-width, text-length, and alternative-content checks relevant to the feature. Revise documented findings.
4. **Loop 4, regression and coherence:** an independent reviewer replays the feature in complete workshop journeys and compares implementation with design/authority requirements. Revise findings, then independently verify those revisions and all affected earlier guarantees.

Each loop should retain feature ID, build/commit, reviewer identity/role, environment, exact steps, observed results, screenshots where useful, findings, revision diff, and retest outcome. If a loop finds no defect, record a justified no-change result; do not introduce cosmetic churn to manufacture a revision. Four loops are a minimum effort structure, not a substitute for closure: unresolved material findings mean the feature stays open.

## Limits of this review

No source repository, canvas renderer, mobile browser, persistent storage, network behavior, deployment pipeline, mathematical proof suite, or complete protocol path was inspected by this reviewer. I did not independently establish canonical image fidelity. Findings labeled observed come from the rendered desktop UI; proposed redesign benefits and untested risks are recommendations for implementation and verification, not claims of measured user performance.
