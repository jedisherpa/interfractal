# Hopf Cycle Visualizer — orchestration package

**Status:** planning grant + first-page addendum. **Not a runtime implementation.**
**Date:** 16 September 2026
**Owner:** Paul Cooper (JediSherpa)
**PR:** https://github.com/jedisherpa/hopf-workshop/pull/10

## Read order

1. This file
2. `10_FIRST_PAGE_UX.md` — Interfractal first page (hole / light / press / fibers / levels / Cloud Nine)
3. `11_INTRO_FEATURES.md` — I01–I10 and V-INTRO gates
4. `02_COSMOLOGY_LOCK.md`
5. `05_INHERITANCE_MATH.md`
6. `04_VISUALIZER_CYCLE_SPEC.md`
7. `01_MASTER_PROMPT.md` — later cycle grant; not begin
8. `03_MULTI_AGENT_ORCHESTRATION.md`
9. `06_TRACKING_AND_VERIFICATION.md`
10. `07_OPEN_QUESTIONS.md`
11. `08_HANDOFF.md`
12. `09_BUILD_AGENT_PROMPT.md`
13. `contracts/` including `first-page.md`

## First page, one sentence

White hole, light hole; press the dot; fibers fill the screen; Impossible Cube; Level 4, 3, 2, 1; you are at the beginning of Cloud Nine — a place where clarity keeps everything from being black and white.

## Do not implement from this package alone

No new wells, rain, eight seats, cycle player, GMD login, or kernel rewrite. The live four-world host stays. Say begin to build I01–I10.
