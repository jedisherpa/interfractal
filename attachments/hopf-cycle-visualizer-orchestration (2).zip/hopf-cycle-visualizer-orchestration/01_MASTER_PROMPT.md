# Master prompt — public Hopf cycle visualizer

Prepared for Paul Cooper · 16 September 2026

Copy this entire document into a later coding environment only after Paul says **begin**. This file is a grant *shape*. Until that word, it is planning.

Attach this whole zip. If attachments are missing, this prompt still contains the lock. Record missing evidence and inspect the live host before inventing coordinates.

---

## 0. Execute this outcome (when activated)

Build a **public, no-login** visualizer that can:

1. **View Whole Cycle** — fall from Cloud Nine, land in the garden, open W1 then W2 then W3 then W4, auto-select one of five return pathways or latch Clusterfuck, return or disperse, land again with holonomy.
2. **Scrub** up and down the stack and show how each decision was made.
3. Show **carry down** and **carry up** of settled choices without turning carry into a Yes.
4. Keep the Hopf Workshop kernel as the only permission engine.

Do **not** treat this prompt as permission to:

- push or open PRs
- add GMD / Sphere / Deal login
- move DEC-VP-01 wells
- replace TAWarRoom
- claim GMD *is* the Hopf fibration
- implement eight GMD interiors
- mint consent from animation

Finish a reviewable implementation and an evidence package. Independently verify, revise, independently verify again, for **at least four full loops per feature**. Independently verify the fourth revision too.

---

## 1. Baseline to inspect first

| Thing | Stamp / note |
|---|---|
| hopf-workshop tree | `dd0ab5ea42e34fb53ebee461f7fc6831d6415205` at last inspection |
| hopf.js blob | `c36df81e8421c07e3e89bce3d9c59e75b6d74698` |
| Python | normative in hopf-workshop |
| Discipline | `docs/DISCIPLINE.md`, `VERIFICATION.md` |
| Live teaching host | four nested worlds already flying; Decision Well off-axis; Ready ≠ Yes |
| This zip | cosmology + cycle viewer grant; nests under, does not replace, `docs/tawarroom-flagship-planning/` |

Confirm remotes, branch, dirty state, and whether `main` has moved. Preserve user-owned dirty files. Do not reset to historical SHAs.

Python remains normative. A new renderer is not a new permission engine.

---

## 2. Product lock (do not “improve”)

Read `02_COSMOLOGY_LOCK.md` and `05_INHERITANCE_MATH.md` as requirements.

Short form:

- Five GMD chambers: Cloud Nine + W1 Self + W2 Tribe + W3 World + W4 Earth.
- Eight **entrances** at W1: Physical, Emotional, Intellectual, Social, Spiritual, Environmental, Occupational, Financial. Align beliefs. Keep them. Visiting is not Self.
- Endings: **Cloud Nine** or **Clusterfuck**.
- Five return **fibers** from Earth: P0 Vapor, P1 Self, P2 Tribe, P3 World, P4 Earth. Clusterfuck is not P5.
- Carry settled facts down and up. Carry ≠ inherited Yes.
- Auto-select by published dominance. Unique max above threshold → that fiber. Else Clusterfuck. P0 only for thin-but-coherent, never for a mess.
- Public. No login.
- 2D fallback required.

---

## 3. Preserve the workshop rules

1. Topology does not authorize.
2. Ready is not Yes. A suggestion is not a grant. Confidence is not a grant.
3. Display \(z\) is not protocol \(z\) until Explore.
4. New draft does not silently inherit old Yes. v1 may coexist with v2.
5. Withdrawal pauses. Repair does not restore consent. History is append-only.
6. RETURN is not a reset. Cycle restart is RETURN-shaped: apply once, keep the ledger.
7. People are not fibers. Dimensions are not people. Entrances are not worlds.
8. Hourglass is process vocabulary, not the bundle.
9. Humans attest. Agents do not ratify. Practice seats (Maya, Finn, Bea, Sam) are fictional.
10. Wizard Joe may teach. Joe cannot consent.
11. Camera, scrub, Play Cycle, orbit, hover, and replay cannot Commit, Act, or Explore unless the user issues that command in the inspect UI.
12. Public observation is not assent.

Represent the rules in the interaction. Do not wallpaper the stage with caveats.

---

## 4. Features to build (when activated)

Feature ids match `06_TRACKING_AND_VERIFICATION.md`.

| Id | Feature |
|---|---|
| C01 | Lock table in UI copy (worlds, endings, eight names) |
| C02 | Eight entrance seats on the cube (or star-tetra if Paul picked it) |
| C03 | Hold-over-time within session (saved versions only if SAVE_VERSION 2 is granted) |
| C04 | Carry-down marks |
| C05 | Carry-up holonomy marks |
| C06 | Five-pathway auto-select, inspectable scores |
| C07 | Clusterfuck ending |
| C08 | View Whole Cycle |
| C09 | Layer scrubber + Inspect Decision |
| C10 | No-login public route |
| C11 | 2D fallback of the same facts |
| C12 | Reduced motion |

A person who implements a feature cannot accept that feature. Four loops each.

---

## 5. Team

Five disciplines, same spirit as the workshop visualizer grant:

1. Cosmology / product lock
2. Visual design + accessibility
3. Inheritance math + dominance
4. Kernel parity (do not fork `hopf.js`)
5. Independent verification

Coordinator integrates. Verifiers may explain a defect; if they supply the patch, another verifier accepts it.

---

## 6. First useful screen

A visitor with no account can:

- press **View Whole Cycle** and understand fall → four spheres → return or clusterfuck
- scrub to Tribe and see that arriving as a Self did not sign Maya’s Yes
- open Inspect and see Ready standing next to unset, not next to gold

If they cannot do those three things, the feature is not done.

---

## 7. Hard stops

- Do not implement this prompt against the live wells host until Paul names the host repo and branch.
- Preferred later hosts (pick, do not assume): a public route on hopf-workshop, or a standalone cycle viewer that vendors `hopf.js`.
- `jedisherpa/fractal-block` Babylon 8 remains a different product. Do not silently port combat.
- Do not push `main`. Do not deploy production.

---

## 8. Done means

Typecheck / kernel parity tests pass. Fixtures for both endings pass. V-CYCLE-01 through V-CYCLE-10 in `06` are PASS or explicitly blocked with the missing capability named. Evidence zip attached. Coordinator does not mark PASS on their own work.
