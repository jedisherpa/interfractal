# Cosmology lock

**Date:** 16 September 2026
**Authority:** spoken lock this turn + prior owner tables this day.
**Does not change:** DEC-VP-01 coordinates, DEC-GATE-01 (commit is not a scale key), DEC-SAVE-01 (session-only until Paul bumps SAVE_VERSION), hopf-workshop kernel.

---

## 0. The cycle, not a ladder you throw away

The instrument is a **cycle**.

```
Cloud Nine  --fall-->  W1 Self  -->  W2 Tribe  -->  W3 World  -->  W4 Earth
    ^                                                                  |
    +-------- five return fibers, auto-selected by settled choices ----+
    or
    Clusterfuck (no fiber; eight dimensions dispersed)
```

You either end the game in **Cloud Nine** or in a **clusterfuck**. Those are the two presentations of a finished cycle. They are not two extra worlds.

---

## 1. Five GMD chambers

God’s Mind Dreaming has **five chambers**. The eight are **entrances**, not GMD interiors.

| Chamber | Role in this instrument |
|---|---|
| **Cloud Nine** | Fifth chamber. Living torus you fall from (unearned) and may return to (earned). Not a shrink-layer. Not `ScaleLayerId = 4`. |
| **W1 Self / garden observatory** | Still in the clouds. Align **beliefs** around the eight wellness dimensions. Then keep playing: can you hold them. |
| **W2 Tribe / Cloud Six** | Ideas hold shape. You arrive as a Self, among others. Last written altitude lock; see §7 if Paul finishes the interrupted “cloud six is like…” clause. |
| **W3 World / Cloud Three** | Friends, kept agreements, cloud thickens. Rain hits the ground. Art, business, work beyond the inner circle. |
| **W4 Transcendent / Earth** | Love, nature, family, vision, belief, and weather. Earth is sacred, not a marketplace. Bottom of the playable descent. Auto-selects a return fiber. |

Current teaching host already flies four nested dresses (Garden / Forest / Desert / Core). Dress-to-world mapping is an open question (`07_OPEN_QUESTIONS.md`). Do not move wells until that pick.

---

## 2. Eight entrances (W1 only)

Source: *CLUSTER FU#K — 8 Dimensions To Living Wellness*, Barry Stamos & Paul Cooper.

You must **get them aligned and keep them aligned over time** to demonstrate alignment in Self. Visiting is tourism. Keeping is the test.

| Id | Entrance | Not this later world |
|---|---|---|
| E0 | Physical | — |
| E1 | Emotional | — |
| E2 | Intellectual | — |
| E3 | Social | not Tribe |
| E4 | Spiritual | not Earth |
| E5 | Environmental | not Earth |
| E6 | Occupational | not World-as-rain |
| E7 | Financial | not World-as-rain |

Geometry candidate: Impossible Cube **vertices** = entrances. Gold ring = shrink gate. Dual-use of the cube (gate volume = well) stays forbidden. Stella octangula is an optional overlay (two dual tetras = 8 verts), not a second protocol.

HUD word: `entrance`. Never `gmdChamber` for E0–E7.

---

## 3. Two endings

| Ending | What it is | What it is not |
|---|---|---|
| **Cloud Nine** | You rode a return fiber. The sky you return to. Cycle may start again. Holonomy means the next fall is not the first fall. | A Yes. A login. A fifth shrink-layer. A prize for visiting four statues. |
| **Clusterfuck** | No fiber to ride. Eight dimensions dispersed. Honest name for the unearned / unheld state. Title of the book. | A fifth return pathway. A punishment animation that signs for you. A deleted history. |

P0 Vapor (a thin but coherent return) is **not** Clusterfuck. Thin-and-together still rides a fiber. Dispersed does not.

---

## 4. Five return pathways (fibers, not worlds)

Selected at W4 from settled choices accumulated through the stack. Auto-select. Not a slot machine. Not “the map picked for you.” Replayable in the visualizer.

| Path | Fiber | Dominance picture (candidate) |
|---|---|---|
| **P0 Vapor** | Cloud Nine fiber | Little held below; coherent enough to return thin |
| **P1 Self** | Self fiber | Eight dimensions held as beliefs; Tribe / World / Earth thin |
| **P2 Tribe** | Tribe fiber | Agreements with others held |
| **P3 World** | World fiber | Rain held; work beyond the circle held |
| **P4 Earth** | Earth fiber | Weather, love, nature, family, vision held |

If no Yes-set is settled enough to dominate → **Clusterfuck**, not a default P0.

Paul may rename the five fibers. Do not invent GMD interior chamber names and paste them here.

---

## 5. Keep playing

Self is not a boss fight you clear.

1. Fall into the garden.
2. Align beliefs around E0–E7.
3. **Keep playing.** Descend as a Self.
4. At each world the same abacus runs: Explore, Ready ≠ Yes, reviews, current-version Yes, Commit, Act, Withdraw, Repair.
5. Settled choices carry **down**. Settled choices carry **back up**. See `05_INHERITANCE_MATH.md`.
6. At Earth the dominance function picks a fiber — or fails to.
7. Cloud Nine restart is cycle, not amnesia.

---

## 6. What stays forbidden

- Geometry is not permission.
- People are not fibers. Dimensions are not people. Entrances are not worlds.
- Ready is not Yes. A suggestion is not a grant. Confidence is not a grant.
- Display \(z\) is not protocol \(z\) until Explore.
- New draft does not silently inherit old Yes.
- Withdrawal pauses. Repair does not restore consent.
- Commit is not a scale key (DEC-GATE-01).
- Walking eight cube corners is not alignment.
- Auto-select is not consent for the next cycle’s first Yes.
- No login on the cycle visualizer.
- Do not claim GMD *is* the Hopf fibration. Do not claim Cluster Fu#k *is* the Hopf fibration. Three languages, one instrument.

---

## 7. Interrupted clause

This turn: “it’s actually more clear to say that cloud six is like , and the self is just where you align your beliefs around all of those eight.”

Self is locked as belief-alignment around the eight.

“Cloud six is like…” was not finished. Until Paul finishes it, Cloud Six remains the altitude label on **W2 Tribe** from the last complete table. Do not invent a new Cloud Six world to fill the ellipsis.
