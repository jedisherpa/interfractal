# Multi-agent orchestration

**Status:** Execution map for `01_MASTER_PROMPT.md`.
**Activation:** Paul’s explicit begin. This file does not authorize work by existing.
**Push / PR / deploy:** not authorized by this zip.

This zip is the **cosmology + public cycle visualizer** grant. It does not replace `docs/tawarroom-flagship-planning/`. Live Decision Wells stay shipped.

---

## 1. Path ownership

| Owner | May edit (when activated) | Must not |
|---|---|---|
| Coordinator / integrator | viewer shell, routing, public route, evidence index | hopf.js semantics |
| Cosmology lock keeper | copy, layer labels, ending cards | dominance formula, kernel |
| Inheritance / dominance | carry adapter, dominance function, fixtures for carry | camera, auth |
| Cycle viewer | Play Cycle beats, scrubber, sphere-open presentation, 2D fallback | Workshop commands other than read |
| Protocol inspect | Inspect Decision columns, Ready≠Yes chrome | animation timing as protocol |
| Kernel parity | vendor/update hopf.js only to recorded SHA, parity tests | “simplify” Ready into Yes |
| Independent verification | `docs/tests/*`, screenshots, V-CYCLE ledger | implementation under review |

Serialize: lock copy → failing math tests → carry adapter → dominance → Play Cycle → scrub/inspect → 2D fallback → public smoke.

Parallelize: reduced-motion sheet, 2D paint, accessibility checklist, fixture writing (both endings).

---

## 2. Feature branch (when activated)

Suggested: `docs/descent-cycle-planning` for docs-only, or `feat/cycle-visualizer` for code.

Do not commit on `main`. Do not push unless Paul issues a new grant. This zip is not that grant.

Do not touch weopoly or tawarroom unless a later grant says so. Public no-login here is not permission to strip TAWar auth.

---

## 3. Phase-to-owner map

| Phase | Gate | Owner | Independent check |
|---|---|---|---|
| 0 Baseline | SHAs, dirty state, collision with live wells recorded | Coordinator | Verifier signs the record |
| 1 Failing tests | Carry-down does not stamp Yes; Clusterfuck ≠ P0 | Inheritance | Verifier reviews tests before they pass |
| 2 Public shell | No-login route renders a cycle stage | Coordinator | A11y + verifier |
| 3 Play Cycle | V-CYCLE-01 and V-CYCLE-06 fixtures | Cycle viewer | Verifier |
| 4 Scrub + inspect | V-CYCLE-02, V-CYCLE-03 | Protocol inspect | Verifier |
| 5 Carry marks | V-CYCLE-04, V-CYCLE-05, V-CYCLE-07 | Inheritance | Verifier + math |
| 6 Fallback + motion | V-CYCLE-09, C12 | Cycle viewer | A11y |
| 7 Evidence | Ledger complete, hashes frozen | Verifier | Coordinator cannot accept |

---

## 4. Independence rules

- Implementer ≠ acceptor for the same feature.
- At least two verifier identities across each feature’s four loops.
- Freeze each candidate under review (commit or content hash).
- Give verifiers criteria and fixtures **before** the builder’s success narrative.
- Verifiers may FAIL. Builder cannot rewrite a FAIL into a PASS.
- If browser preview is blocked, record the blocked capability. Do not substitute self-review.

---

## 5. What stays read-only

- hopf-workshop `hopf_model.py` semantics
- DEC-VP-01 well coordinates until a dress grant
- DEC-GATE-01
- DEC-SAVE-01 unless Paul bumps SAVE_VERSION
- TAWarRoom flagship planning
- GMD production auth

---

## 6. Communication

One lock file. Disputes resolve in `02_COSMOLOGY_LOCK.md` and `07_OPEN_QUESTIONS.md`, not in chat lore.

If Paul finishes “cloud six is like…”, update §7 of the cosmology lock and bump the package date. Do not silently relabel W2.
