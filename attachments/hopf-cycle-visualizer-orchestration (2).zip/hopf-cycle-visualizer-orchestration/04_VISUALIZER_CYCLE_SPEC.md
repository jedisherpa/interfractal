# Visualizer cycle spec

**Date:** 16 September 2026
**Audience:** later implementers of a public cycle viewer.
**Auth:** none. No login, no Sphere membership, no Deal, no GMD sovereign-session import.
**Kernel:** view of hopf-workshop (`hopf.js` blob `c36df81e`). This viewer does not become a second permission engine.

TAWarRoom remains the authenticated work desk. This instrument is the public teaching cycle. Do not collapse them.

---

## 1. What Paul asked to see

> Hit view whole cycle. Watch him fall. Land. Watch one sphere open, then another, then another, then another. Go back up to the fall. Land. A controller that lets you go up and down and see how the decisions get made.

Two modes, one ledger.

---

## 2. Modes

| Mode | Job | Must not |
|---|---|---|
| **Play Cycle** | Cinematic, pausable replay of one session’s descent and return | Write protocol \(z\). Mint a second RETURN. Grant Yes. |
| **Scrub** | Vertical controller through Cloud Nine, W1, W2, W3, W4 | Skip holonomy. Hide Clusterfuck. |
| **Inspect Decision** | How each decision was made | Treat Ready as Yes. Treat carry as inherited consent. |

Reduced motion: skip interpolation; snap poses. Same facts.

---

## 3. Play Cycle beats

Fixed order. Pause allowed between beats. Playhead is a view index, not a command.

1. **Fall** — Cloud Nine / La La Land. Dispersed. Eight dimensions unattached.
2. **Land** — garden observatory, still in the clouds. Cube visible. Gold ring is a gate, not a well.
3. **Open W1** — Self sphere. Eight wellness entrance loops. Beliefs aligning (or not).
4. **Open W2** — Tribe sphere. Four seats. Constraints from W1 visible as carry-down marks, seats still unset until they sign.
5. **Open W3** — World sphere. Cloud Three. Rain only if a valid Act exists in the ledger.
6. **Open W4** — Earth sphere. Love, nature, family, vision, weather.
7. **Select** — dominance function picks P0–P4, or fails.
8. **Return or disperse**
   - Fiber: ride the chosen pathway up to Cloud Nine.
   - Clusterfuck: eight loops lose coherence. No fiber. Honest title card.
9. **Land again** — only if a fiber was ridden. Next fall has holonomy phase. Not a reset.

Both endings must be fixture-replayable from the same session log (`V-CYCLE-10`).

---

## 4. Scrub controller

Vertical slider or stepped keys:

```
Cloud Nine
    W1 Self
        W2 Tribe
            W3 World
                W4 Earth
```

- Clicking a layer pauses Play and opens Inspect.
- Up/down does not travel scale in the live game host. This is a viewer.
- Show, at the playhead:
  - carried-down constraints (marks from above)
  - carried-up phase (marks from below)
  - those two marks must be visually distinct
- Camera / orbit / scrub never writes protocol \(z\).

Keyboard: `J` / `K` or arrow keys step layers. `Space` plays/pauses. `Home` Cloud Nine. `End` Earth. `R` replay cycle from log (does not re-apply RETURN).

---

## 5. Inspect Decision columns

| Column | Shows |
|---|---|
| Layer | C9, W1, W2, W3, W4 |
| Draft version | exact version id |
| Seats / entrances | names; dimensions at W1, people at W2+ |
| Ready | boolean, never painted as gold agreement |
| Yes / No / unset | current version only |
| Withdrawn | pause mark |
| Repair open | blocker |
| Carried down | constraints inherited as facts, not Yes |
| Carried up | holonomy / challenged marks from below |
| Dominance | scores for P0–P4 + Clusterfuck latch, inspectable |

Math lens (`M` if the host already uses it): protocol \(z\) vs display \(z\).

Copy that must remain readable without hover: why a command is blocked; why a pathway won; why Clusterfuck latched.

---

## 6. Spheres

“Watch one sphere open and then another” = the world-chart becoming the featured solid, not a loading spinner.

Candidate solids (dress, not authority):

| Layer | Solid |
|---|---|
| Cloud Nine | torus / Clifford torus already used for earned sky |
| W1 Self | cube (8 entrance vertices) or stella octangula overlay |
| W2 Tribe | tetrahedron (4 seats, 6 links) |
| W3 World | existing well / hourglass-as-process only, never as the bundle |
| W4 Earth | torus interior / ground |

Opening a sphere is presentation. It does not Explore, Commit, or Act.

---

## 7. Public surface

- No login wall.
- Session-only ledger.
- 2D fallback canvas paints the same protocol facts if WebGL fails.
- No GPU required for the workshop-faithful 2D path.
- Mobile: stack inspector; keep Play and Scrub reachable; no essential action requires hitting a hidden 3D pick.
- Reduced motion respected.
- Title / share card may exist; they are not protocol.

Do not import “I Am A Real Human.” Do not require an ENS name.

---

## 8. Relationship to the live wells host

The four-world flyable host already shipped is **practice inside a world**.

This cycle viewer is **the map of the whole journey**.

They may share a kernel and a session ledger. They must not share a camera that writes consent. Flying in Garden is not Play Cycle. Play Cycle is not a shrink through the gold ring.

---

## 9. Acceptance pictures (later)

When implementation is granted, evidence must include:

- Play Cycle reaching W4 then a named pathway.
- Play Cycle reaching W4 then Clusterfuck.
- Scrub at W2 showing carry-down from W1 and no forged Yes on Maya/Finn/Bea/Sam.
- Inspector showing Ready ≠ Yes on the same seat.
- 2D fallback with the same version ids.
- No-auth public route loads.
- After a full fiber-return, holonomy phase ≠ identity on the next fall mark.
