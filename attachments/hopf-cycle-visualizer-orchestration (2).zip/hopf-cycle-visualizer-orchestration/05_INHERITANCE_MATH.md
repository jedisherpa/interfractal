# Inheritance math

**Date:** 16 September 2026
**Normative kernel:** hopf-workshop `hopf_model.py` / `hopf.js` (Python remains normative).
**This file defines “carry.” It does not invent a second permission engine.**

Owner requirement this turn: the instrument must carry settled choices of the world **above** into the world **below**, and carry settled choices of the world **below** back into the worlds **above**, all the way through the stack.

---

## 1. What carry is

Carry is **phase and constraint**, not consent.

A settled choice at world \(n\) becomes visible on the chart of world \(n\pm 1\) as:

- a bead that is still on its home fiber (intention still aimed)
- a constraint the next proposal must face
- a holonomy phase the lift remembers

It does **not** become a Yes on a new draft.

---

## 2. What “settled” means

A choice is settled only when all of these hold:

1. Current version.
2. Explicit Yes (or an explicit, recorded No the constitution accepts).
3. Reviews recorded for **this** version.
4. Not withdrawn.
5. No open repair that blocks action.
6. Ready is **not** part of settled. Ready never travels.

If any of 1–5 fails, the choice is not settled. It may still exist as history.

---

## 3. Two directions

### Downward (above → below)

You arrive in the lower world already shaped.

| From | Into | What arrives |
|---|---|---|
| Cloud Nine fall | W1 Self | Dispersed eight. No Yes. The cluster-fuck of unattached dimensions. |
| W1 Self | W2 Tribe | You are a Self. Eight belief-fibers that were *kept* are constraints other people now meet. Social-as-dimension ≠ Tribe seats. |
| W2 Tribe | W3 World | Kept agreements thicken the cloud. World proposals face that thickness. Rain is presentation of a valid Act, not a shrink key. |
| W3 World | W4 Earth | Work-beyond-circle that actually rained is evidence Earth can weather. Occupational/Financial *entrances* stay W1 loops; the rain is World. |

Downward carry answers: **who are you when you get here?**

### Upward (below → above)

What you actually did writes back.

| From | Back into | What writes back |
|---|---|---|
| W4 Earth | W3, W2, W1, C9 | Weather, love, nature, family, vision — if held — re-phase the upper charts. A Self-belief that cannot survive Earth weather does not stay current just because it was Yes in the garden. |
| W3 World | W2, W1 | Rain that happened (or failed) is evidence Tribe and Self must re-hold. |
| W2 Tribe | W1 | Other people’s kept or broken agreements change which of the eight can stay current. |
| Any withdrawal | All charts that carried it | Phase pauses. History remains. Consent is not restored by the picture updating. |

Upward carry answers: **did the lower world keep what the upper world claimed?**

A new draft at the upper world is still a new draft. The written-back facts are constraints, not a forged signature.

---

## 4. Workshop identities that must not blur

Let \(A_n^v\) be agreement version \(v\) at world \(n\).

- \(A_n^{v+1}\) does not inherit responses or reviews from \(A_n^v\).
- Carry from \(A_{n-1}^{u}\) into world \(n\) may **constrain** what \(A_n^{v}\) can honestly propose. It does not fill in Yes for the seats of world \(n\).
- Carry from \(A_{n+1}^{w}\) back to world \(n\) may **mark** \(A_n^{v}\) as still-current or now-challenged. Marking challenged is not a silent No and not a silent withdraw. A human (or practice seat) must still issue the command.
- Explore copies display \(z\) toward protocol \(z\). Camera, scrub, replay, and View Whole Cycle never do that.

---

## 5. Holonomy of a cycle

Workshop holonomy at latitude \(\theta\):

\[
\oint = \pi(1-\cos\theta)
\]

A full descent-and-return is one lift. Landing again in the garden is **not** a reset.

- RETURN applies a pending outcome once and keeps the ledger.
- Cycle restart at Cloud Nine is RETURN-shaped: the chosen pathway (or Clusterfuck) is applied once; history is retained; the next fall has phase.
- Replay in the visualizer must not mint a second application of that outcome.

90° of holonomy sits at 60° of latitude. Use that as a teaching mark on the cycle scrubber if a math lens is on. Do not score a person’s life with it.

---

## 6. Dominance at Earth (auto-select)

At W4 the instrument computes a **dominance** over settled Yes-sets accumulated through the stack.

Candidate (not a moral score):

Let \(S_P\) be the set of settled facts that belong to pathway \(P \in \{P0,P1,P2,P3,P4\}\).

- If every \(S_P\) is empty or below a hold-threshold → **Clusterfuck**. No fiber.
- Else pick \(\arg\max_P |S_P|\) with a documented tie-break (longest held, then lowest world that still holds, then P4 > P3 > P2 > P1 > P0). Publish the tie-break. Do not hide it in animation.
- Thresholds are product constants, not ethics. Record them. Do not tune them to make Cloud Nine more common.

Auto-select is a **presentation and travel** decision. It is not a Yes for the next cycle.

---

## 7. Eight-dimension field

Eight featured fibers. Pairwise links:

\[
L = \binom{8}{2} = 28
\]

Draw eight entrance loops loud. Keep 28 as quiet field.

The book: neglect one dimension and the others slip. The field is how that slip is visible without fusing eight hoops into one.

Breaking a kept dimension (withdraw, challenged-by-upward-carry, new draft) can drop P1 dominance and miss the Self fiber on the way home.

Chern \(|c_1|=1\): there is no single global wellness scalar that signs for you.

---

## 8. Copy-preview vs carry

Copy-preview already exists in the workshop: it must **not** inherit Yes.

Carry is allowed to copy **facts that are still settled** onto another chart as constraints.

Test that must fail a build:

1. Create v1 Yes at W1 Physical.
2. Open a v2 draft at W1.
3. Physical Yes must not appear as v2 Yes.
4. After a settled W1 Self-set, enter W2. Tribe seats must still be unset. The inspector may show “arrived as a Self” as constraint copy, never as Maya’s Yes.

---

## 9. Session-only until SAVE_VERSION 2

“Keep aligned over time” wants duration. This host is session-only (DEC-SAVE-01).

Until Paul bumps persistence:

- “Over time” inside one sitting = holonomy around the cycle + not-withdrawn current-version Yes.
- Visualizer replay uses the session ledger.
- Do not fake durability with `localStorage` accounts or GMD sovereign-session import.

---

## 10. Non-claims

- Carry is not quantum entanglement of people.
- Dominance is not a personality test and not a medical wellness score.
- Holonomy is not karma.
- WillVector cosine-0.8 in Metacanon remains an embedding analogy, not \(\pi\).
- SAMHSA’s eight-dimension chart is a clinical relative; Cluster Fu#k is the local source; Hopf is the kernel. Do not cite SAMHSA as the in-game author.
