# Tracking and verification

**Date:** 16 September 2026
**Rule:** a feature is not done when the builder likes the screenshot. It is done when an independent verifier records PASS against the gate, on a frozen hash, with steps another person can repeat.

This file is the ledger contract. Fill rows when implementation is granted. Empty PASS/FAIL today is correct.

---

## 1. Feature ledger

| Id | Feature | Implementer | Reviewer | Hash | Loops | Result | Forbidden effect checked |
|---|---|---|---|---|---|---|---|
| C01 | Lock table in UI copy | | | | 0/4 | NOT_STARTED | Eight labeled as GMD chambers |
| C02 | Eight entrance seats | | | | 0/4 | NOT_STARTED | Social seat signing as Tribe |
| C03 | Hold over time (session) | | | | 0/4 | NOT_STARTED | Fake account durability |
| C04 | Carry-down marks | | | | 0/4 | NOT_STARTED | Inherited Yes on new draft |
| C05 | Carry-up marks | | | | 0/4 | NOT_STARTED | Repair restoring consent |
| C06 | Pathway auto-select | | | | 0/4 | NOT_STARTED | Hidden random spin |
| C07 | Clusterfuck ending | | | | 0/4 | NOT_STARTED | Clusterfuck painted as P0 |
| C08 | View Whole Cycle | | | | 0/4 | NOT_STARTED | Play writing protocol \(z\) |
| C09 | Scrub + inspect | | | | 0/4 | NOT_STARTED | Ready painted as Yes |
| C10 | No-login public route | | | | 0/4 | NOT_STARTED | Login wall / ENS gate |
| C11 | 2D fallback | | | | 0/4 | NOT_STARTED | 2D missing version ids |
| C12 | Reduced motion | | | | 0/4 | NOT_STARTED | Facts only in animation |

Four loops per feature. Loop 4 is also independently verified.

---

## 2. Cycle gates

| Gate | Passes when | Fails when |
|---|---|---|
| **V-CYCLE-01** | Play Whole Cycle reaches W4 then a named pathway | Stops at a pretty torus and calls it done |
| **V-CYCLE-02** | Scrub does not mutate protocol \(z\) | Layer slider Explore-copies or Commits |
| **V-CYCLE-03** | Ready never appears in carried-phase | Gold mark on a Ready-only seat |
| **V-CYCLE-04** | New draft at a lower world has empty Yes | Maya Yes because Self was kept |
| **V-CYCLE-05** | Withdrawal pauses upward and downward carry | Withdrawn Yes still dominates a fiber |
| **V-CYCLE-06** | Clusterfuck has no fiber to ride | Dispersed stack assigned P0 |
| **V-CYCLE-07** | Holonomy after a full fiber-cycle ≠ identity | Next fall indistinguishable from the first |
| **V-CYCLE-08** | Public route loads with no account | Any auth wall, cookie gate, or “connect wallet” |
| **V-CYCLE-09** | 2D fallback paints the same protocol facts | 2D is a poster with no version ids |
| **V-CYCLE-10** | Both endings replay from the same session log | Replay re-applies RETURN or mints new Yes |

---

## 3. Workshop invariants to re-test (already true; must stay true)

Cite hopf-workshop `docs/DISCIPLINE.md` and `VERIFICATION.md`.

- Geometry is not permission
- Suggestion is not a grant
- Confidence is not a grant
- Display \(z\) is not protocol \(z\)
- Return is not a reset
- History append-only; withdrawal pauses
- Objection is not consent=false
- Correction is not authorship of another line
- Pairwise linking \(N(N-1)/2\) — eight dimensions → 28
- Hourglass is not the bundle
- `apply(explore/reframe/propose/object/correct)` leaves agreement/consents unchanged
- Teaching instrument, not production authorization

If a cycle feature breaks one of these, the cycle feature is FAIL even if the animation is beautiful.

---

## 4. Fixtures required before C08 can PASS

1. **Thin coherent** — few Yes, no contradictions → expect P0, not Clusterfuck.
2. **Self held** — E0–E7 current-version Yes, lower worlds thin → P1.
3. **Tribe held** — four-seat agreement kept → P2.
4. **World rained** — valid Act on current World agreement → P3.
5. **Earth held** — W4 weather/love/nature facts settled → P4.
6. **Dispersed** — mixed Ready, missing reviews, one withdrawn dimension, broken links → Clusterfuck.
7. **v1/v2 coexist** — W1 v1 kept, W1 v2 draft open → v2 has no Yes; carry uses v1 only while v1 remains current-active per kernel.

Each fixture: frozen JSON or workshop snapshot hash, expected pathway or Clusterfuck, screenshot or 2D dump.

---

## 5. Evidence shape

For each PASS:

- candidate hash
- verifier id
- steps
- expected
- observed
- screenshot or 2D dump paths
- which forbidden effect was attempted and did not happen

Builder narrative is not evidence.

---

## 6. Current classification

`planning_only`

Live Decision Wells classification remains `implemented_with_limitations` and is not upgraded by this zip.
