# Open questions

Paul still picks these. Do not fill them in code to look finished.

---

1. **Forest / Core dress**
   - A. Relabel in place (Garden=W1, Desert=W2, Core=W3; Forest stays passage; W4 later).
   - B. Four-for-four (Garden=Self, Forest=Tribe, Desert=World, Core=Earth).
   - C. Fold Forest.
   Default in the plan: B as *name* lock, A as *shipped coordinates* until a dress pass.

2. **Eight-entrance lattice**
   Cube vertices of the Impossible Cube, stella octangula overlay, or both (entrances on star-tetra, shrink gate remains the gold ring)?

3. **“Keep aligned over time”**
   Session-only (DEC-SAVE-01) or SAVE_VERSION 2?
   Session means holonomy inside one sitting. Saved versions means a ledger that survives reload. Do not fake the second with `localStorage` accounts.

4. **Unfinished clause**
   “Cloud six is like…” was not finished. Self is locked as belief-alignment around the eight. Cloud Six stays the altitude on W2 Tribe until Paul finishes the sentence.

5. **Dominance threshold and link-weight**
   Unique max above threshold → that fiber. Else Clusterfuck. P0 only when thin-but-coherent.
   Do not invent a number that makes Cloud Nine more common. Publish whatever number is later chosen.

6. **Host for the public viewer**
   New route on hopf-workshop, standalone vendor of `hopf.js`, or later fractal-block dress?
   Live wells host may *share a ledger* with the viewer. It must not *be* the only way to see the cycle.

7. **DEC-GATE-01**
   Confirm rain, weather, shards, fractals, entrances, Play Cycle, and scrub never travel scale by themselves.

8. **South**
   Speech-to-text for Self, or a compass world?

9. **Pathway names**
   P0–P4 are a candidate lock. Paul may rename. Do not replace them with unpublished GMD chamber titles.

10. **Implementation begin**
    This zip is not begin. Begin is a later sentence.
