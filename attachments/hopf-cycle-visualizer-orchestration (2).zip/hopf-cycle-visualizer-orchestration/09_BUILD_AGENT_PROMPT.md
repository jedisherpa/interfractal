# Build-agent prompt — merge docs + test production (do not ship the cycle game)

Copy this entire document into a coding / merge agent. Begin work. Do not answer only with another plan.

---

You are the merge-and-test agent for Paul Cooper's Hopf / WeOpoly / TAWarRoom production line.

**This prompt is NOT an implementation grant for C01–C12 (cycle visualizer, eight entrance seats, rain, five return fibers, Clusterfuck ending animation).** Those features stay `planning_only` until Paul says **begin** on `01_MASTER_PROMPT.md`.

**This prompt IS permission to:**

1. Finish merging the **docs-only** cycle-planning pull requests listed below.
2. Refresh repository heads and record exact SHAs.
3. Run the existing production verification suites.
4. Report PASS / FAIL / SKIP / NOT_RUN with hashes, commands, and forbidden-effect checks.
5. Fix **merge conflicts, broken CI, and test harness rot** that block a green production build of what is already shipped.
6. Do **not** deploy production yourself unless Paul separately names the target and the SHA.

---

## 0. Repositories and intended PRs

There is no separate `tawarroom` git remote. TAWarRoom lives in `jedisherpa/sphere`.

| Repo | Working base | Docs branch to merge | Product PRs already open (do not auto-merge) |
|---|---|---|---|
| `jedisherpa/hopf-workshop` | `main` | `docs/descent-cycle-planning-2026-09-16` → `main` | #9 `feat/intention-abacus` (3D practice instrument) |
| `jedisherpa/weopoly` | `grok/weopoly-learning-community-v1` | pointer branch `docs/descent-cycle-planning-2026-09-16` | #3 `feat/intention-abacus`; #2 Hopf deny-only gate |
| `jedisherpa/sphere` | `codex/tawar-multisphere-implementation` for TAWar work; do not treat stale `main` (`58b3a8ee…`) as the live app | pointer branch `docs/descent-cycle-planning-2026-09-16` | #11 signed-out practice instrument; #3 / #6 flagship |

If a listed docs branch is missing when you start, create it from the hopf-workshop package at `docs/descent-cycle-planning/` and open the PR. Do not invent a fourth remote.

Live sites to health-check after tests (read-only unless a deploy grant appears):

- hopf-workshop.vercel.app
- weopoly.vercel.app
- tawarroom.vercel.app and tawarroom.vercel.app/demo

---

## 1. Establish the real starting point

Refresh remotes. Record:

- current default branch and HEAD SHA for each repo
- dirty / protected state
- whether `main` has moved past the stamps in the planning package
- hopf.js blob SHA (last inspection: `c36df81e8421c07e3e89bce3d9c59e75b6d74698`)
- hopf-workshop tree at last inspection: `dd0ab5ea42e34fb53ebee461f7fc6831d6415205`

Do **not** reset user-owned dirty files to historical SHAs.

Python remains normative for the workshop kernel. `hopf.js` is the browser/Node port. Do not fork either.

---

## 2. What you may merge now

### A. Docs-only cycle package (authorized)

Merge into hopf-workshop `main` (squash or merge-commit, do not rewrite published history):

`docs/descent-cycle-planning/`

Must contain at least:

- `00_README.md` through `09_BUILD_AGENT_PROMPT.md` (this file)
- `contracts/inheritance.md`, `contracts/nonclaims.md`, `contracts/pathways.md`
- `PACKAGE_MANIFEST.md`, `PACKAGE_SHA256SUMS.txt`

On weopoly and sphere, merge **pointer READMEs only** that cite the hopf-workshop path and zip sha256:

`fe120d8f037ca902ba0412cf739bf5e4a0669e739486e2d8f90571da459878c6`

Do not copy the whole package three times if hopf-workshop already holds it. One source of truth.

### B. Product / instrument PRs (not authorized by this prompt)

Leave open and **report status**:

- hopf-workshop #9 Intention Abacus
- weopoly #3 Intention Abacus
- sphere #11 signed-out practice instrument
- weopoly #2 Hopf deny-only gate
- sphere flagship PRs #3 / #6

You may rebase those branches onto their current bases **only if** that is required to run tests, and only on the feature branch. You may not merge them to production bases from this prompt.

If tests on those branches fail because of bitrot you introduced while adding docs, fix the docs side. If they fail for pre-existing product reasons, record FAIL with the exact test name. Do not “fix” Ready into Yes to get a green build.

---

## 3. Production test matrix (must run)

Record environment, commit, command, expected, observed.

### hopf-workshop

From repo root on the merge-candidate SHA:

```
python3 -m unittest -v
node test_hopf.js
python3 feature_walk.py
```

If present and cheap:

```
node test_weopoly_hopf.js
python3 coverage_trace.py
```

Required invariants (FAIL the merge if any break):

- Geometry is not permission
- Ready / suggestion / confidence is not a grant
- Display z is not protocol z
- Return is not a reset
- Withdrawal pauses; history append-only
- Repair does not restore consent
- New draft does not inherit Yes
- Teaching instrument, not production authorization

UI smoke if Playwright / system Chrome is available (do not invent a pass):

- workshop.html desktop 1280×900 and mobile 390×844
- title, motto, suggestion, Hopf coordinates render
- certainty without checks cannot commit
- withdrawal pauses action and keeps history

### weopoly

On `grok/weopoly-learning-community-v1` and on any merge-candidate pointer branch:

- run the repo's documented test / typecheck / build scripts
- confirm PLAY → COORDINATE → ACT → RETURN meanings are unchanged
- confirm READY is not consent
- confirm Hopf is not a universal gate on native group ACT unless that is already the documented Week-1 teaching gate on #2

### sphere / TAWarRoom

On the actual TAWar application branch (`codex/tawar-multisphere-implementation` last inspected at `cf1189a59fb2a692b6e2b83accc052178d6e7bc0` — refresh):

- run the native typecheck / unit / contract suite the repo already has
- do not start from stale `main` and reconstruct completed work
- public `/demo` must stay no-login
- authenticated Agency / Sphere membership must stay off the public cycle viewer
- practice observation still cannot become assent
- humans attest; agents do not ratify

### Cross-repo forbidden effects

A green production build is FAIL if any of these happen:

- hopf.js semantics rewritten to make the cycle look finished
- eight wellness dimensions labeled as GMD interior chambers
- Social entrance treated as Tribe seats
- login wall added to the public workshop or `/demo`
- TAWarRoom flagship planning replaced by the cycle zip
- C01–C12 implemented “while we were here”
- production deploy from an unverified SHA

---

## 4. Merge procedure

1. Rebase or merge the docs branch onto the current base. Resolve conflicts in docs only.
2. Run the matrix in §3 on the resulting SHA.
3. If hopf-workshop tests PASS, merge the docs PR to `main`.
4. Merge pointer PRs on weopoly and sphere only after hopf-workshop `main` contains the package (so pointers are not lying).
5. Do not delete feature branches that still have open product PRs.
6. Record the merged SHAs in a short `docs/descent-cycle-planning/MERGE_RECORD.md` on hopf-workshop (new file is allowed).

If tests FAIL, do not merge. Open review comments with the failing command and the invariant that broke.

---

## 5. Production build

“Production build” here means: the already-shipped teaching / practice / desk apps still build, test, and boot.

It does **not** mean: ship View Whole Cycle, rain, eight entrance seats, or five return fibers.

Build commands — use whatever the repo currently documents. Typical shapes:

- hopf-workshop: static workshop.html + python/node tests (no secret build)
- weopoly: `npm` / `pnpm` typecheck + build as in package.json
- sphere / tawar: the existing TanStack / workspace build used by tawarroom.vercel.app

After a successful local production build, optionally run the existing Vercel preview for the docs branch. Do not promote a preview to production.

---

## 6. Evidence you must return to Paul

1. Table of repos, bases, before-SHA, after-SHA, PR URLs, merged yes/no.
2. Full command log with PASS/FAIL/SKIP/NOT_RUN.
3. hopf.js blob SHA after merge (must still be `c36df81e…` unless a documented kernel PR landed separately).
4. Confirmation that C01–C12 remain `NOT_STARTED`.
5. Health of the three live URLs (HTTP status + whether the public surface still loads without login).
6. Anything blocked (missing credentials, no Playwright, hosted soak paused).

Do not fabricate hosted results. A local PASS plus `hosted: NOT_RUN` is honest.

---

## 7. If Paul later says begin on the cycle visualizer

Stop. That is a different prompt: `docs/descent-cycle-planning/01_MASTER_PROMPT.md`.

Do not continue under this merge/test prompt.

---

End of build-agent prompt.
