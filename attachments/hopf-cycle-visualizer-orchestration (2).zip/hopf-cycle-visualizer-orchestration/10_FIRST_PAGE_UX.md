# Addendum — Interfractal first-page UX

**Date:** 16 September 2026
**Status:** implementation documentation. **Not** a runtime grant for C01–C12 and **not** a silent begin on the cycle player.
**Host:** Interfractal teaching instrument, public, no login.
**Kernel:** view of hopf-workshop (`hopf.js` `c36df81e`). First-page animation does not become a permission engine.

This file specifies the **first page** Paul locked this turn. It sits *in front of* Cloud Nine play. It is not Play Whole Cycle. It is not a Yes.

---

## 1. What the first page is for

The visitor arrives in a binary: hole or light, white or black. That is the unearned picture — La La Land as two colors taking turns.

Pressing the dot is the refusal. Hopf fibres fill the field. The Impossible Cube holds two readings at once. Four worlds assemble from the deep end back to the start. The visitor lands at the **beginning of Cloud Nine**.

Line that must be readable without hover:

> This is a place where clarity keeps everything from being black and white.

Clarity here is the fibration and the nested worlds — not a third slogan color.

---

## 2. Beats (fixed order)

Playhead is a view index. No beat writes protocol \(z\). No beat stamps Yes.

| # | Beat | Picture | Copy | Must not |
|---|---|---|---|---|
| B0 | Hole | Full white field. One black circle, centered. | `HOLE` on or under the dot | Strobe faster than 3 Hz. Auto-advance into fibres. |
| B1 | Light | Full black field. One white circle, same size and place. | `LIGHT` on or under the dot | Different hit-target than B0. |
| B2 | Oscillate | B0 ↔ B1, looping, until press or skip | Reading: **white hole / light hole** — one figure-ground pair, not two products | Seizure-rate flash. Sound required to understand. |
| B3 | Press | Pointer / keyboard / touch on the dot | No new word required | Commit, Act, Explore-copy of protocol \(z\), login |
| B4 | Fibres | Hopf fibres appear from the dot, spin up, fill the screen | Optional whisper: `loops` | Fibres as people. Holonomy as a grant. |
| B5 | Cube | Impossible Cube takes the field | Optional: `two readings` | Cube as a fifth world. Cube as a well. |
| B6 | L4 | Level 4 world-chart featured | `L4` / Earth label if dress is picked | Calling L4 “level 1” |
| B7 | L3 | Level 3 featured | World / Cloud Three | Rain particles as a scale key |
| B8 | L2 | Level 2 featured | Tribe / Cloud Six | Social *entrance* as Tribe seats |
| B9 | L1 | Level 1 featured | Self / garden observatory | Eight statues = alignment |
| B10 | Cloud Nine start | Lands at the beginning of Cloud Nine | The clarity line above | Treating this landing as the *earned* Cloud Nine ending |

After B10 the instrument may idle on Cloud Nine start (fall/garden still available as play), or hand to the existing workshop start. That handoff is open (`07`).

---

## 3. Hole / Light contract

- Same circle geometry both frames. Only field color, dot color, and the one word change.
- The word is the *name of the figure*, not a button label for two destinations.
- Oscillation is **figure-ground**, not a coin-flip between two apps.
- Default period candidate: **1.6 s** per frame (well under 3 flashes/second). Crossfade ≥ 200 ms. Do not hard-cut at 10 Hz.
- `prefers-reduced-motion: reduce` → no oscillation. Show a static pair: black dot on white labeled HOLE, white dot on black labeled LIGHT, stacked or side-by-side, plus `Enter`.
- `prefers-reduced-motion` also skips fibre-spin interpolation and cube/level interpolation. Snap poses. Same facts.

Press targets:

- Pointer: the circle (generous hit area, at least 44×44 CSS px).
- Keyboard: focus the circle; `Enter` or `Space`.
- Touch: same circle; no drag required.
- Skip: visible text control `Skip intro` that jumps to B10. Skip is not a Yes.

Screen reader:

- On load: “Hole. Light. Press the dot to enter. Skip intro available.”
- Do not announce every oscillation tick.
- After press: “Loops filling the field.” Then level names as they appear. Then the clarity line.

---

## 4. Press is ENTER, not Yes

Pressing the dot:

- starts B4–B10
- may be logged as a session `enter` view event
- does **not** Explore, Commit, Act, object, withdraw, or repair
- does **not** copy display \(z\) onto protocol \(z\)
- does **not** create a draft or a seat

Looking at the dot is not Ready. Hover is not Ready. Ready still lives in the inspect UI after play begins.

---

## 5. Fibres

Presentation of the Hopf map already owned by hopf-workshop. Spin-up is camera / shader time, not holonomy.

- Start sparse at the dot.
- Increase count and angular speed until the field is full.
- Then yield to the Impossible Cube. Do not keep accelerating forever.
- Stereographic fibres, same convention as the workshop. Do not invent a second fibration.
- People are not fibres. Do not label fibres Maya / Finn / Bea / Sam.

Reduced motion: one static full-field fibre drawing, then cube.

---

## 6. Impossible Cube

The cube is the **two-readings** object (Necker / impossible cube). It is how the first page leaves the black/white binary without picking a third brand color.

It is **not**:

- a fifth GMD chamber
- a Decision Well
- automatic lock of cube-vs-star-tetra for the eight Self entrances (`07` still open)

Gold ring, if shown, remains a shrink *gate* later in play, not a well, and not part of this intro unless Paul adds it.

---

## 7. Level map (intro reveal)

Owner order: **4, then 3, then 2, then 1, then Cloud Nine start.**

| Intro level | World lock | Altitude / dress (until Paul picks otherwise) |
|---|---|---|
| L4 | W4 Transcendent / Earth | love, nature, family, vision, belief, weather |
| L3 | W3 World / Cloud Three | kept agreements, rain on the ground |
| L2 | W2 Tribe / Cloud Six | ideas hold shape; arrive as a Self |
| L1 | W1 Self / garden observatory | eight wellness *entrances*; still in the clouds |
| C9 | Cloud Nine start | teaching origin. Fall and earned return live here later. Not a shrink-layer. |

This reveal is **deep → start**. Play Whole Cycle is the other direction: C9 fall → W1 → W2 → W3 → W4 → fiber or Clusterfuck.

Do not number Cloud Nine as L5. Do not number Clusterfuck as a level.

Opening a level in this intro is presentation. It does not travel scale in the live wells host (DEC-GATE-01).

---

## 8. Clarity line

Exact owner sense, readable wording:

> This is a place where clarity keeps everything from being black and white.

Place: B10, Cloud Nine start. May persist as a caption under the first playable frame.

Do not replace DISCIPLINE sentences with this line. The line is teaching copy. The rules stay: Ready ≠ Yes, geometry ≠ permission, display \(z\) ≠ protocol \(z\).

---

## 9. Relationship to other surfaces

| Surface | Job |
|---|---|
| This first page | Public entrance cinematic + ENTER |
| Cloud Nine start | Playable origin after B10 |
| Play Whole Cycle (`04`) | Replay a session’s descent and return |
| Live Decision Wells host | Practice *inside* a world; do not rip it out to ship this intro |
| TAWarRoom /demo | Desk / pick-a-dot product; do not collapse into this intro |
| workshop.html `.start-intro` | Existing Hopf Workshop caption beat; reconcile later, do not delete in this addendum |

---

## 10. Implementation notes (when a later begin is granted)

Suggested feature ids (do not start them in this turn):

| Id | Feature |
|---|---|
| C13 | Hole / Light first page + oscillation + reduced-motion static pair |
| C14 | Press → fibres spin-up fill |
| C15 | Impossible Cube beat |
| C16 | L4→L3→L2→L1→C9 start reveal |
| C17 | Clarity line + Skip intro |
| C18 | Photosensitivity + keyboard + SR for first page |

Host candidates (same open pick as `07`): public route on hopf-workshop, or standalone Interfractal viewer that vendors `hopf.js`.

Do not implement against fractal-block combat. Do not require WebGL for the reduced-motion / 2D path: B0–B3 and B10 must work as DOM. Fibres/cube/levels may 2D-fallback as labeled frames.

---

## 11. Acceptance pictures (later)

- First paint is white + black dot + HOLE, no login wall.
- Oscillation period documented and < 3 flashes/s.
- Reduced-motion: no flicker, no spin, Skip still works.
- Press starts fibres; protocol \(z\) unchanged; no Yes on any seat.
- L4 appears before L3 before L2 before L1 before Cloud Nine start.
- Clarity line visible at B10.
- Skip jumps to B10 without minting enter-as-Yes.
