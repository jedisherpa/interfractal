# Intro feature ledger (first page only)

I01–I10 are the first-page instrument. They are **not** C01–C12. Shipping the pulse does not ship carry, rain, or Clusterfuck.

| Id | Feature | Result |
|---|---|---|
| I01 | Pulse A/B — white hole / light hole | NOT_STARTED |
| I02 | Press / keyboard Enter on the dot | NOT_STARTED |
| I03 | Fiber spin-up fills the screen | NOT_STARTED |
| I04 | Impossible Cube | NOT_STARTED |
| I05 | Levels 4 → 3 → 2 → 1 | NOT_STARTED |
| I06 | Cloud Nine beginning + owner line | NOT_STARTED |
| I07 | Skip intro | NOT_STARTED |
| I08 | Reduced motion / no strobe / pause on tab blur | NOT_STARTED |
| I09 | 2D fallback of the same states | NOT_STARTED |
| I10 | No-login public first page | NOT_STARTED |

## Gates

| Gate | Pass | Fail |
|---|---|---|
| V-INTRO-01 | Frame A is white + black dot + HOLE | Extra chrome or a second dot |
| V-INTRO-02 | Frame B is black + white dot + LIGHT | Word says Start/Play |
| V-INTRO-03 | Pulse ≤ 0.75 Hz default, never > 3 Hz | Strobe |
| V-INTRO-04 | Press starts fibers only | Press Yes, Commit, or Explore-copies protocol z |
| V-INTRO-05 | After fibers: cube, then L4 Earth → L3 World → L2 Tribe → L1 Self | Order 1→2→3→4 |
| V-INTRO-06 | Lands at beginning of Cloud Nine | Lands at earned ending / Core well |
| V-INTRO-07 | Owner line readable | Line missing or replaced |
| V-INTRO-08 | Reduced-motion: no pulse, no spin, Skip works | Motion-only facts |
| V-INTRO-09 | No login | Wallet / GMD / ENS wall |
| V-INTRO-10 | Hidden tab pauses the pulse | Pulse runs in background |

Press is **Enter**. It is not workshop Explore (Explore copies display z toward protocol z). The intro must not do that.
