# Package manifest

**Name:** hopf-cycle-visualizer-orchestration
**Date:** 2026-09-16
**Classification:** planning_only
**Kernel stamps (inspection, not a checkout order):**
- hopf-workshop tree `dd0ab5ea42e34fb53ebee461f7fc6831d6415205`
- hopf.js blob `c36df81e8421c07e3e89bce3d9c59e75b6d74698`

## Files

| Path | Role |
|---|---|
| 00_README.md | Entry |
| 01_MASTER_PROMPT.md | Later implementation grant shape |
| 02_COSMOLOGY_LOCK.md | Worlds, eight, endings, pathways |
| 03_MULTI_AGENT_ORCHESTRATION.md | Who may edit what |
| 04_VISUALIZER_CYCLE_SPEC.md | Play Cycle + scrub + inspect |
| 05_INHERITANCE_MATH.md | Carry up/down |
| 06_TRACKING_AND_VERIFICATION.md | Ledger + V-CYCLE gates |
| 07_OPEN_QUESTIONS.md | What Paul still picks |
| 08_HANDOFF.md | Classification |
| contracts/nonclaims.md | Fail-the-build implications |
| contracts/pathways.md | P0–P4 + Clusterfuck |
| contracts/inheritance.md | Settled / down / up / new draft |
| PACKAGE_MANIFEST.md | This file |
| PACKAGE_SHA256SUMS.txt | Hashes |

This package nests under hopf-workshop discipline. It does not replace TAWarRoom flagship planning.
