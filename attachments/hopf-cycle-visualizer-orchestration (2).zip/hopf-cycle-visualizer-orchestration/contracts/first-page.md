# First-page contract

Public Interfractal entrance. Session-only. No login.

## Binary

White field + black dot + HOLE  
Black field + white dot + LIGHT  
Same circle. Figure-ground, not two destinations.  
Period ≥ 1 s per frame. Never ≥ 3 flashes/s.  
`prefers-reduced-motion`: static pair, no oscillation.

## Press

ENTER the intro continuation.  
Not Ready. Not Yes. Not Explore. Not Commit. Not Act.

## After press

Fibres fill → Impossible Cube → L4 → L3 → L2 → L1 → Cloud Nine **start**.

L4 = W4 Earth. L3 = W3 World. L2 = W2 Tribe. L1 = W1 Self.  
Cloud Nine is not L5. Clusterfuck is not a level.

## Copy

“This is a place where clarity keeps everything from being black and white.”

## Forbidden

- Strobe that fails WCAG 2.3.1
- Press writing protocol z
- Fibres labeled as people
- Cube as a well or a fifth chamber
- Intro landing treated as the earned Cloud Nine *ending*
