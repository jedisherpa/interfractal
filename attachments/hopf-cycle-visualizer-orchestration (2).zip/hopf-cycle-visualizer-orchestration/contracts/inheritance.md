# Inheritance contract

Carry is phase and constraint. Carry is not consent.

## Settled

current-version ∧ explicit Yes-or-accepted-No ∧ reviews for this version ∧ ¬withdrawn ∧ ¬blocking-repair

Ready ∉ settled.

## Down

Settled facts at world \(n\) appear on world \(n+1\) as constraints / beads / copy. Seats at \(n+1\) remain unset until they sign.

## Up

Settled facts at world \(n+1\) write back as kept-phase or challenged-phase on worlds \(\le n\). Challenged is not a silent No. A command is still required to withdraw or re-Yes.

## New draft

\(A_n^{v+1}\) does not inherit responses or reviews from \(A_n^{v}\).

## Cycle

Restart at Cloud Nine applies the pending pathway-or-clusterfuck **once**. History remains. Next fall has holonomy ≠ identity.

## Tests that must exist before C04/C05 can PASS

See `06_TRACKING_AND_VERIFICATION.md` fixtures 1–7 and gates V-CYCLE-03, 04, 05, 07.
