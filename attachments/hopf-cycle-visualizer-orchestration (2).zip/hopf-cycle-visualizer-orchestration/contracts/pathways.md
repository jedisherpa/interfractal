# Pathway contract

Five return fibers from W4 Earth to Cloud Nine. Not worlds. Not GMD interior names.

| Id | Name | Selected when | Forbidden confusion |
|---|---|---|---|
| P0 | Vapor | Thin-but-coherent stack; unique max; little held below | Dispersed mess |
| P1 | Self | Eight dimensions held as current-version unwithdrawn Yes; lower worlds thin | Visiting eight statues |
| P2 | Tribe | Kept agreements with others dominate | Social *entrance* Yes |
| P3 | World | Rain / work-beyond-circle Act held | Occupational *entrance* Yes |
| P4 | Earth | Weather, love, nature, family, vision held | Spiritual *entrance* Yes alone |

**Clusterfuck** is the latch when no fiber can be selected:

- no unique max above threshold, or
- contradictions / broken 28-link field / withdrawn key dimension / missing reviews

Clusterfuck has **no fiber to ride**. Replay must show disperse, not a thin torus ride.

Dominance inputs: current-version, unwithdrawn, reviews-on-this-draft Yes-sets, intact incident links. Ready never enters the score.

Tie-break (candidate, must be published if used): longest held, then lowest world that still holds, then P4 > P3 > P2 > P1 > P0.

Threshold: OPEN. Do not invent a number in this package.
