# Hopf Workshop × Inner Fractal — orchestration package

**Status:** Planning / work-order package. Not an implementation grant until Paul activates `05_IMPLEMENTATION_PROMPT.md`.
**Prepared:** 2026-09-16
**Prepared for:** Paul Cooper / Jedi Sherpa
**Audience:** Grok build team (lead integrator + archaeology, geometry, implementation, adversarial review)

## What this package is

A source-grounded orchestration and implementation specification for making the existing Hopf Workshop visualizer a **3D interactive decision instrument inside Inner Fractal**, with the four Values Prism levels as nested tetrahedron vertices, and the IT³ Exact Engine video as the **look** of the instrument — not as protocol truth.

This is a work order, evidence contract, and next-developer handoff. It is not a built game, not a TAWarRoom deployment, and not permission to push, merge, or publish.

## The one-sentence outcome

A player flying Inner Fractal can walk up to a living apparatus at the center of each scale, watch ideas become spheres, watch Ready approach the torus without becoming Yes, watch four level-centers become a tetrahedron, and — after World is unlocked — see Cloud Nine complete the torus, while Hopf Workshop remains the only source of practice-agreement truth.

## Central question

> Can the existing deterministic Hopf Workshop protocol become one shared, legible, in-world 3D instrument whose physical layout is four Values Prism levels (Self / Forest / Tribe / World) that nest as tetrahedron vertices and complete as a torus, while geometry still cannot sign a name?

Do not optimize for the most cinematic cosmology video. Optimize for correct spatial relationships, immediate interaction, honest Ready≠Yes, measured performance inside the existing Babylon 8 scene, and a result people can actually play.

## How to use this package

| File | Purpose |
|---|---|
| `00_README.md` | This index |
| `01_ARCHAEOLOGY.md` | Exact repos, SHAs, branches, what exists vs what was assumed |
| `02_GEOMETRY_CONTRACT.md` | Three labeled geometry layers: exact Hopf, Fuller, IT³ aesthetic |
| `03_VALUES_PRISM_MAP.md` | Self→Forest→Tribe→World→Cloud Nine + tetrahedral nesting |
| `04_AESTHETIC_GRAMMAR.md` | Shot language of the north-star video and how it maps to interaction |
| `05_IMPLEMENTATION_PROMPT.md` | **The prompt to give Grok build.** Activate only when Paul says begin. |
| `06_ORCHESTRATION.md` | Multi-agent roles, path ownership, phase gates |
| `07_HANDOFF.md` | Smallest next human decision, rollback, residual risks |
| `contracts/presentation-frame.md` | Typed view-model the 3D renderer may consume |
| `contracts/nonclaims.md` | Hard nonclaims that survive the build |
| `contracts/well-positions.md` | Existing gates vs offset Decision Wells |

Give the implementation team the **entire package**. The prompt is not a substitute for the contracts.

## What was inspected

- `jedisherpa/hopf-workshop` main `dd0ab5ea42e34fb53ebee461f7fc6831d6415205` — live https://hopf-workshop.vercel.app
- `jedisherpa/fractal-block` (product name **Inner Fractal**) main `043e614959f916fe7273e66ba1b3fa7011b8de57` — live https://fractal-block.vercel.app
- Live Hopf Workshop teaching model v0.2
- Attached Babylon 3D SYNC/FALL prompt (donor patterns only)
- Attached “How to write a prompt Paul will approve”
- Attached Values Prism short form (Paul spoken)
- North-star video: IT³ Exact Engine v10.0 morph (disc → torus → Perez hourglass → cuboctahedral lattice)

## What this package does not do

- Does not edit any repository.
- Does not authorize TAWarRoom, WeOpoly production, or SYNC/FALL changes.
- Does not claim the IT³ / Logvinovich / Perez numbers prove cosmology.
- Does not treat hashes, fibers, linking, or holonomy as consent.
- Does not collapse Hopf Workshop, Inner Fractal, SYNC/FALL, and TAWar into one product.

## Activation

`05_IMPLEMENTATION_PROMPT.md` becomes an implementation grant only when Paul submits it to an agent and explicitly says to begin. It expires when the final handoff is delivered or Paul revokes it.
