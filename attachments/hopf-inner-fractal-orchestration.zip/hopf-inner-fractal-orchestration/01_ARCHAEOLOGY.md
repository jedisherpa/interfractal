# Repository archaeology

**Inspected:** 2026-09-16
**Method:** GitHub connected tools + live sites + attached work orders
**Classification key:** OBSERVED SOURCE · REPOSITORY-REPORTED · INFERRED · NOT_TESTED

## 1. Naming corrections

| User said | What actually exists | Classification |
|---|---|---|
| `jedisherpa/hopf-workshop` | Private repo, JS + Python teaching model, homepage https://hopf-workshop.vercel.app | OBSERVED |
| `jedisherpa/fractal-block world inner-fractal branch` | There is **no** repo named `fractal-block-world` and **no** branch named `inner-fractal`. The game is `jedisherpa/fractal-block`, package name `inner-fractal`, title **Inner Fractal — A Journey Through the Impossible Cube**. | OBSERVED |
| Babylon 3D implementation | Attached prompt targets `jedisherpa/multiplayer-falling-block-game` (SYNC/FALL / boulderjoe.com), Babylon **9.25.0**. Inner Fractal already runs Babylon **^8.0.0**. | OBSERVED |

Do not silently reset either repo to a historical SHA. Confirm whether `main` has moved before implementing.

## 2. Hopf Workshop

- Owner: `jedisherpa/hopf-workshop`
- Visibility: private
- Default branch: `main`
- Recorded HEAD at inspection: `dd0ab5ea42e34fb53ebee461f7fc6831d6415205`
- Created: 2026-09-14 · Pushed: 2026-09-16
- Language: JavaScript view + Python normative model
- Live: https://hopf-workshop.vercel.app
- Teaching model: **v0.2**
- Discipline: “Python is normative. HTML is a view. Topology does not authorize.”

### Executable core

| Path | Role |
|---|---|
| `hopf_model.py` | Normative geometry + Workshop protocol |
| `hopf.js` | JS port of the model |
| `visualizer.js` | Pure view-model. Commands stay outside this file. |
| `weopoly_hopf.py` / `weopoly_hopf.js` | Four-seat PLAY/COORDINATE/ACT/RETURN rehearsal over Workshop |
| `shapes_picker.js` | Geometry-first product default |
| `workshop.html` | Live workshop + geometry lab |
| `test_model.py`, `test_hopf.js`, `test_visualizer.js`, `test_weopoly_hopf.*`, `test_parity.*` | Existing gates |

### Geometry that is actually implemented

- Unit `z = (z1, z2) ∈ S³ ⊂ ℂ²`
- Hopf map `π(z) = (2 Re(z1 conj(z2)), 2 Im(z1 conj(z2)), |z1|² − |z2|²)`
- Gauge / common-phase invariance
- North/south sections, transition `sS = e^{iφ} sN`
- Horizontal latitude lift, holonomy `Δγ = π(1 − cos θ)` (90° at θ = 60°)
- Numerical Chern check ≈ −1 (check, not proof)
- Pairwise linking of sampled fibres
- Toy suggestion selector from `π(z)` — suggestion ≠ grant

### Protocol that is actually implemented

State is **not** S³. Workshop state is the augmented tuple described in the README: geometry `z` plus proposal, confidence, consents, review stamps, agreement, repair, history.

Modes:

- Upper cone: generate / explore / propose
- Torus table: keep a promise / commit / act
- Lower cone: withdraw / repair / release

Invariants already tested (see `docs/DISCIPLINE.md`):

- Geometry is not permission
- Suggestion is not a grant
- Confidence is not a grant
- Display `z` is not protocol `z` until Explore copies it
- Return is not a reset
- History is append-only
- Hourglass is not the bundle
- `apply(state, event)` leaves agreement and consents unchanged for explore/reframe/propose/object/correct

### Visualizer that is actually implemented

`visualizer.js` already projects a typed view:

- proposal vs applicable agreement
- per-person response: unset / yes / no / withdrawn
- rehearsal `ready` as a **separate** field from consent
- reviews (evidence / authority / safety) version-scoped
- action availability (commit / act / repair / release) with reasons
- next-step copy
- history vs current time-context
- `sameFacts()` for idempotent UI

The live geometry lab is a 2D canvas drawing of two circle families on a torus, plus a labeled hourglass process metaphor. Sliders move display only.

### Adjacent planning already in-tree (do not duplicate as if new)

`docs/tawarroom-flagship-planning/` is a 15 Sep 2026 package for bringing Hopf + WeOpoly into TAWarRoom. That work is **separately authorized**. This Inner Fractal instrument must not pretend to be that integration.

UX decision already locked (`docs/ux-review/decisions.md`):

1. Bundle is the geometry-lab default. Hourglass remains a labeled process metaphor.
2. Guided / free / rehearsal / lab are views of one session.
3. No production deploy from an implementation prompt.
4. Four-loop independent verification per feature.

## 3. Inner Fractal (`jedisherpa/fractal-block`)

- Package name: `inner-fractal`
- Title: Inner Fractal — A Journey Through the Impossible Cube
- Recorded HEAD at inspection: `043e614959f916fe7273e66ba1b3fa7011b8de57`
- Live: https://fractal-block.vercel.app
- Stack: React 19 + Vite 8 + Babylon.js **^8.0.0** (`@babylonjs/core`, `gui`, `loaders`, `materials`)
- No backend, accounts, or network services at runtime
- `App.tsx` dynamically imports `GameEngine` so Babylon stays out of the title boot path

### Scale worlds that already exist

| Scale | Layer file | World | Game job |
|---|---|---|---|
| 0 | `src/world/layers/ObservatoryGarden.ts` | Observatory Garden | Flight tutorial, pulse weapon, first Iris signal, shrink into cube |
| 1 | `src/world/layers/CircuitForest.ts` | Circuit Forest | Three pylons, Arc Caster, hostiles |
| 2 | `src/world/layers/MonumentDesert.ts` | Monument Desert | Glyph puzzle △ ○ □ ◇, ziggurat, Singularity Mine |
| 3 | `src/world/layers/InnerCore.ts` | Inner Core | Warden waves, Iris core, victory |

World contract: `src/world/types.ts` `LayerContent` — root TransformNode, colliders, enemies, pickups, landmarks, interactables, checkpoint, `presentationMarks`, visuals.

Scale transitions: `src/scale/ScaleSystem.ts` plus presentation in `GameEngine`. Layer roots are separate scene graphs. Continuity is sold by transition FX, not one infinite mesh.

### Level branches (not `inner-fractal`)

| Branch | SHA at inspection |
|---|---|
| `main` | `043e614959f916fe7273e66ba1b3fa7011b8de57` |
| `feat/level-one-observatory-overhaul` | `ee711197a208d9fd88d0a00fc59c218f8be2e9ed` |
| `feat/level-one-gemcut` | `0cb8aa6cff69f1f62afe7ca6e51456ecd683ae7e` |
| `feat/level-two-circuit-forest-overhaul` | `ce9586d981dfbbf8933d3a877278c1795b0ded8d` |
| `feat/level-two-gemcut` | `4934185c1f3bf9b9f4d66202a38403ac0d41521f` |
| `feat/level-three-monument-desert-overhaul` | `75045fe7aba97ee76313c8f02b8ac6f0ad311e79` |
| `feat/level-four-inner-core-overhaul` | `53e0482179365ad26d4cb534c9e4ac15823bba3a` |
| `integration/all-levels` | `c1a1695fff372a381621ed64d481ca9eeb33554a` |
| `codex/asset-first-visual-overhaul` | `d44b2a2645da4f83208697625090b244d829437b` |

Code search for `hopf OR torus OR tetrahedron OR workshop` inside `fractal-block` returned **zero hits**. There is currently no Hopf instrument in the game. Classify as OBSERVED ABSENCE on default branch.

### Engine seams the new instrument must use

- `src/engine/GameEngine.ts` — one scene, one render loop
- `src/world/WorldBuilder.ts` — layer registry/lifecycle
- `src/world/StaticGeometryBatcher.ts` — already exists; reuse for static apparatus shells
- `src/player/FlightController.ts` — do not bind camera-orbit to gameplay keys
- `src/objectives/` — interactables already exist (`F` to interact)
- `src/save/SaveSystem.ts` — versioned localStorage; new workshop progress must migrate or fail closed
- Quality / reduced-motion already exist

### Scale gates versus Decision Wells

`buildScaleGates()` at SHA `043e6149`. Garden `scale_ring` sits at `(0, 6, 0)`. Authored cube visual in `ObservatoryGarden.ts` is at `(0, 11.5, 0)`. A well at the origin collides with the travel gate.

| id | dir | from→to | position | radius |
|---|---|---|---|---|
| garden_to_forest | shrink | 0→1 | (0, 6, 0) | 5 |
| forest_to_garden | grow | 1→0 | (0, 14, 58) | 4 |
| forest_to_desert | shrink | 1→2 | (0, 6, −20) | 4.5 |
| desert_to_forest | grow | 2→1 | (0, 12, 72) | 4 |
| desert_to_core | shrink | 2→3 | (0, 18, 0) | 4 |
| core_to_desert | grow | 3→2 | (0, 10, 42) | 4 |

`ScaleSystem.canUseGate` currently allows any shrink from the current layer; grow requires destination already in `unlocked[]`. DEC-GATE-01 preserves this. Defaults for offset wells: `contracts/well-positions.md`. Garden recommendation: `(16, 3.2, 8)` radius 3.5.

Add `kind: 'decision_well'` to existing `WorldInteractable`. Put `well_*` keys on `presentationMarks`.

`SAVE_VERSION = 1`. `migrateSave` fails closed on future versions. `CheckpointData.puzzle` already owns `gardenTargets`, `forestPylons`, `desertSequence`, `desertSolved`, `coreReleased`. Do not reuse those flags. Default: session-only Workshop state (DEC-SAVE-01).

`hopf.js` SHA `c36df81e8421c07e3e89bce3d9c59e75b6d74698`. Public API: `state`, `hopf`, `gauge`, `stereographic`, `northSection`, `southSection`, `horizontalLatitude`, `holonomyAngle`, `suggestion`, `curvatureNumber`, `fibre`, `linkingNumber`, `Workshop`, `apply`. `apply()` leaves agreement + consents unchanged. Vendor into `src/workshop/` with provenance. Do not reimplement.

SHA refresh 2026-09-16 23:12 UTC: hopf-workshop `main` still `dd0ab5ea`; fractal-block `main` still `043e6149`.

## 4. Donor, not host: SYNC/FALL Babylon prompt

The attached `BABYLON_3D_IMPLEMENTATION_PROMPT.md` is a high-quality work order for turning a 2D falling-block arena into a 3D room. Steal from it:

- Presentation-frame contract
- Renderer is not game authority
- Thin instances / no per-cell React
- Event idempotency across reconnect/rematch
- WebGPU → WebGL → Canvas fallback
- Quality governor order
- Independent verifier cannot be the implementer
- Claim discipline: SUPPORTED / CONTRADICTED / UNKNOWN / NOT_TESTED

Do **not** steal from it:

- Babylon 9.25.0 pin (Inner Fractal is on 8.x)
- 1P/2P/3P/4P seat station geometry for a competitive grid
- Server/protocol/persistence changes
- Production URLs `boulderjoe.com`

## 5. Negative findings

1. The north-star video vocabulary (Logvinovich field, Perez hourglass as vacuum, Cartan torsion 0.06835, ΔK = 3,317,760,000, covolume 57,600, 16-bit CMB mask, Yang-Mills mass gap, “God geometrizes”) is **not** in hopf-workshop source. It is an aesthetic north star from an external IT³ Exact Engine clip.
2. Hopf Workshop visualizer is a view-model + 2D canvas, not a Babylon world.
3. Inner Fractal has four nested worlds and no decision apparatus.
4. Existing TAWarRoom flagship plan already claims the visualizer centerpiece for a different product. This package must name that conflict and stay in Inner Fractal + Hopf practice scope.
5. Human playtest of WeOpoly is recorded `NOT_RUN` in Hopf INTEGRATION.md. Automated seats are not four humans.
6. Live fractal-block.vercel.app page text was not extractable at inspection time (JS app). Layer names above come from source, not the rendered title screen.

## 6. Source-of-truth order for the build

1. Paul’s current direct decisions and this package’s activation
2. hopf-workshop `docs/DISCIPLINE.md`, README corrections, `visualizer.js`
3. fractal-block `ARCHITECTURE.md`, `GAME_DESIGN.md`, `LayerContent` contract, current Babylon 8 scene
4. Exact source and tests at the recorded SHAs (refresh first)
5. Reproduced tests and observed runtime
6. Attached SYNC/FALL prompt as engineering donor
7. IT³ video as look reference
8. Memory and inference last
