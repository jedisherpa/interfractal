# Geometry contract

Three layers. Keep the labels. Do not collapse them.

## Layer A — Exact Hopf (must implement, must test)

Source of truth: `jedisherpa/hopf-workshop` `hopf_model.py` / `hopf.js`.

Unit state:

\[
z=(z_1,z_2)\in S^3\subset\mathbb C^2,\qquad |z_1|^2+|z_2|^2=1
\]

Hopf map:

\[
\pi(z)=\bigl(2\operatorname{Re}(z_1\overline{z_2}),\;
2\operatorname{Im}(z_1\overline{z_2}),\;
|z_1|^2-|z_2|^2\bigr)
\]

Gauge invariance: \(\pi(e^{i\gamma}z)=\pi(z)\). Common-phase changes do not create permission.

Clifford torus: \(|z_1|=|z_2|=1/\sqrt{2}\) is the preimage of the equator.

Solid tori: \(V_N=\{|z_1|\ge|z_2|\}\cong D^2\times S^1\), \(V_S=\{|z_2|\ge|z_1|\}\cong D^2\times S^1\), intersection \(T^2\).

Transition on the overlap: \(s_S=e^{i\phi}s_N\) (winding 1).

Holonomy of the specified connection:

\[
\Delta\gamma=\pi(1-\cos\theta)
\]

At \(\theta=60^\circ\), \(\Delta\gamma=90^\circ\). The base returns; the lift has changed. This is “return is not a reset.”

Chern numerical check ≈ −1 with the repository convention. It is a check, not a proof, not a moral sign.

Fibres: `fibre(theta, phi)` then `stereographic`. The projection pole is excluded; do not draw numerical infinity as a broken curve.

Protocol state remains \(X=(z,P,B,C,A,E,K,M)\). The game may drive Workshop commands. The game may not invent a second permission kernel.

## Layer B — Fuller / synergetics (implement, labeled Fuller)

Why four levels: the tetrahedron is Fuller’s minimum system (4 vertices, 6 edges, 4 faces). That is a design reason, not a theorem that consciousness is a tetrahedron.

Regular tetrahedron on the unit circumsphere — implement exactly:

\[
\begin{aligned}
V_0 &= (1,\;1,\;1)/\sqrt{3} \\
V_1 &= (1,\;-1,\;-1)/\sqrt{3} \\
V_2 &= (-1,\;1,\;-1)/\sqrt{3} \\
V_3 &= (-1,\;-1,\;1)/\sqrt{3}
\end{aligned}
\]

Child tetrahedron at vertex \(V_i\): center \(V_i\), scale \(1/\varphi\), orientation same or dual (stella octangula). \(\varphi=(1+\sqrt{5})/2\in\mathbb Q(\sqrt{5})\subset K\).

Vector Equilibrium = cuboctahedron: 12 vertices, center-to-vertex = edge, 12-around-1 closest packing. This is the honest geometric name for the video’s “0_h cuboctahedral lattice.”

Jitterbug: VE → icosa → octa → tetra. Optional “cross-level alignment” morph **after** all four stations exist. Do not run during ordinary flight.

Octet truss / isotropic vector matrix: tetra + octa fill space. Optional low-weight environment lattice in Core / Cloud Nine.

Fuller’s “4 × 3 = 12 degrees of freedom” is a mnemonic, not a physics derivation.

## Layer C — IT³ Exact Engine look (presentation only)

\(K=\mathbb Q(\sqrt{2},\sqrt{3},\sqrt{5})\) is a real degree-8 field. It contains the three radicals that generate tetra/cube (\(\sqrt{2}\)), triangular/hex (\(\sqrt{3}\)), and icosa/dodeca/φ (\(\sqrt{5}\)). That is enough to justify using \(K\) as a **shared constant field for procedural lengths**.

Integer identity that may be displayed as a labeled numerical check:

\[
3{,}317{,}760{,}000 = 2^{16}\cdot 3^4\cdot 5^4,\qquad
\sqrt{3{,}317{,}760{,}000}=57{,}600=2^8\cdot 3^2\cdot 5^2
\]

Whether this integer is the field discriminant of \(K\) is **UNKNOWN** until an independent number-theory check is recorded. Displaying the identity is allowed. Claiming “this is the CMB hardware frequency” is not.

Allowed as look:

- Black void, teal phosphor terminal, red → cyan wireframe
- Concentric disc → torus → Perez hourglass (one-sheet hyperboloid / two bowls + neck)
- Counter-rotation lock at the neck
- Cuboctahedral lattice overlay after lock
- Boot-log typography as inspect overlay

Forbidden as physics / protocol truth:

- No Big Bang because CMB is uniform
- 16-bit processor hum as cosmology
- \(\tau_{vac}=0.06835\) as vacuum Cartan torsion
- “Yang-Mills mass gap verified”
- “God geometrizes” as a system proof (title card only)
- 36 nodes as a physical count (VE 12-around-1 may be doubled for display)

Cheeger’s inequality \(\lambda_1\ge h^2/4\) is a real theorem. Showing the inequality is fine. Calling it a solved Yang-Mills gap is not.

## What “spheres coming together” means

At a station the player sees:

1. Live fibres over the current base point (suggestion, not grant).
2. Named seats as dots on the public face. Yes / No / unset / withdrawn / ready are **distinct shapes**, not only colors.
3. A versioned consent flip brightens or dims the matching fibre on the next frame. No camera tween.
4. `commit() === true` locks the local sphere to the torus table.
5. Four local locks draw the large tetrahedron edges and a Clifford torus around the common center — Cloud Nine presentation.
6. Withdrawal unhooks that seat’s fibre immediately, pauses the local agreement, leaves the person-dot present, dashes the tetrahedron edge.
7. Grow/shrink through existing `ScaleSystem` is travel between vertices. The station is not a cutscene.

## Non-isomorphisms (from hopf-workshop README — preserve)

- Hashes are not the Hopf projection.
- Twelve lenses do not fill \(S^3\).
- Linking does not guarantee sovereignty, safety, or liveness.
- Pairwise linking of \(N\) fibres sums to \(N(N-1)/2\), not 1.
- Phase is not memory.
- A person is not a fibre.
- The hourglass process drawing is not the bundle.
- The torus is not all of \(S^3\).
