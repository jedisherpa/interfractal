# 03 Values Prism map

**Status:** Recommended mapping for this work order. Not a proof that the Values Prism is a tetrahedron.
**Sources:** Paul's spoken Values Prism (2026-09-16) + short-form transcript `7. Values Prism - Explained by Paul` + Inner Fractal `GAME_DESIGN.md` layers 0–3 + hopf-workshop `docs/DISCIPLINE.md`.

This file is the product mapping. Geometry coordinates live in `02_GEOMETRY_CONTRACT.md`. Do not collapse the two.

## What the Prism actually says

Love enters the self only if the self is transparent. Transparency teaches vulnerability and clarity. Clarity leads toward tribe.

Love enters the tribe only through participation: show up, help, let yourself be helped. Participation teaches presence and connection. That is how a person starts to feel whole.

Love enters the world only through meritocracy. The world is not that forgiving. Energy has to be ordered enough to compete. Freedom is not the absence of constraint. Freedom is the ability to express inside constraints, and sometimes to change them.

When energy can move through self, tribe, and world without getting stuck, the person feels free. Completing that circuit is Cloud Nine: the torus that can hold a promise across all four spheres.

Creativity is not an obscure impulse that has to be cultivated in isolation. It is the wholesome expression that appears when the four spheres can pass energy without blockage.

## Four vertices, not three acts plus a cutscene

Paul named four playable levels and then a completion:

| Vertex | Prism name | Inner Fractal layer | Hopf mode at the station | Condition of flow | Failure mode the player should be able to see |
|---|---|---|---|---|---|
| V0 | Self / Cloud Six | 0 Observatory Garden | Upper cone GENERATE | transparency | a beautiful idea with no one named |
| V1 | Forest | 1 Circuit Forest | explore / presence | showing up in a world that is not only you | a signal that does not yet bind anyone |
| V2 | Tribe | 2 Monument Desert | Torus KEEP PROMISE | participation | READY mistaken for Yes; one seat withdrawn |
| V3 | World | 3 Inner Core | Lower cone RELEASE / ACT | merit, form that can compete | acting on a draft, or erasing history to look finished |
| Cloud Nine | completed torus | Garden after V3 unlocked | holonomy that is not a reset | flow across all four | a locked local vertex whose edge to another vertex is dashed |

Cloud Nine is **not** `ScaleLayerId 4`. It is the completion state of tetrahedron T0, presented as a transformed Garden (circumsphere + Clifford torus + holonomy caption). Inner Fractal still has exactly four scale layers.

Paul's spoken “south” is a speech fragment, not a compass contract. Do not rotate the whole arena so V1 is geographic south unless a later measurement requires it. The coordinate identity is `(1, −1, −1)/√3`. Local camera may orbit so the current layer's well sits in the foreground without mutating vertex identity.

## DEC-VP-01 default vertex assignment

Regular tetrahedron on the unit circumsphere. Implement exactly:

\[
\begin{aligned}
V_0 &= (1,\;1,\;1)/\sqrt{3} && \text{Self / Observatory Garden / Cloud-entry} \\
V_1 &= (1,\;-1,\;-1)/\sqrt{3} && \text{Forest / Circuit Forest} \\
V_2 &= (-1,\;1,\;-1)/\sqrt{3} && \text{Tribe / Monument Desert} \\
V_3 &= (-1,\;-1,\;1)/\sqrt{3} && \text{World / Inner Core}
\end{aligned}
\]

T0 center is the origin. Child tetrahedron at vertex \(V_i\): center \(V_i\), scale \(1/\varphi\), \(\varphi=(1+\sqrt{5})/2\in\mathbb Q(\sqrt{5})\subset K\). Orientation same as parent or dual (stella octangula). Four seats around a local table are the child tetrahedron. They are practice characters, not the four worlds.

## Tetrahedron semantics

- **Vertex** = one Workshop instance plus one Decision Well interactable.
- **Edge** = visual translation of a *copy preview* of a versioned proposal from \(V_i\) to \(V_j\). Copying is Explore / propose at the destination, not inheritance of Yes.
- **Face** = any three locked vertices. A face can look “stable” while the fourth vertex is withdrawn. That is the pedagogical point: alignment at one level may fail at another.
- **Circumsphere / Clifford torus around T0** = Cloud Nine completion predicate:
  - all four vertices have an applicable (not merely draft) agreement, AND
  - no open withdrawal on those applicable versions.
  - Geometry of the torus is the Hopf equatorial \(T^2\), not a new surface.

Alignment is two predicates, never one score:

- `localAlignment(Vi)`: Workshop at \(V_i\) has status `active` for an exact version.
- `tetraAlignment(T0)`: Cloud Nine predicate.

Do not display “82% aligned.” Do not display a combined Self/Tribe/World percentage.

## How love-flow becomes visible without becoming permission

1. **Self / Garden.** Fibres appear when the player explores. Explore copies display \(z\) into protocol \(z\). It still writes no consent. Transparency is the condition: the apparatus shows the idea before anyone is named.
2. **Forest.** A second station. A suggestion can travel as a copy-preview from V0. The Forest station starts unset. Presence is showing up in a world that is not only you.
3. **Tribe.** Named seats must separately Ready and separately Yes. The torus table is the only place a promise can sit. Participation is the condition.
4. **World.** An applicable agreement can be acted. Withdrawal pauses. Repair records consequences. Release retires the form without erasing people. Merit is the condition: the form has to be ordered enough to compete.
5. **Cloud Nine.** Four locked vertices draw the six edges. The Clifford torus completes. Holonomy caption reads: “you can return without pretending the journey never happened.”

Wizard Joe may narrate the Prism in plain words. He may not supply a seat's consent.

## Binding nonclaims

- Transparency, participation, and merit are design intentions, not physics.
- Completing combat in Inner Core is not World-consent.
- Completing three pylons is not Forest-consent.
- Solving glyphs is not Tribe-consent.
- Geometry can show that a Yes at Tribe does not yet exist at World. It cannot sign the missing Yes.
- Freedom / Creativity is the completed circuit, not a fifth vertex and not a fifth scale layer.
- A person is not a fibre. A world is not a fibre. A level-complete flag is not a Yes.

## Default if Paul does not answer mid-run

Use DEC-VP-01, DEC-GATE-01, offset wells, Maya / Finn / Bea as labeled fictional practice seats, Iris as world narrative only, Cloud Nine as transformed Garden.
