# 04 Aesthetic grammar

**Status:** Presentation contract. Layer C of `02_GEOMETRY_CONTRACT.md`.
**North star:** attached 30-second IT³ Exact Engine v10.0 clip (`IMNr4PdqSzwR3351.mp4`).
**Classification:** LOOK REFERENCE. Not protocol truth. Not cosmology.

The clip is the *look* of the Decision Well when the player inspects it. Hopf Workshop remains the *meaning*. If the two disagree, Hopf wins.

## What the clip actually does (timed)

Read from extracted frames, not from memory of similar videos.

| t (s) | Picture | Terminal copy (verbatim look, not protocol) |
|---|---|---|
| 0–1 | Red concentric disc, teal particle field, black void | `[SYSTEM BOOT] IT3 EXACT ENGINE v10.0` |
| 2–5 | Same disc; particles drift | CMB scan → “NO 'BIG BANG' EXPANSION DETECTED” → “BACKGROUND NOISE IS CONSTANT AND UNIFORM” → “INSTRUMENTS ARE MEASURING 16-BIT PROCESSOR HUM!” |
| 6–8 | Disc dissolves; particles remain | “ANALYZING CONTINUOUS SPACE (R^4)...” → “INFINITE SINGULARITIES DETECTED.” |
| 8–11 | Cyan wireframe torus | “R^4 IS A MATHEMATICAL ILLUSION. INITIATING COLLAPSE...” → `K = Q(√2, √3, √5)` → Logvinovich field line |
| 11–14 | Torus pinches into Perez hourglass (one-sheet hyperboloid / two bowls + neck) | Cartan torsion line → “MORPHING TORUS INTO PEREZ HOURGLASS...” → “TOPOLOGICAL NECK FORMED. COUNTER-ROTATION LOCKED.” |
| 15–20 | Hourglass holds; numbers appear | ΔK = 3,317,760,000 → covolume √ΔK = 57,600 → 16-bit mask `1110 0001 0000 0000` |
| 21–24 | Yellow ring + magenta axis at the neck | “CALCULATING YANG-MILLS MASS GAP...” → `MASS GAP: λ₁ ≥ h²/4 > 0` |
| 25–29 | Cuboctahedral lattice with yellow nodes superimposed | “SUPERIMPOSING 0_h CUBOCTAHEDRAL LATTICE...” → “36 TOPOLOGICAL NODES LOCKED.” → “REALITY RENDERING COMPLETE. GOD GEOMETRIZES.” |

Color sequence: black void → red wireframe disc → cyan/teal torus → cyan hourglass → yellow lock ring + magenta axis → yellow VE nodes + green lattice edges.

Typography: monospaced teal phosphor terminal, right-aligned, accumulating log. Left side is the instrument. Never put the log over the instrument.

## What the clip is allowed to become in-game

The Decision Well plays this morph as a *state machine driven by Workshop facts*, not as a 30-second cutscene that hijacks the camera.

| Clip beat | In-game trigger (Workshop fact) | What the player sees |
|---|---|---|
| Red disc + CMB scan | Station idle / no proposal | Concentric disc at the well. Particles exist. No permission language. |
| Collapse of R^4 / torus appears | Player enters the well (F) and Explore is live | Disc lifts into a Clifford torus. Display \(z\) sliders / look-orbit move the base point. |
| `K = Q(√2, √3, √5)` caption | Inspect overlay open | Caption only. Shared constant field for procedural lengths. Not a cosmology claim. |
| Perez hourglass + neck lock | Proposal exists; torus table is the current mode | Hourglass is the **labeled process metaphor**. Bundle remains available as the Math lens. |
| Counter-rotation lock | All required reviews recorded for this version, still no commit | Neck locks. Caption: “reviews recorded — Ready is not Yes.” |
| ΔK / covolume / 16-bit mask | Inspect / Math lens | Integer identity display. See Layer C nonclaims. |
| Mass-gap overlay | Cloud Nine inspect only | Caption **must** say “Cheeger's inequality (spectral geometry check)”. Never “Yang-Mills solved.” |
| Cuboctahedral lattice | `localAlignment(Vi)` true, or Cloud Nine predicate approaching | VE / 12-around-1 overlay. Honest name is Vector Equilibrium, not “0_h lattice as vacuum.” |
| “GOD GEOMETRIZES.” | Title card / reduced-motion still only | Never a system proof. Never a commit receipt. |

The player must be able to walk away from the well at every beat. Morph progress is a view of Workshop state. It is not a timer that grants anything.

## Palette (exact enough to implement)

Use these as starting tokens. Adapt to each layer's existing `LAYER_PALETTES` so the well belongs to its world instead of punching a black hole in Garden daylight.

| Token | Hex | Use |
|---|---|---|
| `void` | `#000000` | Inspect overlay background only. Not the Garden sky. |
| `phosphor` | `#3CFF9A` | Terminal log, inspect body, fibre suggestion |
| `disc-red` | `#FF2A2A` | Idle disc wireframe |
| `torus-cyan` | `#2EE6D6` | Bundle / Clifford torus (aligns with Pulse Projector `#2ee6d6`) |
| `hourglass` | `#20E0C8` | Process metaphor |
| `lock-yellow` | `#F5C542` | Neck lock, VE nodes |
| `axis-magenta` | `#E11D48` | Mass-gap axis, withdrawal dash |
| `seat-unset` | `#6B7280` | Person dot, no answer |
| `seat-ready` | `#A78BFA` | Ready, not Yes (distinct shape, not only color) |
| `seat-yes` | `#34D399` | Versioned Yes |
| `seat-no` | `#F97316` | Versioned No |
| `seat-withdrawn` | `#E11D48` dashed | Person remains present; relationship changes |

State always uses words **and** shape/icon differences as well as color. No color-only consent.

## Shot language

- Black void is for the inspect overlay and Cloud Nine completion beat, not for replacing layer lighting.
- The instrument sits left; the log sits right. On a narrow screen the log becomes a DOM drawer under the canvas, never a GPU-only GUI that hides the next action.
- Camera: a slight fixed angle may reveal torus depth. Do not attach Babylon camera-orbit to flight keys. Do not shake, ease, or dolly during ordinary Explore.
- Particles: teal point field around the instrument, density governed by existing quality tiers. Reduced motion: freeze the field, keep the wireframe.
- Counter-rotation at the neck is two slow opposing windings. Reduced motion: static opposing chevrons.
- Cubocta overlay is thin instances, not one mesh per node.
- “Spheres coming together” means named person-dots brighten their matching fibre on the next frame when a versioned consent flips. No camera tween. No confetti for Yes.

## Layer-local dress

The well must read as belonging to its world.

- **Garden / Self.** Pale-stone plinth, gold tick marks echoing the existing scale-ring ticks, ivory/warm ambient. The well is not the gold scale ring at `(0, 6, 0)`.
- **Forest / presence.** Magenta fog, circuit-tree vocabulary, teal emissive traces. Well sits near a pylon language, not inside the Seed Core.
- **Desert / Tribe.** Warm stepped plinth, glyph-adjacent but not the △ ○ □ ◇ socket. Torus table is the promise furniture.
- **Core / World.** Black / crimson / blue machine vocabulary. Well is not the Iris victory interactable.
- **Cloud Nine.** Garden lighting remains; a Clifford torus and six tetra edges appear around T0. The sky does not become the IT³ void unless the player opens Inspect.

## Copy discipline

Allowed on the instrument:

- Hopf next-step sentences from `visualizer.js` (`view.nextStep`).
- “Readiness is not consent.”
- “Make this agreement is still a separate command.”
- “You can return without pretending the journey never happened.”
- Integer identity `3,317,760,000 = 2^16 · 3^4 · 5^4` as a labeled numerical check.
- `K = Q(√2, √3, √5)` as the shared constant field for lengths.

Forbidden as physics / protocol truth (may appear only as quoted north-star flavor inside Inspect, with a “look reference” label):

- “No Big Bang because CMB is uniform”
- “16-bit processor hum” as cosmology
- `τ_vac = 0.06835` as vacuum Cartan torsion
- “Yang-Mills mass gap verified”
- “God geometrizes” as a system proof
- “36 topological nodes locked” as a physical count (VE 12-around-1 may be doubled for display)
- Any sentence that treats a morph completion as a grant

## Reduced motion

Existing Inner Fractal reduced-motion setting already shortens scale transitions and softens post-processing. The well must honor it:

- No torus spin, no particle drift, no neck counter-rotation, no camera ease.
- Morph becomes an instant pose change: disc → torus → hourglass → lattice, with a one-frame crossfade at most.
- Consent flips still update on the next frame. That is state, not decoration.
- Essential state (proposal vs agreement, Ready vs Yes, withdrawn person still present) remains fully visible.

## What not to steal from SYNC/FALL

The attached Babylon 3D arena prompt is a donor for *engineering patterns* (presentation frame, batching, fallback, claim discipline). It is not the look of this instrument. Do not build player stations around a 10×50 well. Do not pin Babylon 9.25.0. Do not put hold-queue-garbage furniture on a Decision Well.
