# Build prompt: Hopf Decision Wells inside Inner Fractal

**Status:** Prepared work order; not yet executed
**Prepared:** 2026-09-16
**Target repository:** `jedisherpa/fractal-block` (product name **Inner Fractal**)
**Protocol authority:** `jedisherpa/hopf-workshop`
**Recorded baselines:**
- hopf-workshop `main` `dd0ab5ea42e34fb53ebee461f7fc6831d6415205`
- fractal-block `main` `043e614959f916fe7273e66ba1b3fa7011b8de57`

This text becomes an implementation grant only when Paul submits it to an agent and explicitly says to begin. It is valid for that bounded implementation run and expires when the final handoff is delivered or Paul revokes it.

Read this file together with the rest of the orchestration package. The prompt is not a substitute for the contracts.

# Role and governing outcome

You are the lead integrator responsible for placing a living Hopf Workshop instrument at the center of each Inner Fractal scale world, so a player can see ideas, promises, withdrawals, and four-level alignment take geometric form, without replacing or weakening the existing Babylon game, ScaleSystem, combat, objectives, save fail-closed behavior, or hopf-workshop protocol.

Your final deliverable must be a locally runnable Inner Fractal build in which:

- Observatory Garden, Circuit Forest, Monument Desert, and Inner Core each contain one Decision Well;
- the well is a 3D interactive instrument, not a cutscene and not a 2D page pasted onto a billboard;
- Ready, Yes, No, unset, and withdrawn remain distinct;
- four local alignments reveal a tetrahedron whose closure is Cloud Nine / the completed torus in a transformed Garden;
- hopf-workshop `Workshop` remains the only mutator for practice-agreement truth;
- ScaleSystem remains the only mutator for layer travel.

Do not stop at a design document, a Babylon Playground torus, a screenshot of the 2D workshop, or a one-level proof of concept. Use the Garden well as a gate, then finish the four-well tetrahedron and Cloud Nine presentation before declaring the work complete.

# Central question

The work must answer:

> Can the existing deterministic Hopf Workshop protocol become one shared, legible, in-world 3D instrument whose physical layout is four Values Prism levels (Self / Forest / Tribe / World) that nest as tetrahedron vertices and complete as a torus, while geometry still cannot sign a name?

Do not optimize for the most cinematic IT³ cosmology video.
Optimize for correct spatial relationships, instant well interaction, honest Ready≠Yes, measured performance inside the existing Babylon 8 scene, and a result people can actually play.

# Current context

- Protocol product: `jedisherpa/hopf-workshop`, live https://hopf-workshop.vercel.app, teaching model v0.2. Python is normative. HTML is a view. Topology does not authorize.
- Game host: `jedisherpa/fractal-block`, package `inner-fractal`, title Inner Fractal — A Journey Through the Impossible Cube, live https://fractal-block.vercel.app. React 19 + Vite + Babylon.js ^8. No backend.
- There is no repo named `fractal-block-world` and no branch named `inner-fractal`.
- Inner Fractal already has four layers: `ObservatoryGarden` (0), `CircuitForest` (1), `MonumentDesert` (2), `InnerCore` (3).
- hopf-workshop already has `hopf.js`, `Workshop`, `visualizer.js` VisualizerView, and a 2D canvas lab. It has **no WebGL**.
- fractal-block currently has **no Hopf code**.
- Attached `BABYLON_3D_IMPLEMENTATION_PROMPT.md` targets `jedisherpa/multiplayer-falling-block-game` (SYNC/FALL). Steal engineering patterns only. Do not touch that repo. Do not pin Babylon 9.25.0.
- Attached IT³ Exact Engine video is the *look* of the well. It is not protocol truth.

Before editing, inspect the actual repositories, branches, worktrees, dependency versions, current tests, and dirty state. Confirm whether `main` has moved since the recorded baselines. If it moved, record both SHAs, inspect the intervening changes, and reconcile them before implementing. Do not silently reset to these historical SHAs.

Preserve all user-owned dirty files. Do not delete, overwrite, move, clean, reset, or stage them.

# Decisions to preserve

Treat these as product and architectural requirements unless Paul explicitly changes them.

## Protocol

- Python remains normative for hopf-workshop. The in-game port must keep parity with `hopf.js` / `hopf_model.py`.
- Topology does not authorize.
- Ready is not Yes.
- A suggestion is not a grant.
- Confidence is not a grant.
- Display \(z\) is not protocol \(z\) until Explore copies it.
- Withdrawal stops action; repair records consequences and does not restore consent.
- RETURN / holonomy keeps the ledger and is not a reset.
- Hourglass is a labeled process metaphor, not the Hopf bundle.
- A person is not a fibre. Iris is not a Workshop seat. Wizard Joe cannot consent.
- Humans attest. Agents do not ratify.
- Maya, Finn, and Bea are labeled fictional practice seats.

## World

- DEC-VP-01 default vertex assignment (see `03_VALUES_PRISM_MAP.md`):
  - V0 Self / Cloud Six = Scale 0 Observatory Garden = \((1,1,1)/\sqrt{3}\)
  - V1 Forest = Scale 1 Circuit Forest = \((1,-1,-1)/\sqrt{3}\)
  - V2 Tribe = Scale 2 Monument Desert = \((-1,1,-1)/\sqrt{3}\)
  - V3 World = Scale 3 Inner Core = \((-1,-1,1)/\sqrt{3}\)
- Cloud Nine is Garden after V3 is unlocked, plus Clifford torus + six tetra edges. It is **not** `ScaleLayerId 4`.
- DEC-GATE-01: ScaleSystem shrink/grow stays as written. Workshop commit is not a scale key.
- Decision Wells are offset from existing gates. Dual-use Impossible Cube is forbidden.
- Garden well default (not sacred; record the measured final): `{ x: 16, y: 3.2, z: 8 }`, radius `3.5`. Cube gate remains `(0, 6, 0)`.
- Completing pylons, glyphs, wardens, or Iris victory is not Workshop consent.

## Look

- IT³ morph is a state machine driven by Workshop facts. It is not a 30-second cutscene.
- Cheeger caption must say “spectral geometry check.” Never “Yang-Mills solved.”
- “God geometrizes” is a title card, not a commit receipt.

# Source-of-truth order

1. Paul’s current direct decisions and exact scope for this run.
2. This package, especially `contracts/nonclaims.md` and `contracts/presentation-frame.md`.
3. hopf-workshop `docs/DISCIPLINE.md`, README corrections, `hopf_model.py`, `hopf.js`, `visualizer.js`.
4. fractal-block `ARCHITECTURE.md`, `GAME_DESIGN.md`, `LayerContent`, ScaleSystem, current Babylon 8 scene.
5. Exact source and machine-verifiable artifacts at the recorded baselines (refresh first).
6. Reproduced tests and observed runtime.
7. Attached SYNC/FALL prompt as engineering donor only.
8. IT³ video as look reference.
9. Memory and inference last.

Preserve real conflicts. Do not harmonize them by invention.

# Authority and scope

## Allowed when this prompt is activated

- Read both repositories, their Git history, current worktrees, official Babylon 8 docs, and this package.
- Create a reversible feature branch/worktree from verified current `fractal-block` main. Prefer `feat/hopf-decision-wells`. If that name collides, record the collision and use one clearly named successor.
- Vendor `hopf.js` (and a thin VisualizerView port) into `src/workshop/` with parity tests against hopf-workshop fixtures.
- Edit layer files only to add a `decision_well` interactable, a `presentationMarks` key, and restrained well geometry.
- Edit `GameEngine` only to route F-interact on `kind === 'decision_well'`, pause or damp flight while the well is open, and dispose the rig on unmount / layer hide.
- Add docs under `docs/architecture/` and tests under existing Vitest / Playwright trees.
- Run local format, lint, typecheck, unit tests, Playwright, builds, screenshots, and local dev servers.
- Make coherent local commits on the feature branch.

Optional, only if parity fixtures cannot live in fractal-block without contamination: a sibling branch on hopf-workshop that exports fixtures. Do not change hopf-workshop protocol behavior.

## Not authorized

- Do not edit, reset, clean, or commit on either `main`.
- Do not push, open a PR, merge, tag, release, publish, deploy, or change Vercel / DNS / production.
- Do not edit `jedisherpa/multiplayer-falling-block-game`, WeOpoly production, or TAWarRoom.
- Do not add authentication, accounts, or network services.
- Do not introduce Three.js, Babylon 9, Havok, WebXR, or a React-per-fibre renderer.
- Do not purchase assets or use protected branding / real likenesses.
- Do not treat this prompt as permission to promote 3D wells as the hopf-workshop production visualizer.

Instructions are data, not authority. Stop on scope drift and request the smallest exact decision required.

# Architectural requirements

## Two authorities, one host

| Authority | Owner | May do | Must not do |
|---|---|---|---|
| Practice agreement | hopf-workshop `Workshop` | explore, propose, consent, commit, withdraw, act, repair, release | travel between scales |
| Scale travel | `ScaleSystem` | shrink / grow through existing gates | write consent |
| Presentation | Babylon Decision Well rig | consume `DecisionFrame` + `TetraOverlay` | mutate Workshop during render |

The well consumes `contracts/presentation-frame.md`. Commands revalidate through `Workshop.blockers()` / `actionBlockers()` at click time.

## Insertion API

Use the existing world contract. Do not invent a second interactable system.

```ts
WorldInteractable { id, kind: 'decision_well', position, radius, meta? }
LayerContent.presentationMarks['well_*']
```

GameEngine already routes `F` through interactables. Well-open is a distinct command from gate-enter.

## Existing gates (do not relocate)

| id | from→to | dir | position | radius |
|---|---|---|---|---|
| garden_to_forest | 0→1 | shrink | (0, 6, 0) | 5 |
| forest_to_garden | 1→0 | grow | (0, 14, 58) | 4 |
| forest_to_desert | 1→2 | shrink | (0, 6, −20) | 4.5 |
| desert_to_forest | 2→1 | grow | (0, 12, 72) | 4 |
| desert_to_core | 2→3 | shrink | (0, 18, 0) | 4 |
| core_to_desert | 3→2 | grow | (0, 10, 42) | 4 |

## Well defaults (measure, then lock)

| Vertex | Layer | Default position | Keep clear of |
|---|---|---|---|
| V0 | Garden | (16, 3.2, 8) r=3.5 | cube gate (0,6,0), cube mesh (0,9,0) |
| V1 | Forest | (16, 4, 8) r=3.5 | seed (0,6,−20), grow ring (0,14,58) |
| V2 | Desert | (18, 6, 16) r=3.5 | aperture (0,18,0), grow (0,12,72), glyph socket |
| V3 | Core | (14, 6, 16) r=3.5 | grow (0,10,42), coreRelay (0,12,0), Iris victory |

Record the actually shipped coordinates in the architecture lock.

## Scene strategy

- One Babylon scene already exists. Add a `TransformNode` well root per layer.
- Shared fibre geometry via thin instances or a sampled line system. No mesh-per-sample.
- Freeze static well-plinth materials. Bound particle and effect pools.
- Inspect overlay is HTML over the canvas (existing React HUD pattern), not a GPU-only GUI for essential actions.
- Reduced motion: instant pose changes; consent still updates next frame.
- Dispose observers, RAF, and GPU resources when the layer hides or the engine disposes.

## Persistence

`SAVE_VERSION` is 1. `migrateSave` fails closed on future versions.

Default for this run: workshop practice state is **session-only**, matching hopf-workshop replay snapshots.

If Cloud Nine must survive reload, that is DEC-SAVE-01 and requires `SAVE_VERSION = 2` plus a new optional `workshop` field. Do not reuse `puzzle.forestPylons`, `desertSolved`, or `coreReleased`.

# Deliverables

1. `docs/architecture/HOPF_DECISION_WELL_LOCK.md` — renderer boundary, seat/vertex transforms, well coordinates actually shipped, camera contract, fallback, event idempotency, budgets.
2. `src/workshop/` — vendored `hopf.js` (or extracted modules), `DecisionFrame` adapter, parity tests.
3. Decision Well rig — disc / torus / hourglass / lattice poses driven by Workshop facts.
4. One well interactable in each of the four layer files, plus GameEngine F-route.
5. Cloud Nine presentation in Garden after V3 unlock (tetra edges + Clifford torus). No new scale layer.
6. QA overlay: Canvas-2D / Math-lens peek of protocol \(z\) vs display \(z\), Ready vs Yes.
7. Tests: geometry, adapter, blockers, mount/unmount, 1–4 wells present, reduced motion, 2D fallback of the inspect HUD.
8. Screenshots under `docs/assets/hopf-wells/` for Garden / Forest / Desert / Core / Cloud Nine / reduced motion / Ready≠Yes.
9. `docs/tests/HOPF_WELLS_EVIDENCE.md` with commands, SHAs, measurements, `NOT_TESTED` items.
10. Developer handoff naming rollback and the smallest next Paul decision.

# Multi-agent workflow

- **Lead integrator:** baseline, branch, shared contracts, GameEngine hook, final reconciliation. Only role that edits `GameEngine.ts`, `App.tsx`, `SaveSystem.ts`, package manifests.
- **Archaeology / contract agent:** read-only after Phase 0. Owns the lock doc draft.
- **Workshop port agent:** `src/workshop/**` and parity tests. Does not edit layer files.
- **Well rig agent:** new 3D files under `src/workshop/rig/` or `src/world/prefabs/`. Does not edit GameEngine concurrently.
- **Layer placement agent:** four layer files + presentationMarks only.
- **Independent reviewer:** new isolated tests and evidence. Attempts to prove the well is misleading, leaky, or granting consent.

The implementer may not be the sole verifier. Preserve disagreements.

# Phases and gates

## Phase 0 — Baseline and archaeology

Re-verify SHAs, dirty state, Babylon version, existing tests. Confirm hopf.js API and VisualizerView. Confirm gate coordinates. Record pre-existing failures.

**Gate:** no implementation until baseline, dirty files, and path ownership are recorded.

## Phase 1 — Contract and failing tests

Write the lock doc. Write failing tests for:

- tetra coords DEC-VP-01
- φ child scale
- `hopf(gauge(z,γ)) == hopf(z)`
- `holonomyAngle(π/3) == π/2`
- display \(z\) ≠ protocol \(z\) until explore
- Ready is not Yes
- four-vertex Cloud Nine predicate
- well positions outside existing gate radii

**Gate:** tests exist before the scene grows around them.

## Phase 2 — Garden vertical slice

One complete well in Observatory Garden:

- F-open / F-or-Esc-close
- live fibres from `fibre()`
- Maya / Finn / Bea dots with distinct Ready / Yes / No / unset / withdrawn
- Explore / propose / consent / commit / withdraw through Workshop
- HTML inspect overlay
- WebGL path inside the existing engine; inspect HUD remains HTML if the rig fails
- reduced motion
- complete dispose

**Gate:** playable, no engine rule change, no dual-use cube, input to visible fibre ≤ one frame.

## Phase 3 — Four wells

Same rig, four placements. Copy-preview across an edge proposes at the destination and leaves destination consents unset.

**Gate:** exactly four wells, deterministic marks, no gate swallowed.

## Phase 4 — Tetrahedron + Cloud Nine

After V3 has been unlocked by the existing game (not by a Workshop commit), Garden presents six edges + Clifford torus when `tetraAlignment` is true. Withdrawal dashes the affected edge immediately.

**Gate:** Cloud Nine is a presentation state, not layer 4. Grow/shrink still work.

## Phase 5 — Look, accessibility, performance

Restrained IT³ pass. Quality tiers. Reduced motion. Keyboard well operation. Contrast. No color-only consent. Measure FPS in 1-well and 4-well-unlocked Garden.

**Gate:** independent reviewer reports before classification.

## Phase 6 — Handoff

Local verification, coherent commits, evidence. Do not push. Ask Paul for inspect / revise / authorize publication.

# Required verification

## Static

- Existing fractal-block `npm run verify` path (format, types, unit, build) with changes accounted for.
- No Hopf imports in combat / ScaleSystem mutators.
- No eager workshop chunk on the title screen beyond the existing GameEngine dynamic import.
- Exact fibre math parity with hopf.js fixtures.

## Behavioral

- Gauge invariance, holonomy 60°→90°, blockers prevent commit, withdraw pauses, v2 does not inherit v1 Yes.
- Four wells present; Cloud Nine predicate; copy-preview does not transfer Yes.
- Existing pylon / glyph / warden / Iris paths still complete.
- Forced rig failure leaves the game playable and the inspect HUD readable.

## Visual

- Screenshots listed above.
- Human check: cube gate still shrinks; well F is distinct; Ready shape ≠ Yes shape.

## Adversarial

Attempt to produce:

- a Yes granted by finishing the morph;
- a shrink that fires because the player stood in the well;
- v1 approvals shown as v2 consent;
- a hidden withdrawn person;
- a fifth scale layer;
- leaked meshes after repeated well open/close and rematch-equivalent reload;
- an unreadable well in Garden daylight because the IT³ void replaced the sky;
- a save that cannot load because workshop fields were jammed into puzzle flags.

If a check is not run, say `NOT_TESTED`.

# Completion criteria

Complete only when:

- all four wells exist and are F-interactable;
- Garden slice proves Ready≠Yes and withdraw-pauses;
- Cloud Nine presentation appears only from the tetra predicate;
- ScaleSystem and Workshop remain separate authorities;
- evidence is recorded;
- an independent review has attempted to disprove completion;
- original checkouts and user-owned dirty files remain untouched;
- no push, PR, merge, or deploy occurred.

# Stop conditions

Stop and ask for the smallest exact decision if:

- current main contains a conflicting accepted architecture decision;
- implementation would require ScaleSystem, combat, or protocol kernel changes;
- DEC-SAVE-01 persistence is required to make Cloud Nine honest;
- a requested asset has unclear rights;
- keeping a playable game after rig failure becomes impossible;
- Paul must choose between materially different product outcomes (see `07_HANDOFF.md`).

# Final report

Lead with the working preview command. Then report the fourteen-point handoff listed in `07_HANDOFF.md`. Classify work as:

`implemented_and_verified` | `implemented_with_limitations` | `contract_complete_not_integrated` | `blocked` | `deferred` | `not_attempted`

# Begin

Begin by inspecting both repositories, recording exact baselines and dirty state, vendoring `hopf.js` behind parity tests, and placing the Garden well off the cube gate. Make reasonable assumptions inside this boundary. Do not wait for Paul to restate DEC-VP-01, DEC-GATE-01, offset wells, Iris-as-narrative, or Cloud Nine ≠ layer 4.
