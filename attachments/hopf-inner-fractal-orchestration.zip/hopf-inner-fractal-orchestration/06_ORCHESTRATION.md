# 06 Orchestration

**Status:** Execution map for the implementation grant in `05_IMPLEMENTATION_PROMPT.md`.
**Host work happens on:** `jedisherpa/fractal-block` feature branch.
**Protocol authority stays on:** `jedisherpa/hopf-workshop`.

This file divides labor. It does not authorize work. Activation is Paul's explicit “begin” on `05`.

## Path ownership

| Owner | May edit | Must not edit concurrently |
|---|---|---|
| Lead integrator | `GameEngine.ts`, `WorldBuilder.ts`, `App.tsx` integration seams, Vite/package only after review, architecture lock, final reconciliation | hopf.js semantics |
| Archaeology | nothing (read-only) | everything |
| Kernel / view | `src/workshop/hopf.*`, `src/workshop/view.*`, parity fixtures/tests | GameEngine, layer files |
| Babylon well | `src/workshop/DecisionWell.*`, `TetraOverlay.*`, `WorkshopDirector.*`, procedural materials | hopf.js public API |
| Layer dress | four files in `src/world/layers/` **only** to add `decision_well` interactable + `presentationMarks.well_*` | ScaleSystem gate positions |
| Persistence | `SaveSystem.ts` + `gameConfig.ts` **only if** DEC-SAVE-01 persistence is chosen mid-run | puzzle flags |
| Adversarial | `docs/tests/HOPF_WELL_EVIDENCE.md`, new isolated tests, screenshot matrix | implementation under review |

Serialize: presentation-frame types → kernel vendor → Garden well → four wells → Cloud Nine → GameEngine hook.

Parallelize: asset inventory, test planning, accessibility checklist, IT³ look token sheet, well-offset measurement screenshots.

## Feature branch

Preferred host branch: `codex/hopf-decision-well`.
If it exists, record the collision and use `codex/hopf-decision-well-2` or a dated successor.
Do not commit on `main`. Do not push unless Paul issues a new grant.

Optional hopf-workshop branch only if parity fixtures need a home the host should not carry. Default: vendor into the host and leave hopf-workshop `main` untouched.

## Phase-to-owner map

| Phase | Gate | Primary owner | Independent check |
|---|---|---|---|
| 0 Baseline | SHAs, dirty state, collision map recorded | Archaeology + Lead | Lead signs the record |
| 1 Contract + failing tests | Ready ≠ Yes and well-not-on-gate tests exist and fail | Kernel + Lead | Adversarial reviews the tests |
| 2 Garden slice | Playable V0 well, cube gate untouched | Babylon well + Layer dress | Adversarial + Lead |
| 3 Four wells + edges | Copy-preview does not inherit Yes | Babylon well + Kernel | Adversarial |
| 4 Cloud Nine | Predicate-only torus in transformed Garden | Lead + Babylon well | Adversarial |
| 5 Hardening | Evidence file filled, including `NOT_TESTED` | Adversarial | Lead may not fill this alone |
| 6 Handoff | Local commits, preview command, no push | Lead | Archaeology confirms dirty files preserved |

## What stays out of this run

- TAWarRoom flagship plan (`docs/tawarroom-flagship-planning/` in hopf-workshop)
- WeOpoly production
- SYNC/FALL / `jedisherpa/multiplayer-falling-block-game`
- Babylon 9.25.0 pin
- ScaleLayerId 4
- DEC-GATE-02 (workshop required to shrink) unless Paul changes DEC-GATE-01
- Iris as a consenting seat
- Dual-use Impossible Cube

## Communication

Each handoff uses the block required by `05`. Preserve disagreement. A cleaner story is not a reason to drop a negative finding.

If two owners need the same file, the lead serializes. Do not merge competing GameEngine patches by vibes.

## Preview command (to be confirmed after Phase 0 inspection)

Expected shape, adapt after reading current `package.json` scripts:

```sh
pnpm install
pnpm dev
# open the local Vite URL, start a run, fly to Garden well at ~ (16, 3.2, 8)
```

Record the actual command in the architecture lock. Do not invent a script name.
