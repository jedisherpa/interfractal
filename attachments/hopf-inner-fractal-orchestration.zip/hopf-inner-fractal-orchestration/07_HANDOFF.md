# 07 Handoff

**Status:** Planning package complete. Implementation not started.
**Date:** 2026-09-16
**Audience:** Paul, then the Grok build team after activation.

## What you are holding

A source-grounded orchestration package for making Hopf Workshop a 3D Decision Well inside Inner Fractal. It is not a built game, not a TAWarRoom deployment, and not permission to push.

```text
hopf-inner-fractal-orchestration/
  00_README.md
  01_ARCHAEOLOGY.md
  02_GEOMETRY_CONTRACT.md
  03_VALUES_PRISM_MAP.md
  04_AESTHETIC_GRAMMAR.md
  05_IMPLEMENTATION_PROMPT.md      ← activate only when you say begin
  06_ORCHESTRATION.md
  07_HANDOFF.md                    ← this file
  contracts/presentation-frame.md
  contracts/nonclaims.md
  contracts/well-positions.md
```

Give the implementation team the **entire package**.

## What was inspected

| System | What exists | SHA at inspection |
|---|---|---|
| hopf-workshop | JS + Python teaching model v0.2, 2D canvas visualizer, Workshop kernel | `dd0ab5ea42e34fb53ebee461f7fc6831d6415205` |
| fractal-block / Inner Fractal | React 19 + Vite 8 + Babylon **8**, four scale layers, no Hopf code | `043e614959f916fe7273e66ba1b3fa7011b8de57` |
| SYNC/FALL prompt | Adjacent Babylon 3D arena work order for a different game | donor only |
| IT³ clip | 30s disc → torus → Perez hourglass → cubocta lattice | look only |
| Values Prism short form | Self → Tribe → World → Freedom/Creativity as completed circuit | spoken intention |

Corrections already applied:

- There is no `fractal-block-world` repo and no `inner-fractal` branch.
- Host is `jedisherpa/fractal-block`.
- Do not pin Babylon 9.25.0.
- Garden scale ring at `(0, 6, 0)` must not be the well.

## Defaults locked pending you

Use these if you activate without further comment. Change any of them with one sentence.

| ID | Default | Alternative you may pick |
|---|---|---|
| **DEC-VP-01** | V0 Self Garden `(1,1,1)/√3` · V1 Forest `(1,-1,-1)/√3` · V2 Tribe Desert `(-1,1,-1)/√3` · V3 World Core `(-1,-1,1)/√3` | Different vertex ↔ layer pairing |
| **DEC-GATE-01** | Workshop optional. ScaleSystem unchanged. Combat/puzzles still unlock travel. | **DEC-GATE-02**: local commit required to shrink. Not recommended; collapses travel and permission. |
| **Wells** | Offset from gates. Garden default `(16, 3.2, 8)` radius 3.5. | Dual-use cube. Rejected. |
| **Seats** | Maya / Finn / Bea, labeled fictional, simulated. | Live multiplayer seats. Out of this run. |
| **Iris** | Narrative signal + Core victory interactable. Not a Workshop seat. | Iris as fourth consenter. Rejected for this run. |
| **Cloud Nine** | Transformed Garden + Clifford torus. Not `ScaleLayerId 4`. | Fifth scale layer. Rejected. |
| **DEC-SAVE-01** | Session-only Workshop state. Persist Cloud Nine only if you later ask, via `SAVE_VERSION` 2. | Immediate SAVE_VERSION bump. |
| **DEC-PKG-01** | Vendor hopf.js into the host with provenance SHA. | Workspace package / npm-link. Ask first. |

## Smallest next human decisions

You do not need to answer these to activate. The prompt will use the defaults. Answer only if you want a different default.

1. Activate `05_IMPLEMENTATION_PROMPT.md`? (yes / revise / wait)
2. Keep DEC-GATE-01 (recommended) or switch to DEC-GATE-02?
3. Keep Garden well at `(16, 3.2, 8)` or name another landmark?
4. Session-only workshop, or SAVE_VERSION 2 from day one?
5. After a verified local preview, may the branch be pushed / PR opened? (default: no)

## Residual risks

- TAWarRoom flagship plan already claims the visualizer centerpiece for a different product. Scope collision is named, not solved.
- hopf-workshop and fractal-block `main` may move before activation. The prompt requires a refresh, not a silent reset.
- Human playtest of WeOpoly rehearsal is `NOT_RUN`. Automated seats are not four humans. This run stays simulated.
- Whether \(3{,}317{,}760{,}000\) is the field discriminant of \(K=\mathbb Q(\sqrt{2},\sqrt{3},\sqrt{5})\) is **UNKNOWN**. Display the integer identity; do not claim CMB hardware.
- Garden daylight vs IT³ black void: if the well punches a black hole in the plaza, stop and ask. Do not “fix” it by replacing layer lighting.
- `ScaleSystem.canUseGate` currently allows any shrink from the current layer. DEC-GATE-01 preserves that. A future DEC-GATE-02 would be a product change, not a renderer trick.
- Feat-level overhaul branches exist (`feat/level-one-observatory-overhaul`, etc.). Implementation must inspect whether `main` or `integration/all-levels` is the stronger host before choosing the worktree parent.

## Rollback

Nothing has been changed in either repository. Rollback of this package is “do not activate `05`.”

After a future implementation run: disable the well flag or delete the isolated worktree. Canonical `main` and production must remain unchanged until you issue a new grant.

## Preview (after a future implementation, not now)

The implementation report must lead with the actual command. Expected shape:

```sh
pnpm install && pnpm dev
```

Fly to Observatory Garden. The gold scale ring at the cube remains the shrink gate. The Decision Well sits off-axis near `(16, 3.2, 8)`. F opens practice. Ready is not Yes.

## Classification of this package

`contract_complete_not_integrated`

Supported:

- Repo names, SHAs, layer list, gate coordinates, Workshop public API, VisualizerView shape, DISCIPLINE invariants, Babylon 8 host, absence of Hopf code in fractal-block.

Unknown / not tested:

- Live visual QA of fractal-block.vercel.app (JS SPA text extraction failed; layer names taken from source).
- Field-discriminant claim for ΔK.
- Human comprehension of Ready ≠ Yes inside a flying game.
- Whether feat-level branches contain a better well site than main.

Contradicted (user wording vs source):

- `fractal-block-world` / `inner-fractal` branch — do not exist.
- Babylon 9.25.0 as the host version — host is 8.x.
- Cloud Nine as a fifth playable scale — rejected by this package.
