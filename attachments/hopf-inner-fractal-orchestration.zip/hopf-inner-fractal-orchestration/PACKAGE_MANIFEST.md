# Package manifest

**Prepared:** 2026-09-16
**Classification of this package:** `contract_complete_not_integrated`
**Activation:** Paul says begin on `05_IMPLEMENTATION_PROMPT.md`

SHA refresh at package close (2026-09-16 23:12 UTC):

- hopf-workshop `main` `dd0ab5ea42e34fb53ebee461f7fc6831d6415205` — current
- fractal-block `main` `043e614959f916fe7273e66ba1b3fa7011b8de57` — current
- hopf.js blob `c36df81e8421c07e3e89bce3d9c59e75b6d74698`

| Path | Role |
|---|---|
| 00_README.md | Index and one-sentence outcome |
| 01_ARCHAEOLOGY.md | Repos, SHAs, gates, seams, negative findings |
| 02_GEOMETRY_CONTRACT.md | Layer A Hopf / Layer B Fuller / Layer C IT³ look |
| 03_VALUES_PRISM_MAP.md | Self Forest Tribe World Cloud Nine + DEC-VP-01 |
| 04_AESTHETIC_GRAMMAR.md | 30s clip → in-game pose machine |
| 05_IMPLEMENTATION_PROMPT.md | Paul-style work order (activate to build) |
| 06_ORCHESTRATION.md | Path ownership and phase-to-owner map |
| 07_HANDOFF.md | Defaults, open decisions, rollback |
| contracts/presentation-frame.md | Typed view the rig may consume |
| contracts/nonclaims.md | Hard nonclaims |
| contracts/well-positions.md | Gate coords vs offset wells |
| PACKAGE_MANIFEST.md | This file |
