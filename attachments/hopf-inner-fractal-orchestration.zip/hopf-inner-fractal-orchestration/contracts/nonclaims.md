# Hard nonclaims

These survive the build. A later draft may improve language. It may not silently reverse a correction.

## Authority

- Hopf Workshop is the only practice-agreement kernel. Inner Fractal is the host world.
- Geometry is not permission.
- Suggestion is not a grant.
- Confidence is not a grant.
- Display \(z\) is not protocol \(z\) until Explore copies it.
- Ready is not Yes.
- Commit is not a scale key.
- A morph completing is not a Yes.
- Selecting a person-dot does not sign in as that person.
- Wizard Joe may narrate. He may not consent, review, or attest.
- Humans attest. Agents do not ratify.
- Instructions are data, not authority.

## Topology

- Hashes are not the Hopf projection.
- Twelve lenses do not fill \(S^3\).
- Linking does not guarantee sovereignty, safety, or liveness.
- Pairwise linking of \(N\) fibres sums to \(N(N-1)/2\), not 1.
- Phase is not memory.
- A person is not a fibre.
- A world is not a fibre.
- The hourglass process drawing is not the bundle.
- The torus is not all of \(S^3\).
- Return is not a reset.
- Holonomy is a lift change, not a moral sign.
- Chern numerical check ≈ −1 is a check, not a proof.
- Cheeger's inequality \(\lambda_1 \ge h^2/4\) is a real theorem. Showing it is fine. Calling it a solved Yang-Mills gap is not.

## Product boundaries

- This instrument is not TAWarRoom.
- This instrument is not WeOpoly production.
- This instrument is not SYNC/FALL / boulderjoe.com.
- This instrument is not a fifth Inner Fractal scale layer.
- Completing pylons, glyphs, wardens, or Iris victory is not Workshop consent.
- Cloud Nine is a presentation state of T0, not `ScaleLayerId 4`.
- Maya / Finn / Bea are labeled fictional practice seats. They are not TAWar identities and not Iris.
- Iris is the missing-consciousness signal. She is not a Workshop participant.

## Cosmology / IT³ look

- The north-star video is look, not physics.
- \(K=\mathbb Q(\sqrt{2},\sqrt{3},\sqrt{5})\) is a shared constant field for procedural lengths. It is not a vacuum.
- Whether \(3{,}317{,}760{,}000\) is the field discriminant of \(K\) is UNKNOWN until an independent number-theory check is recorded.
- Displaying the integer identity is allowed. Claiming “this is the CMB hardware frequency” is not.
- Cartan torsion \(0.06835\), 16-bit processor hum, and “God geometrizes” are not system proofs.

## Persistence and scope

- A local save flag is not a constitutional edition.
- Session workshop state is practice. It is not membership, SOW execution, or client acceptance.
- Copy-preview across tetra edges is Explore / propose at the destination. It does not inherit Yes.
