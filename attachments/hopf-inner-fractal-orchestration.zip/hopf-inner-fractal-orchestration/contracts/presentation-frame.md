# Presentation frame contract

The 3D Decision Well consumes a typed view. It does not own Workshop state.

Source of the view: hopf-workshop `visualizer.js` (`projectParade` / `projectRehearsal` / `entities` / `inspect` / `sameFacts`). Commands stay outside the view-model, exactly as they do in the 2D lab.

## Frame identity

```ts
type VertexId = 'V0' | 'V1' | 'V2' | 'V3';
type ScaleLayerId = 0 | 1 | 2 | 3;

interface DecisionFrame {
  vertex: VertexId;
  layer: ScaleLayerId;
  scopeId: 'parade' | 'rehearsal';
  sourceRevision: number;          // workshop.history.length
  snapshotId: string;              // idempotent cosmetic key
  timeContext: { kind: 'current' } | { kind: 'history'; index: number };
  proposal: { id: string; version: number; description: string } | null;
  agreement: {
    id: string;
    status: 'active' | 'paused' | 'retired';
    version: number;
    description: string;
  } | null;
  participants: ParticipantView[];
  recordedReviews: ReviewView[];
  actionAvailability: ActionView[];
  needed: string[];
  nextStep: string;
  events: EventView[];
  consequences: ConsequenceView[];
  exploration: { id: string; description: string } | null;
  round: { phase: string; round: number; lastReturn?: { round: number; applied: boolean } } | null;
  dataHealth: 'ok' | 'stale' | 'unknown';
}
```

`sameFacts(prev, next)` decides whether the rig rebuilds. If facts are equal, do not replay cosmetics.

## Participant facts that must stay distinct

```ts
type Response = 'unset' | 'yes' | 'no' | 'withdrawn';

interface ParticipantView {
  id: string;                 // `person:${name}`
  name: string;               // Maya | Finn | Bea (default)
  response: Response;         // version-scoped
  responseVersion: number | null;
  earlier: { version: number; answer: Response }[];
  ready: boolean | null;      // null outside rehearsal; never coerce ready → yes
}
```

Draw Ready and Yes with different shapes. Color is not enough.

## Action availability

Use Workshop `blockers()` / `actionBlockers()` as the only eligibility source. The frame may display reasons. It may not invent a new reason that the kernel does not emit.

Required actions: `commit` · `act` · `repair` · `release`.

Labels stay close to the existing visualizer:

- commit → “Make this agreement”
- act → “Try the agreed action”
- repair → “Record the response to earlier consequences”
- release → “Release / retire”

## Inspect overlay

`Visualizer.inspect(view, selection)` is the body text. Do not write a second inspector that paraphrases consent into “aligned.”

Selection types already defined: `overview` · `exploration` · `proposal` · `agreement` · `person` · `review` · `consequence` · `event`.

History inspection displays a persistent “Earlier state” banner. Mutation controls are unavailable from historical snapshots.

## Tetra overlay facts (host-owned, kernel-informed)

The host may add a thin wrapper. It may not add new permission fields.

```ts
interface TetraOverlay {
  localAlignment: boolean;          // active agreement at this vertex + version
  cloudNine: boolean;               // all four applicable, no open withdrawal
  edges: {
    from: VertexId;
    to: VertexId;
    kind: 'empty' | 'preview' | 'locked' | 'dashed-withdrawn';
    previewVersion: number | null;
  }[];
  wellPose: 'disc' | 'torus' | 'hourglass' | 'lattice' | 'cloud-nine';
}
```

`wellPose` is a function of Workshop + tetra facts (see `04_AESTHETIC_GRAMMAR.md`). It is not a fifth protocol field stored inside `Workshop`.

## Commands the host may issue

The host issues ordinary Workshop methods after an explicit player gesture:

`explore` · `reframe` · `propose` · `proposeSuggestion` · `consent` · `withdraw` · `review` · `commit` · `act` · `resolveRepair` · `release` · `object` · `dispose` · `correct` · `holonomy` · `setConfidence`

In this bounded Inner Fractal run, default practice seats are simulated. The player is operating a teaching model, not signing as Maya / Finn / Bea. HUD copy must say so.

Copy-preview across an edge is `propose(description)` at the destination Workshop, with a recorded source vertex + source version in the destination history detail. Destination consents stay unset.

## What the frame must never do

- Mutate `Workshop` during render.
- Treat `ready === true` as `response === 'yes'`.
- Hide a withdrawn person.
- Transfer Yes from v1 onto v2 wording.
- Drive React state at render-loop frequency.
- Create one React component or one Babylon mesh per fibre sample.
- Bind flight keys to camera-orbit around the well.
