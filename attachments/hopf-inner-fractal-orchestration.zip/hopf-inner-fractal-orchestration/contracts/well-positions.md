# Decision Well positions

Defaults for this work order. Builder may nudge after a measured screenshot. Must stay outside the existing gate radius. Dual-use cube is forbidden.

## Existing travel gates (do not reuse)

From `src/scale/ScaleSystem.ts` `buildScaleGates()` at fractal-block `043e6149`:

| id | dir | from→to | position | radius | label |
|---|---|---|---|---|---|
| garden_to_forest | shrink | 0→1 | (0, 6, 0) | 5 | Enter the Impossible Cube |
| forest_to_garden | grow | 1→0 | (0, 14, 58) | 4 | Grow to Observatory Garden |
| forest_to_desert | shrink | 1→2 | (0, 6, −20) | 4.5 | Enter the Seed Core |
| desert_to_forest | grow | 2→1 | (0, 12, 72) | 4 | Grow to Circuit Forest |
| desert_to_core | shrink | 2→3 | (0, 18, 0) | 4 | Enter the Aperture |
| core_to_desert | grow | 3→2 | (0, 10, 42) | 4 | Grow to Monument Desert |

Garden authored cube (ObservatoryGarden.ts): visual box at `(0, 11.5, 0)`, scale ring torus at `(0, 6, 0)`. WorldBuilder may also instance `art/impossible-cube` near `(0, 9, 0)` scale 0.88. Treat the whole cube/ring assembly as reserved for travel.

## Recommended wells

| presentationMark | vertex | layer | default position | radius | keep clear of |
|---|---|---|---|---|---|
| `well_garden` | V0 Self | 0 Observatory Garden | (16, 3.2, 8) | 3.5 | ring (0,6,0) r=5, cube (0,11.5,0) |
| `well_forest` | V1 Forest | 1 Circuit Forest | (16, 4, 8) | 3.5 | seed (0,6,−20) r=4.5, grow (0,14,58) |
| `well_desert` | V2 Tribe | 2 Monument Desert | (18, 6, 16) | 3.5 | aperture (0,18,0) r=4, grow (0,12,72) |
| `well_core` | V3 World | 3 Inner Core | (14, 6, 16) | 3.5 | grow (0,10,42), Iris / coreRelay ~(0,12,0) |

Garden rationale: +X of plaza, near the equip bench at `(14, 2.8, −10)`, off the +Z approach tiles, clear of ceremonial columns (~±20, ±15) and the observation arch (−15, 18). Player can see the cube while using the well. F-on-well is distinct from F-on-ring.

Forest / Desert / Core numbers are **defaults, not surveyed**. Implementation must inspect each layer file, take a screenshot, and record the actually chosen coordinate in `docs/architecture/HOPF_DECISION_WELL_LOCK.md`.

## Distance invariant

For every well \(W\) and every gate \(G\) on the same layer:

\[
\|W - G\| \ge r_W + r_G + 2
\]

A test must fail if a well sits inside a gate's interact radius. This is how DEC-GATE-01 stays honest.

## Interactable shape

```ts
{
  id: 'decision_well_V0',          // V1 / V2 / V3
  kind: 'decision_well',
  position: { x: 16, y: 3.2, z: 8 },
  radius: 3.5,
}
```

Also write `presentationMarks.well_garden` (etc.) so `WorldBuilder.resolvePresentationPoint` and Wizard Joe can aim at the well without hardcoding.
