// HOPF: This entire file is new or heavily modified to implement the formal Shiab Operator.
use crate::genesis::{ActionSpace, WillVector};
use crate::prelude::*;
use std::ops::Deref;

/// The Hopf Projection Map: p(S³) → S²
/// This trait defines the core constitutional validation function.
pub trait ActionValidator {
    fn validate_action(&self, action: &ActionSpace) -> Result<f32, ValidationError>;
}

/// The default implementation of the Shiab Operator.
/// It holds the user's sovereign WillVector (S²) and projects actions from S³ onto it.
pub struct DefaultActionValidator {
    // HOPF: The WillVector is the Base Space (S²) of the Hopf Fibration.
    pub will_vector: WillVector,
}

impl ActionValidator for DefaultActionValidator {
    /// CONSTITUTIONAL INVARIANT — Article 8: Pre-Validation Mandate
    /// This function MUST return Ok(similarity) before any compute call is made.
    /// Threshold: cosine similarity ≥ 0.8
    fn validate_action(&self, action: &ActionSpace) -> Result<f32, ValidationError> {
        // HOPF: Added validation against empty prompt.
        if action.content.trim().is_empty() {
            return Err(ValidationError::EmptyPrompt);
        }

        // HOPF: This is the core of the Hopf projection. We derive the action's embedding
        // and then compute its cosine similarity to the sovereign WillVector.
        let action_embedding = derive_action_embedding(&action.content);
        let similarity = cosine_similarity(&self.will_vector.embedding, &action_embedding);

        if similarity >= 0.8 {
            Ok(similarity)
        } else {
            Err(ValidationError::BlockedByWillVector(format!(
                "Action similarity {:.3} below threshold 0.8 — blocked by sovereign intent",
                similarity
            )))
        }
    }
}

/// Placeholder: in production, call the active compute provider's get_embedding()
/// This must use the SAME embedding model as was used during Genesis Rite
fn derive_action_embedding(content: &str) -> [f32; 384] {
    let mut embedding = [0.0f32; 384];
    let bytes = content.as_bytes();
    for (i, chunk) in bytes.chunks(32).enumerate() {
        let hash = ring::digest::digest(&ring::digest::SHA256, chunk);
        for (j, val) in hash.as_ref().iter().enumerate() {
            embedding[(i * 32 + j) % 384] += *val as f32 / 255.0;
        }
    }
    normalize_embedding(&mut embedding);
    embedding
}

fn normalize_embedding(embedding: &mut [f32; 384]) {
    let norm = (embedding.iter().map(|v| v * v).sum::<f32>()).sqrt();
    if norm > 0.0 {
        for val in embedding.iter_mut() {
            *val /= norm;
        }
    }
}

/// Computes the cosine similarity between two 384-dimensional vectors.
fn cosine_similarity(a: &[f32; 384], b: &[f32; 384]) -> f32 {
    let dot_product = a.iter().zip(b.iter()).map(|(x, y)| x * y).sum::<f32>();
    let norm_a = a.iter().map(|v| v * v).sum::<f32>().sqrt();
    let norm_b = b.iter().map(|v| v * v).sum::<f32>().sqrt();

    if norm_a == 0.0 || norm_b == 0.0 {
        0.0
    } else {
        dot_product / (norm_a * norm_b)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn mock_will_vector() -> WillVector {
        let mut embedding = [0.0f32; 384];
        embedding[0] = 1.0;
        WillVector { embedding, directives: vec!["test".to_string()] }
    }

    #[test]
    fn validation_passes_for_similar_action() {
        let validator = DefaultActionValidator { will_vector: mock_will_vector() };
        let action = ActionSpace::from_prompt("test");
        let result = validator.validate_action(&action);
        assert!(result.is_ok());
        assert!(result.unwrap() >= 0.8);
    }

    #[test]
    fn validation_fails_for_dissimilar_action() {
        let validator = DefaultActionValidator { will_vector: mock_will_vector() };
        let action = ActionSpace::from_prompt("different");
        let result = validator.validate_action(&action);
        assert!(result.is_err());
    }
}