use std::collections::{BTreeMap, HashMap, HashSet};
use std::fmt;
use std::sync::Arc;

// HOPF: Import types from Layer 1 to implement the projection map
use crate::{ActionSpace, WillVector, validate_action_with_will_vector};

pub const PROVIDER_QWEN_LOCAL: &str = "qwen_local";
pub const PROVIDER_OLLAMA: &str = "ollama";

#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum ProviderKind {
    Local,
    Cloud,
    Decentralized,
}

// HOPF: Added FiberType to classify the S¹ closed loop by its opacity.
#[derive(Debug, Clone, serde::Serialize, serde::Deserialize, PartialEq)]
pub enum FiberType {
    /// Closed loop on-device. Fully opaque by default.
    Local,
    /// Closed loop via HTTPS. Provider sees plaintext.
    Api,
    /// Closed loop via encrypted compute. Provider sees nothing.
    Fhe,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ProviderHealth {
    pub provider_id: String,
    pub kind: ProviderKind,
    pub is_healthy: bool,
    pub detail: Option<String>,
}

impl ProviderHealth {
    pub fn healthy(
        provider_id: impl Into<String>,
        kind: ProviderKind,
        detail: impl Into<Option<String>>,
    ) -> Self {
        Self {
            provider_id: provider_id.into(),
            kind,
            is_healthy: true,
            detail: detail.into(),
        }
    }

    pub fn unhealthy(
        provider_id: impl Into<String>,
        kind: ProviderKind,
        detail: impl Into<Option<String>>,
    ) -> Self {
        Self {
            provider_id: provider_id.into(),
            kind,
            is_healthy: false,
            detail: detail.into(),
        }
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub enum ComputeErrorKind {
    ProviderUnavailable,
    ProviderNotRegistered,
    InvalidRequest,
    Unsupported,
    Timeout,
    Internal,
    // HOPF: Added to represent when an action is blocked by the WillVector.
    ValidationBlocked,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct ComputeError {
    pub kind: ComputeErrorKind,
    pub provider_id: Option<String>,
    pub message: String,
}

impl ComputeError {
    pub fn new(
        kind: ComputeErrorKind,
        provider_id: Option<String>,
        message: impl Into<String>,
    ) -> Self {
        Self {
            kind,
            provider_id,
            message: message.into(),
        }
    }

    pub fn provider_unavailable(
        provider_id: impl Into<String>,
        message: impl Into<String>,
    ) -> Self {
        Self::new(
            ComputeErrorKind::ProviderUnavailable,
            Some(provider_id.into()),
            message,
        )
    }

    pub fn provider_not_registered(provider_id: impl Into<String>) -> Self {
        let provider_id = provider_id.into();
        Self::new(
            ComputeErrorKind::ProviderNotRegistered,
            Some(provider_id.clone()),
            format!("provider \'{provider_id}\' is not registered"),
        )
    }

    pub fn invalid_request(message: impl Into<String>) -> Self {
        Self::new(ComputeErrorKind::InvalidRequest, None, message)
    }

    pub fn internal(provider_id: impl Into<String>, message: impl Into<String>) -> Self {
        Self::new(
            ComputeErrorKind::Internal,
            Some(provider_id.into()),
            message,
        )
    }
}

impl fmt::Display for ComputeError {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        match &self.provider_id {
            Some(provider_id) => write!(f, "{:?}({provider_id}): {}", self.kind, self.message),
            None => write!(f, "{:?}: {}", self.kind, self.message),
        }
    }
}

impl std::error::Error for ComputeError {}

pub type ComputeResult<T> = Result<T, ComputeError>;

#[derive(Debug, Clone, PartialEq, Default)]
pub struct GenerateRequest {
    pub prompt: String,
    pub system_prompt: Option<String>,
    pub max_tokens: Option<u32>,
    pub temperature: Option<f32>,
    pub provider_override: Option<String>,
    pub metadata: BTreeMap<String, String>,
}

impl GenerateRequest {
    pub fn new(prompt: impl Into<String>) -> Self {
        Self {
            prompt: prompt.into(),
            ..Self::default()
        }
    }

    pub fn with_provider_override(mut self, provider_id: impl Into<String>) -> Self {
        self.provider_override = Some(provider_id.into());
        self
    }

    pub fn with_metadata(mut self, key: impl Into<String>, value: impl Into<String>) -> Self {
        self.metadata.insert(key.into(), value.into());
        self
    }
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct TokenUsage {
    pub prompt_tokens: u32,
    pub completion_tokens: u32,
    pub total_tokens: u32,
}

#[derive(Debug, Clone, PartialEq)]
pub struct GenerateResponse {
    pub provider_id: String,
    pub model: String,
    pub output_text: String,
    pub finish_reason: Option<String>,
    pub usage: Option<TokenUsage>,
    pub metadata: BTreeMap<String, String>,
    pub latency_ms: u64,
}

#[derive(Debug, Clone, PartialEq)]
pub struct EmbeddingResponse {
    pub provider_id: String,
    pub embedding: Vec<f64>,
}

pub trait ComputeProvider: Send + Sync {
    fn provider_id(&self) -> &'static str;
    fn kind(&self) -> ProviderKind;

    // HOPF: Added to make the fiber type explicit for observability.
    /// Returns the Hopf fiber type for this provider.
    /// This classifies the S¹ closed loop by its opacity to the provider.
    fn fiber_type(&self) -> FiberType {
        match self.kind() {
            ProviderKind::Local => FiberType::Local,
            ProviderKind::Cloud => FiberType::Api,
            ProviderKind::Decentralized => FiberType::Fhe,
        }
    }

    fn health_check(&self) -> ComputeResult<ProviderHealth>;
    fn get_embedding(&self, text: &str) -> ComputeResult<Vec<f64>>;
    fn generate_response(&self, req: GenerateRequest) -> ComputeResult<GenerateResponse>;
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct AttemptedProviderError {
    pub provider_id: String,
    pub error: ComputeError,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct RoutingFailure {
    pub requested_provider: String,
    pub attempts: Vec<AttemptedProviderError>,
}

impl fmt::Display for RoutingFailure {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        writeln!(
            f,
            "failed to generate response for requested provider '{}':",
            self.requested_provider
        )?;
        for attempt in &self.attempts {
            writeln!(f, "- {} => {}", attempt.provider_id, attempt.error)?;
        }
        Ok(())
    }
}

#[derive(Clone)]
pub struct ComputeRouter {
    providers: HashMap<String, Arc<dyn ComputeProvider>>,
    global_default_provider: String,
    local_fallback_priority: Vec<String>,
    cloud_fallback_priority: Vec<String>,
}

impl ComputeRouter {
    pub fn new(global_default_provider: impl Into<String>) -> Self {
        let global_default_provider = normalize_provider_id(global_default_provider.into())
            .unwrap_or_else(|| PROVIDER_QWEN_LOCAL.to_string());

        Self {
            providers: HashMap::new(),
            global_default_provider,
            local_fallback_priority: required_local_fallback_priority(),
            cloud_fallback_priority: Vec::new(),
        }
    }

    pub fn register_provider(
        &mut self,
        provider: Arc<dyn ComputeProvider>,
    ) -> Option<Arc<dyn ComputeProvider>> {
        let provider_id = normalize_provider_id(provider.provider_id())
            .expect("provider id returned by implementation cannot be empty");
        self.providers.insert(provider_id, provider)
    }

    pub fn contains_provider(&self, provider_id: &str) -> bool {
        normalize_provider_id(provider_id)
            .map(|provider_id| self.providers.contains_key(&provider_id))
            .unwrap_or(false)
    }

    pub fn provider(&self, provider_id: &str) -> Option<Arc<dyn ComputeProvider>> {
        normalize_provider_id(provider_id)
            .and_then(|provider_id| self.providers.get(&provider_id).cloned())
    }

    pub fn provider_ids(&self) -> Vec<String> {
        let mut provider_ids: Vec<_> = self.providers.keys().cloned().collect();
        provider_ids.sort();
        provider_ids
    }

    pub fn set_global_default_provider(&mut self, provider_id: impl Into<String>) {
        self.global_default_provider = normalize_provider_id(provider_id.into())
            .unwrap_or_else(|| self.global_default_provider.clone());
    }

    pub fn global_default_provider(&self) -> &str {
        &self.global_default_provider
    }

    pub fn set_local_fallback_priority<I, S>(&mut self, priority: I)
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.local_fallback_priority = normalize_local_fallback_priority(priority);
    }

    pub fn set_cloud_fallback_priority<I, S>(&mut self, priority: I)
    where
        I: IntoIterator<Item = S>,
        S: Into<String>,
    {
        self.cloud_fallback_priority = dedupe_provider_priority(priority);
    }

    pub fn resolve_provider_id(&self, provider_override: Option<&str>) -> String {
        provider_override
            .and_then(normalize_provider_id)
            .unwrap_or_else(|| self.global_default_provider.clone())
    }

    pub fn provider_chain_for_request(&self, provider_override: Option<&str>) -> Vec<String> {
        let requested_provider = self.resolve_provider_id(provider_override);
        let mut seen = HashSet::new();
        let mut chain = Vec::new();

        let mut add_to_chain = |provider_id: &str| {
            if !seen.contains(provider_id) {
                chain.push(provider_id.to_string());
                seen.insert(provider_id.to_string());
            }
        };

        add_to_chain(&requested_provider);

        if let Some(provider) = self.provider(&requested_provider) {
            match provider.kind() {
                ProviderKind::Local => {
                    for p in &self.local_fallback_priority {
                        add_to_chain(p);
                    }
                }
                ProviderKind::Cloud => {
                    for p in &self.cloud_fallback_priority {
                        add_to_chain(p);
                    }
                    for p in &self.local_fallback_priority {
                        add_to_chain(p);
                    }
                }
                ProviderKind::Decentralized => {
                    // Decentralized has no fallback for now
                }
            }
        }

        chain
    }

    // HOPF: Enforce validate_action() inside route_generate.
    pub fn route_generate(
        &self,
        req: GenerateRequest,
        will_vector: &WillVector, // Added: the S² base space
    ) -> ComputeResult<GenerateResponse> {
        // HOPF: CONSTITUTIONAL INVARIANT — Article 8: Pre-Validation Mandate
        // The projection map p: S³ → S² MUST be applied before any fiber execution.
        // This is the Shiab operator. It cannot be skipped.
        let action = ActionSpace::from_prompt(&req.prompt);
        validate_action_with_will_vector(&action, will_vector)
            .map_err(|e| ComputeError::new(ComputeErrorKind::ValidationBlocked, None, e.to_string()))?;

        let provider_chain = self.provider_chain_for_request(req.provider_override.as_deref());
        let mut attempts = Vec::new();

        for provider_id in &provider_chain {
            match self.provider(provider_id) {
                Some(provider) => {
                    let result = provider.generate_response(req.clone());
                    match result {
                        Ok(response) => return Ok(response),
                        Err(error) => {
                            attempts.push(AttemptedProviderError { provider_id: provider_id.clone(), error });
                        }
                    }
                }
                None => {
                    attempts.push(AttemptedProviderError {
                        provider_id: provider_id.clone(),
                        error: ComputeError::provider_not_registered(provider_id.clone()),
                    });
                }
            }
        }

        Err(ComputeError::new(
            ComputeErrorKind::ProviderUnavailable,
            None,
            RoutingFailure {
                requested_provider: self.resolve_provider_id(req.provider_override.as_deref()),
                attempts,
            }.to_string(),
        ))
    }

    pub fn route_embedding(&self, text: &str, provider_override: Option<&str>) -> ComputeResult<EmbeddingResponse> {
        let provider_id = self.resolve_provider_id(provider_override);
        let provider = self.provider(&provider_id).ok_or_else(|| ComputeError::provider_not_registered(provider_id))?;
        let embedding = provider.get_embedding(text)?;
        Ok(EmbeddingResponse { provider_id: provider.provider_id().to_string(), embedding })
    }

    pub async fn health_check_all(&self) -> Vec<ProviderHealth> {
        let mut health_checks = Vec::new();
        for provider in self.providers.values() {
            health_checks.push(provider.health_check());
        }
        // This part needs to be async to work correctly
        // futures::future::join_all(health_checks).await
        // For now, synchronously for simplicity
        health_checks.into_iter().map(|res| res.unwrap_or_else(|e| ProviderHealth::unhealthy(e.provider_id.unwrap_or_default(), ProviderKind::Cloud, Some(e.message)))).collect()
    }
}

fn normalize_provider_id(provider_id: impl Into<String>) -> Option<String> {
    let provider_id = provider_id.into().to_lowercase().trim().to_string();
    if provider_id.is_empty() {
        None
    } else {
        Some(provider_id)
    }
}

fn dedupe_provider_priority<I, S>(priority: I) -> Vec<String>
where
    I: IntoIterator<Item = S>,
    S: Into<String>,
{
    let mut seen = HashSet::new();
    let mut deduped = Vec::new();
    for provider_id in priority {
        if let Some(normalized) = normalize_provider_id(provider_id) {
            if !seen.contains(&normalized) {
                seen.insert(normalized.clone());
                deduped.push(normalized);
            }
        }
    }
    deduped
}

fn required_local_fallback_priority() -> Vec<String> {
    vec![PROVIDER_QWEN_LOCAL.to_string(), PROVIDER_OLLAMA.to_string()]
}

fn normalize_local_fallback_priority<I, S>(priority: I) -> Vec<String>
where
    I: IntoIterator<Item = S>,
    S: Into<String>,
{
    let mut final_priority = dedupe_provider_priority(priority);
    let mut seen: HashSet<_> = final_priority.iter().cloned().collect();

    for required in required_local_fallback_priority() {
        if !seen.contains(&required) {
            final_priority.push(required);
        }
    }

    final_priority
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::Mutex;

    #[derive(Default)]
    struct MockProvider {
        id: &'static str,
        kind: ProviderKind,
        healthy: bool,
        should_fail: bool,
        call_count: Mutex<usize>,
    }

    impl ComputeProvider for MockProvider {
        fn provider_id(&self) -> &'static str {
            self.id
        }

        fn kind(&self) -> ProviderKind {
            self.kind
        }

        fn health_check(&self) -> ComputeResult<ProviderHealth> {
            if self.healthy {
                Ok(ProviderHealth::healthy(self.id, self.kind, None))
            } else {
                Ok(ProviderHealth::unhealthy(self.id, self.kind, Some("unhealthy")))
            }
        }

        fn get_embedding(&self, _text: &str) -> ComputeResult<Vec<f64>> {
            Ok(vec![1.0, 2.0, 3.0])
        }

        fn generate_response(&self, req: GenerateRequest) -> ComputeResult<GenerateResponse> {
            *self.call_count.lock().unwrap() += 1;
            if self.should_fail {
                Err(ComputeError::internal(self.id, "mock failure"))
            } else {
                Ok(GenerateResponse {
                    provider_id: self.id.to_string(),
                    model: "mock-model".to_string(),
                    output_text: req.prompt,
                    finish_reason: None,
                    usage: None,
                    metadata: BTreeMap::new(),
                    latency_ms: 100,
                })
            }
        }
    }

    fn create_router() -> ComputeRouter {
        let mut router = ComputeRouter::new("mock_cloud_1");
        router.register_provider(Arc::new(MockProvider { id: "mock_cloud_1", kind: ProviderKind::Cloud, ..Default::default() }));
        router.register_provider(Arc::new(MockProvider { id: "mock_cloud_2", kind: ProviderKind::Cloud, ..Default::default() }));
        router.register_provider(Arc::new(MockProvider { id: "mock_local_1", kind: ProviderKind::Local, ..Default::default() }));
        router.register_provider(Arc::new(MockProvider { id: "mock_local_2", kind: ProviderKind::Local, ..Default::default() }));
        router
    }

    #[test]
    fn provider_chain_uses_global_default() {
        let router = create_router();
        let chain = router.provider_chain_for_request(None);
        assert_eq!(chain[0], "mock_cloud_1");
    }

    #[test]
    fn provider_chain_uses_override() {
        let router = create_router();
        let chain = router.provider_chain_for_request(Some("mock_local_1"));
        assert_eq!(chain[0], "mock_local_1");
    }

    #[test]
    fn provider_chain_falls_back_for_cloud() {
        let mut router = create_router();
        router.set_cloud_fallback_priority(vec!["mock_cloud_2"]);
        let chain = router.provider_chain_for_request(Some("mock_cloud_1"));
        assert_eq!(chain, vec!["mock_cloud_1", "mock_cloud_2", "qwen_local", "ollama"]);
    }

    #[test]
    fn provider_chain_falls_back_for_local() {
        let mut router = create_router();
        router.set_local_fallback_priority(vec!["mock_local_2"]);
        let chain = router.provider_chain_for_request(Some("mock_local_1"));
        assert_eq!(chain, vec!["mock_local_1", "mock_local_2", "qwen_local", "ollama"]);
    }
}