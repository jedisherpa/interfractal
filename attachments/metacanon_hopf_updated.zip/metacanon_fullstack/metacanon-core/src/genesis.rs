use serde::{Deserialize, Serialize};
use std::collections::HashMap;

// HOPF: Add ActionSpace and WillVector to prelude for other layers to use.

/// Represents a point in the Total Space (S³) — the 4D AI computational action space.
/// S³ is the unit quaternion group, so quaternion arithmetic is the natural representation.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct ActionSpace {
    /// Quaternion representation of the action in S³: [w, x, y, z]
    pub quaternion: [f32; 4],
    /// The prompt or action content being evaluated
    pub content: String,
    /// Optional metadata for routing and context
    pub metadata: std::collections::HashMap<String, String>,
}

// HOPF: Implement ActionSpace constructor.
impl ActionSpace {
    pub fn from_prompt(prompt: &str) -> Self {
        Self {
            quaternion: [1.0, 0.0, 0.0, 0.0], // Identity quaternion — neutral starting point
            content: prompt.to_string(),
            metadata: Default::default(),
        }
    }
}

/// The foundational data structure for a Metacanon sovereign identity.
/// It contains the user's WillVector, their cryptographic keys, and the Ratchet for managing permissions.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct SoulFile {
    pub version: String,
    pub sovereign_id: String,
    pub will_vector: WillVector,
    pub ratchet: Ratchet,
    pub created_at: u64,
    pub updated_at: u64,
}

// HOPF: Implement the Hopf Projection Map (validate_action) and a placeholder for action embedding derivation.
impl SoulFile {
    /// The Hopf Projection Map: p(S³) → S²
    /// Projects an action from the total space (S³) onto the base space (S²)
    /// using cosine similarity against the WillVector embedding.
    ///
    /// CONSTITUTIONAL INVARIANT — Article 8: Pre-Validation Mandate
    /// This function MUST return Ok(()) before any compute call is made.
    /// Threshold: cosine similarity ≥ 0.8
    pub fn validate_action(&self, action: &ActionSpace) -> Result<(), ValidationError> {
        if action.content.trim().is_empty() {
            return Err(ValidationError::EmptyPrompt);
        }

        // Derive a 384-dimensional projection of the action for comparison
        // In production: use the same embedding model that generated will_vector.embedding
        // For now: use a deterministic hash-based projection as a structural placeholder
        let action_embedding = self.derive_action_embedding(&action.content);
        let similarity = cosine_similarity(&self.will_vector.embedding, &action_embedding);

        if similarity >= 0.8 {
            Ok(())
        } else {
            Err(ValidationError::BlockedByWillVector(format!(
                "Action similarity {:.3} below threshold 0.8 — blocked by sovereign intent",
                similarity
            )))
        }
    }

    fn derive_action_embedding(&self, content: &str) -> [f32; 384] {
        // Placeholder: in production, call the active compute provider's get_embedding()
        // This must use the SAME embedding model as was used during Genesis Rite
        let mut embedding = [0.0f32; 384];
        let bytes = content.as_bytes();
        for (i, b) in bytes.iter().enumerate().take(384) {
            embedding[i % 384] += *b as f32 / 255.0;
        }
        embedding
    }
}

// HOPF: Upgrade WillVector to a 384-dimensional embedding.
/// The user's sovereign intent, represented as a 384-dimensional embedding.
/// This IS the Base Space (S²) of the Hopf Fibration.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct WillVector {
    /// 384-dimensional embedding of user's sovereign intent.
    /// This IS the Base Space (S²) of the Hopf Fibration.
    pub embedding: [f32; 384],
    /// Human-readable directives preserved for UI display only.
    pub directives: Vec<String>,
}

/// The Ratchet defines the rules for how the AI can operate.
/// It is an implementation of an inhomogeneous gauge group (H ⋉ N).
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct Ratchet {
    pub permissions: HashMap<String, Permission>,
    pub delegations: Vec<Delegation>,
}

/// A permission granted to the AI.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct Permission {
    pub resource: String,
    pub actions: Vec<String>,
    pub constraints: HashMap<String, String>,
}

/// A delegation of authority to another sovereign.
#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Default)]
pub struct Delegation {
    pub delegatee: String,
    pub permissions: Vec<String>,
    pub expires_at: Option<u64>,
}

// HOPF: Add ValidationError enum.
#[derive(Debug, thiserror::Error)]
pub enum ValidationError {
    #[error("Prompt cannot be empty.")]
    EmptyPrompt,
    #[error("Action blocked by WillVector: {0}")]
    BlockedByWillVector(String),
}

// HOPF: Add cosine_similarity function.
/// Computes the cosine similarity between two 384-dimensional vectors.
fn cosine_similarity(a: &[f32; 384], b: &[f32; 384]) -> f32 {
    let dot_product = a.iter().zip(b.iter()).map(|(x, y)| x * y).sum::<f32>();
    let norm_a = a.iter().map(|x| x.powi(2)).sum::<f32>().sqrt();
    let norm_b = b.iter().map(|x| x.powi(2)).sum::<f32>().sqrt();
    if norm_a == 0.0 || norm_b == 0.0 {
        0.0
    } else {
        dot_product / (norm_a * norm_b)
    }
}