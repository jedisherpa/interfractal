use aes_gcm::aead::{Aead, NewAead};
use aes_gcm::{Aes256Gcm, Key, Nonce};
use rand::rngs::OsRng;
use rand::RngCore;
use serde::{Deserialize, Serialize};
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

/// Errors that can occur during secret management.
#[derive(Debug, thiserror::Error)]
pub enum SecretError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
    #[error("Encryption/decryption error: {0}")]
    Encryption(String),
    #[error("Keychain error: {0}")]
    Keychain(String),
    #[error("Partial failure on {operation}: keychain_error={keychain_error:?}, file_error={file_error:?}")]
    PartialFailure {
        operation: &'static str,
        keychain_error: Option<String>,
        file_error: Option<String>,
    },
}

/// A generic backend for storing secrets (e.g., OS keychain).
pub trait KeychainBackend: Send + Sync {
    fn set_secret(&self, key: &str, value: &str) -> Result<(), SecretError>;
    fn get_secret(&self, key: &str) -> Result<Option<String>, SecretError>;
    fn delete_secret(&self, key: &str) -> Result<(), SecretError>;
}

/// Manages secrets, with support for both an encrypted file and a keychain backend.
pub struct SecretsManager {
    keychain: Option<Arc<dyn KeychainBackend>>,
    file_store: Option<Arc<EncryptedFileSecretStore>>,
}

impl SecretsManager {
    pub fn new(keychain: Arc<dyn KeychainBackend>, file_store: Arc<EncryptedFileSecretStore>) -> Self {
        Self { keychain: Some(keychain), file_store: Some(file_store) }
    }

    pub fn keychain_only(keychain: Arc<dyn KeychainBackend>) -> Self {
        Self { keychain: Some(keychain), file_store: None }
    }

    pub fn encrypted_file_only(file_store: Arc<EncryptedFileSecretStore>) -> Self {
        Self { keychain: None, file_store: Some(file_store) }
    }

    pub fn dual_write(keychain: Arc<dyn KeychainBackend>, file_store: Arc<EncryptedFileSecretStore>) -> Self {
        Self::new(keychain, file_store)
    }

    pub fn set_secret(&self, key: &str, value: &str) -> Result<(), SecretError> {
        let mut keychain_err = None;
        let mut file_err = None;

        if let Some(ref keychain) = self.keychain {
            if let Err(e) = keychain.set_secret(key, value) {
                keychain_err = Some(e.to_string());
            }
        }

        if let Some(ref file_store) = self.file_store {
            if let Err(e) = file_store.set_secret(key, value) {
                file_err = Some(e.to_string());
            }
        }

        if keychain_err.is_some() || file_err.is_some() {
            Err(SecretError::PartialFailure {
                operation: "set",
                keychain_error: keychain_err,
                file_error: file_err,
            })
        } else {
            Ok(())
        }
    }

    pub fn get_secret(&self, key: &str) -> Result<Option<String>, SecretError> {
        if let Some(ref keychain) = self.keychain {
            match keychain.get_secret(key) {
                Ok(Some(value)) => return Ok(Some(value)),
                Ok(None) => {}
                Err(e) => return Err(e),
            }
        }

        if let Some(ref file_store) = self.file_store {
            return file_store.get_secret(key);
        }

        Ok(None)
    }

    pub fn delete_secret(&self, key: &str) -> Result<(), SecretError> {
        let mut keychain_err = None;
        let mut file_err = None;

        if let Some(ref keychain) = self.keychain {
            if let Err(e) = keychain.delete_secret(key) {
                keychain_err = Some(e.to_string());
            }
        }

        if let Some(ref file_store) = self.file_store {
            if let Err(e) = file_store.delete_secret(key) {
                file_err = Some(e.to_string());
            }
        }

        if keychain_err.is_some() || file_err.is_some() {
            Err(SecretError::PartialFailure {
                operation: "delete",
                keychain_error: keychain_err,
                file_error: file_err,
            })
        } else {
            Ok(())
        }
    }
}

#[derive(Serialize, Deserialize, Default)]
struct SecretsData {
    secrets: HashMap<String, String>,
}

#[derive(Clone)]
pub struct EncryptedFileSecretStore {
    path: PathBuf,
    key: Vec<u8>,
}

impl EncryptedFileSecretStore {
    pub fn new(path: PathBuf, key: Vec<u8>) -> Result<Self, SecretError> {
        Ok(Self { path, key })
    }

    fn read_and_decrypt(&self) -> Result<SecretsData, SecretError> {
        if !self.path.exists() {
            return Ok(SecretsData::default());
        }
        let mut file = std::fs::File::open(&self.path)?;
        let mut buffer = Vec::new();
        std::io::Read::read_to_end(&mut file, &mut buffer)?;

        if buffer.len() < 12 {
            return Err(SecretError::Encryption("Invalid encrypted file format".to_string()));
        }
        let (nonce_bytes, ciphertext) = buffer.split_at(12);
        let nonce = Nonce::from_slice(nonce_bytes);
        let cipher = Aes256Gcm::new(Key::from_slice(&self.key));

        let decrypted = cipher.decrypt(nonce, ciphertext)
            .map_err(|e| SecretError::Encryption(e.to_string()))?;

        serde_json::from_slice(&decrypted).map_err(SecretError::from)
    }

    fn encrypt_and_write(&self, data: &SecretsData) -> Result<(), SecretError> {
        let serialized = serde_json::to_vec(data)?;
        let cipher = Aes256Gcm::new(Key::from_slice(&self.key));
        let mut nonce_bytes = [0u8; 12];
        OsRng.fill_bytes(&mut nonce_bytes);
        let nonce = Nonce::from_slice(&nonce_bytes);

        let ciphertext = cipher.encrypt(nonce, serialized.as_slice())
            .map_err(|e| SecretError::Encryption(e.to_string()))?;

        let mut file = std::fs::File::create(&self.path)?;
        std::io::Write::write_all(&mut file, &nonce_bytes)?;
        std::io::Write::write_all(&mut file, &ciphertext)?;
        Ok(())
    }

    pub fn set_secret(&self, key: &str, value: &str) -> Result<(), SecretError> {
        let mut data = self.read_and_decrypt()?;
        data.secrets.insert(key.to_string(), value.to_string());
        self.encrypt_and_write(&data)
    }

    pub fn get_secret(&self, key: &str) -> Result<Option<String>, SecretError> {
        let data = self.read_and_decrypt()?;
        Ok(data.secrets.get(key).cloned())
    }

    pub fn delete_secret(&self, key: &str) -> Result<(), SecretError> {
        let mut data = self.read_and_decrypt()?;
        if data.secrets.remove(key).is_some() {
            self.encrypt_and_write(&data)
        } else {
            Ok(())
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::sync::RwLock;

    #[derive(Default)]
    struct InMemoryKeychain {
        secrets: RwLock<HashMap<String, String>>,
    }

    impl InMemoryKeychain {
        fn new() -> Self {
            Self::default()
        }
    }

    impl KeychainBackend for InMemoryKeychain {
        fn set_secret(&self, key: &str, value: &str) -> Result<(), SecretError> {
            self.secrets.write().unwrap().insert(key.to_string(), value.to_string());
            Ok(())
        }

        fn get_secret(&self, key: &str) -> Result<Option<String>, SecretError> {
            Ok(self.secrets.read().unwrap().get(key).cloned())
        }

        fn delete_secret(&self, key: &str) -> Result<(), SecretError> {
            self.secrets.write().unwrap().remove(key);
            Ok(())
        }
    }

    struct FailingKeychain;

    impl KeychainBackend for FailingKeychain {
        fn set_secret(&self, _key: &str, _value: &str) -> Result<(), SecretError> {
            Err(SecretError::Keychain("write failed".to_string()))
        }
        fn get_secret(&self, _key: &str) -> Result<Option<String>, SecretError> {
            Err(SecretError::Keychain("read failed".to_string()))
        }
        fn delete_secret(&self, _key: &str) -> Result<(), SecretError> {
            Err(SecretError::Keychain("delete failed".to_string()))
        }
    }

    fn temp_secret_path(test_name: &str) -> PathBuf {
        let nonce = std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("system clock should be after unix epoch")
            .as_nanos();
        let mut path = std::env::temp_dir();
        path.push(format!("metacanon-secrets-{test_name}-{nonce}"));
        path.push("config.json.enc");
        path
    }

    #[test]
    fn keychain_only_mode_round_trip() {
        let keychain = Arc::new(InMemoryKeychain::new());
        let manager = SecretsManager::keychain_only(keychain.clone());
        manager
            .set_secret("openai_api_key", "sk-test")
            .expect("set should succeed");
        let loaded = manager
            .get_secret("openai_api_key")
            .expect("get should succeed");
        assert_eq!(loaded.as_deref(), Some("sk-test"));
        manager
            .delete_secret("openai_api_key")
            .expect("delete should succeed");
        let loaded = manager
            .get_secret("openai_api_key")
            .expect("get should succeed");
        assert_eq!(loaded, None);
    }

    #[test]
    fn encrypted_file_only_mode_persists_across_instances() {
        let path = temp_secret_path("file-only");
        let store = EncryptedFileSecretStore::new(path.clone(), b"file-secret-key".to_vec())
            .expect("store should initialize");
        let manager = SecretsManager::encrypted_file_only(store.clone());
        manager
            .set_secret("anthropic_api_key", "anth-test")
            .expect("set should succeed");
        let second_store = EncryptedFileSecretStore::new(path, b"file-secret-key".to_vec())
            .expect("second store should initialize");
        let second_manager = SecretsManager::encrypted_file_only(second_store);
        let loaded = second_manager
            .get_secret("anthropic_api_key")
            .expect("get should succeed");
        assert_eq!(loaded.as_deref(), Some("anth-test"));
    }

    #[test]
    fn dual_write_mode_writes_both_and_reads_file_fallback() {
        let path = temp_secret_path("dual-write");
        let keychain = Arc::new(InMemoryKeychain::new());
        let file_store = EncryptedFileSecretStore::new(path.clone(), b"dual-write-key".to_vec())
            .expect("file store should initialize");
        let manager = SecretsManager::dual_write(keychain.clone(), file_store.clone());
        manager
            .set_secret("moonshot_key", "moonshot-test")
            .expect("dual write should succeed");
        let keychain_value = keychain
            .get_secret("moonshot_key")
            .expect("keychain read should succeed");
        assert_eq!(keychain_value.as_deref(), Some("moonshot-test"));
        let file_value = file_store
            .get_secret("moonshot_key")
            .expect("file read should succeed");
        assert_eq!(file_value.as_deref(), Some("moonshot-test"));
        let empty_keychain = Arc::new(InMemoryKeychain::new());
        let fallback_manager = SecretsManager::dual_write(empty_keychain, file_store);
        let fallback_value = fallback_manager
            .get_secret("moonshot_key")
            .expect("fallback read should succeed");
        assert_eq!(fallback_value.as_deref(), Some("moonshot-test"));
    }

    #[test]
    fn dual_write_reports_partial_failure_if_keychain_fails() {
        let path = temp_secret_path("dual-partial");
        let keychain = Arc::new(FailingKeychain);
        let file_store = EncryptedFileSecretStore::new(path, b"dual-partial-key".to_vec())
            .expect("file store should initialize");
        let manager = SecretsManager::dual_write(keychain, file_store.clone());
        let error = manager
            .set_secret("grok_key", "grok-test")
            .expect_err("partial failure should be returned");
        match error {
            SecretError::PartialFailure {
                operation,
                keychain_error,
                file_error,
            } => {
                assert_eq!(operation, "set");
                assert!(keychain_error.is_some());
                assert!(file_error.is_none());
            }
            other => panic!("unexpected error variant: {other}"),
        }
        let file_value = file_store
            .get_secret("grok_key")
            .expect("file write should still succeed");
        assert_eq!(file_value.as_deref(), Some("grok-test"));
    }
}