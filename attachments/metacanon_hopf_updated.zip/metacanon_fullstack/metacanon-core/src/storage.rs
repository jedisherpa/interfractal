use crate::genesis::SoulFile;
use std::io::{Read, Write};
use std::path::{Path, PathBuf};

/// Errors that can occur during SoulFile storage operations.
#[derive(Debug, thiserror::Error)]
pub enum StorageError {
    #[error("I/O error: {0}")]
    Io(#[from] std::io::Error),
    #[error("Serialization error: {0}")]
    Serialization(#[from] serde_json::Error),
    #[error("Path is not valid UTF-8")]
    InvalidPath,
}

/// A trait for storing and retrieving SoulFiles.
pub trait SoulStorage {
    fn save(&self, soul_file: &SoulFile) -> Result<(), StorageError>;
    fn load(&self) -> Result<SoulFile, StorageError>;
}

/// A simple file-based implementation of SoulStorage.
pub struct FileSoulStorage {
    path: PathBuf,
}

impl FileSoulStorage {
    pub fn new(path: impl AsRef<Path>) -> Self {
        Self { path: path.as_ref().to_path_buf() }
    }
}

impl SoulStorage for FileSoulStorage {
    fn save(&self, soul_file: &SoulFile) -> Result<(), StorageError> {
        let mut file = std::fs::File::create(&self.path)?;
        let json = serde_json::to_string_pretty(soul_file)?;
        file.write_all(json.as_bytes())?;
        Ok(())
    }

    fn load(&self) -> Result<SoulFile, StorageError> {
        let mut file = std::fs::File::open(&self.path)?;
        let mut json = String::new();
        file.read_to_string(&mut json)?;
        let soul_file = serde_json::from_str(&json)?;
        Ok(soul_file)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::genesis::*;
    use std::collections::HashMap;

    fn temp_soul_file_path() -> PathBuf {
        let mut path = std::env::temp_dir();
        path.push(format!("soulfile-{}.json", uuid::Uuid::new_v4()));
        path
    }

    #[test]
    fn file_storage_round_trip() {
        let path = temp_soul_file_path();
        let storage = FileSoulStorage::new(&path);

        let soul_file = SoulFile {
            version: "1.0".to_string(),
            sovereign_id: "did:key:z6MkhaXg1fWp5v8aFfWp5v8aFfWp5v8aFfWp5v8a".to_string(),
            will_vector: WillVector {
                embedding: [0.0; 384],
                directives: vec!["Be excellent to each other".to_string()],
            },
            ratchet: Ratchet {
                permissions: HashMap::new(),
                delegations: Vec::new(),
            },
            created_at: 0,
            updated_at: 0,
        };

        storage.save(&soul_file).expect("Failed to save SoulFile");
        let loaded_soul_file = storage.load().expect("Failed to load SoulFile");

        assert_eq!(soul_file, loaded_soul_file);

        std::fs::remove_file(path).ok();
    }
}