use crate::action_validator::ActionValidator;
use crate::compute_router::ComputeRouter;
use crate::genesis::ActionSpace;
use crate::observability::ObservabilityLogger;
use crate::prelude::*;
use serde_json::json;

pub struct DeliberationTorus;

impl DeliberationTorus {
    pub fn new() -> Self {
        Self
    }

    pub fn deliberate(
        &self,
        compute_router: &ComputeRouter,
        request: DeliberationRequest,
        trace_id: &str,
        // HOPF: The validator now carries the sovereign's WillVector (S²).
        validator: &dyn ActionValidator,
        // HOPF: The logger is required for the immutable MerkleDAG audit trail.
        observability_logger: &ObservabilityLogger,
    ) -> Result<DeliberationResult, DeliberationError> {
        // HOPF: This is the Hopf Projection Map, p(S³) → S².
        // Every action is projected against the WillVector before compute.
        let action = ActionSpace::from_prompt(&request.prompt);
        let similarity = validator.validate_action(&action).map_err(|e| DeliberationError::ValidationBlocked(e.to_string()))?;

        // HOPF: The compute call is the Fiber (S¹) execution.
        let response = compute_router.route_generate(request)?;

        // HOPF: Log the successful deliberation to the MerkleDAG.
        observability_logger.record_dual_tier_event(
            "deliberation_complete",
            trace_id,
            None,
            Some(response.provider_id.clone()),
            json!({ "prompt": action.content, "response": response.content }),
            json!({ "status": "complete", "similarity_score": similarity }),
        )?;

        Ok(DeliberationResult {
            content: response.content,
            provider_id: response.provider_id,
        })
    }
}

#[derive(Debug)]
pub struct DeliberationRequest {
    pub prompt: String,
}

#[derive(Debug)]
pub struct DeliberationResult {
    pub content: String,
    pub provider_id: String,
}