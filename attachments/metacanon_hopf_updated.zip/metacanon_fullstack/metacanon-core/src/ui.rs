use std::collections::{BTreeMap, HashSet};
use std::path::{Path, PathBuf};
use std::process::Command;
use std::sync::{Arc, Mutex, MutexGuard};

use serde::{Deserialize, Serialize};
use serde_json::{json, Map, Value};

use crate::communications::{CommunicationError, CommunicationHub, CommunicationPlatform};
use crate::compute::{
    ComputeErrorKind, ComputeRouter, GenerateRequest, ProviderKind, PROVIDER_OLLAMA,
    PROVIDER_QWEN_LOCAL,
};
use crate::genesis::{
    AIBoundaries, Ratchet, SensitiveComputePolicy, SoulFacet, SoulFile, TaskSubSphere,
    TaskSubSphereStatus, WillVector,
};
use crate::lens_library::{LensLibraryEntry, LensLibraryState, LensLibraryTier};
use crate::providers::anthropic::{
    AnthropicConfig, AnthropicProvider, ANTHROPIC_DEFAULT_BASE_URL, ANTHROPIC_DEFAULT_MODEL,
    ANTHROPIC_PROVIDER_ID,
};
use crate::providers::grok::{
    GrokConfig, GrokProvider, GROK_DEFAULT_BASE_URL, GROK_DEFAULT_MODEL, GROK_PROVIDER_ID,
};
use crate::providers::moonshot_kimi::{
    MoonshotKimiConfig, MoonshotKimiProvider, MOONSHOT_KIMI_DEFAULT_BASE_URL,
    MOONSHOT_KIMI_DEFAULT_MODEL, MOONSHOT_KIMI_PROVIDER_ID,
};
use crate::providers::morpheus::{
    MorpheusConfig, MorpheusProvider, MORPHEUS_DEFAULT_ENDPOINT, MORPHEUS_DEFAULT_KEY_ID,
    MORPHEUS_DEFAULT_MODEL, MORPHEUS_DEFAULT_ROUTER_ID, MORPHEUS_PROVIDER_ID,
};
use crate::providers::ollama::{
    OllamaConfig, OllamaProvider, OLLAMA_DEFAULT_BASE_URL, OLLAMA_DEFAULT_MODEL,
};
use crate::providers::openai::{
    OpenAiConfig, OpenAiProvider, OPENAI_DEFAULT_BASE_URL, OPENAI_DEFAULT_CHAT_MODEL,
    OPENAI_DEFAULT_EMBEDDING_MODEL, OPENAI_PROVIDER_ID,
};
use crate::providers::qwen_local::{
    QwenLocalConfig, QwenLocalProvider, QWEN_DEFAULT_BASE_URL, QWEN_DEFAULT_DOWNGRADE_MODEL_ID,
    QWEN_DEFAULT_DOWNGRADE_PROFILE, QWEN_DEFAULT_LLAMACPP_BINARY, QWEN_DEFAULT_LOCAL_TARGET,
    QWEN_DEFAULT_PRIMARY_MODEL_ID, QWEN_DOWNGRADE_LOCAL_TARGET,
};
use crate::specialist_lens::{ActiveSpecialistLens, SpecialistLensDefinition};
use crate::storage::{read_snapshot_json, write_snapshot_json, SnapshotStorageError};
use crate::sub_sphere_torus::{DeliberationRecord, SubSphereQueryResult, SubSphereTorus};
use crate::task_sub_sphere::{
    TaskSubSphereRuntime, TaskSubSphereRuntimeError, TaskSubSphereSummary,
};
use crate::tool_registry::ToolRegistry;
use crate::torus::{DefaultActionValidator, DeliberationTorus, TorusConfig, TorusError};
use crate::workflow::{
    WorkflowDefinition, WorkflowError, WorkflowRegistry, WorkflowTrainingSession,
};

pub use crate::communications::{
    AgentBinding, AgentRoutingMode, CommunicationDispatchResult, CommunicationStatus,
    DiscordDeferredInteractionAck, DiscordGatewayCloseResult, DiscordGatewayEventResult,
    DiscordGatewayProbeResult, DiscordGatewayState, DiscordIntegrationConfig,
    DiscordInteractionCompletionResult, InAppThreadMessage, SubSpherePrismBinding,
    TelegramInboundRecord, TelegramIntegrationConfig, TelegramUpdatePullResult,
    TelegramWebhookConfigResult, TelegramWebhookResult, TypingIndicatorResult,
};

pub const OBSERVABILITY_RETENTION_DAYS: u32 = 90;
pub const UI_STATE_SNAPSHOT_SCHEMA_VERSION: u32 = 1;
pub const DEFAULT_OBSERVABILITY_LOG_LEVEL: &str = "info";
pub const DEFAULT_SECURITY_SNAPSHOT_PATH: &str = ".metacanon_ai/runtime_snapshot.json";
pub const DEFAULT_AGENT_GENESIS_ID: &str = "agent-genesis";
pub const DEFAULT_AGENT_SYNTHESIS_ID: &str = "agent-synthesis";
pub const DEFAULT_AGENT_AUDITOR_ID: &str = "agent-auditor";
pub const DEFAULT_PRISM_SUB_SPHERE_ID: &str = "meta-prism";

fn default_genesis_human_in_loop() -> bool {
    true
}

fn default_genesis_drift_prevention() -> String {
    "Constitutional guardrails remain active.".to_string()
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SystemCheckItem {
    pub check_id: String,
    pub label: String,
    pub status: String,
    pub detail: String,
    pub blocking: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SystemCheckReport {
    pub checks: Vec<SystemCheckItem>,
    pub has_blocking_failures: bool,
    pub warn_count: usize,
    pub fail_count: usize,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SecurityPersistenceSettings {
    pub snapshot_path: String,
    pub encryption_enabled: bool,
    pub passphrase_configured: bool,
    pub auto_save_enabled: bool,
    pub secret_backend_mode: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct LocalBootstrapStatus {
    pub model_root: String,
    pub model_root_exists: bool,
    pub qwen_model_hint_present: bool,
    pub ollama_installed: bool,
    pub ollama_reachable: bool,
    pub ollama_default_model_installed: bool,
    pub recommended_actions: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct LocalModelPackInstallResult {
    pub source_path: String,
    pub source_kind: String,
    pub model_root: String,
    pub installed_files: usize,
    pub notes: Vec<String>,
    pub bootstrap: LocalBootstrapStatus,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq, Default)]
pub struct GenesisMorpheusSettings {
    pub router_id: Option<String>,
    pub wallet_id: Option<String>,
    pub endpoint: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GenesisRiteRequest {
    pub vision_core: String,
    #[serde(default)]
    pub core_values: Vec<String>,
    #[serde(default)]
    pub soul_facets: Vec<SoulFacet>,
    #[serde(default = "default_genesis_human_in_loop")]
    pub human_in_loop: bool,
    #[serde(default)]
    pub interpretive_boundaries: Vec<String>,
    #[serde(default = "default_genesis_drift_prevention")]
    pub drift_prevention: String,
    #[serde(default)]
    pub enable_morpheus_compute: bool,
    #[serde(default)]
    pub morpheus: GenesisMorpheusSettings,
    #[serde(default)]
    pub will_directives: Vec<String>,
    pub signing_secret: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct GenesisRiteResult {
    pub genesis_hash: String,
    pub signature: String,
    pub created_at: i64,
    pub schema_version: u32,
    pub sensitive_compute_policy: SensitiveComputePolicy,
    pub soul_file: SoulFile,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct GuidedGenesisRequest {
    pub vision_core: String,
    #[serde(default)]
    pub core_values: Vec<String>,
    #[serde(default)]
    pub will_directives: Vec<String>,
    pub signing_secret: String,
    #[serde(default)]
    pub facet_vision: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ThreeAgentBootstrapRequest {
    pub orchestrator_agent_id: String,
    pub prism_agent_id: String,
    #[serde(default)]
    pub telegram_chat_id_genesis: Option<String>,
    #[serde(default)]
    pub telegram_chat_id_synthesis: Option<String>,
    #[serde(default)]
    pub telegram_chat_id_auditor: Option<String>,
    #[serde(default)]
    pub discord_thread_id_genesis: Option<String>,
    #[serde(default)]
    pub discord_thread_id_synthesis: Option<String>,
    #[serde(default)]
    pub discord_thread_id_auditor: Option<String>,
    #[serde(default)]
    pub prism_sub_sphere_id: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ThreeAgentBootstrapResult {
    pub agent_ids: Vec<String>,
    pub orchestrator_agent_id: String,
    pub prism_agent_id: String,
    pub prism_sub_sphere_id: String,
    pub communication: CommunicationStatus,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ComputeOption {
    pub provider_id: String,
    pub display_name: String,
    pub kind: String,
    pub implemented: bool,
    pub configured: bool,
    pub available: bool,
    pub selected_global: bool,
    pub default_if_skipped: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct SetupComputeSelectionResult {
    pub selected_provider_id: String,
    pub was_skipped: bool,
    pub auto_configured_qwen: bool,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct GlobalProviderSelection {
    pub provider_id: String,
    pub provider_chain_preview: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ProviderPriorityUpdateResult {
    pub cloud_provider_priority: Vec<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct DeliberationCommandResult {
    pub requested_provider_id: String,
    pub provider_override: Option<String>,
    pub provider_id: String,
    pub provider_chain: Vec<String>,
    pub used_fallback: bool,
    pub model: String,
    pub output_text: String,
    pub finish_reason: Option<String>,
    pub metadata: BTreeMap<String, String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ProviderAttemptError {
    pub provider_id: String,
    pub error_kind: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ProviderHealthStatus {
    pub provider_id: String,
    pub kind: String,
    pub implemented: bool,
    pub configured: bool,
    pub is_healthy: bool,
    pub detail: Option<String>,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq)]
pub struct ProviderConfigUpdateResult {
    pub provider_id: String,
    pub configured: bool,
    pub config: Value,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct ObservabilityStatus {
    pub retention_days: u32,
    #[serde(default = "default_observability_log_level")]
    pub log_level: String,
    pub full_tier_encrypted: bool,
    pub redacted_graph_feed_enabled: bool,
    pub full_event_log_path: String,
    pub redacted_graph_feed_path: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct InstallReviewIssue {
    pub severity: String,
    pub message: String,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct InstallReviewSummary {
    pub can_install: bool,
    pub global_provider_id: String,
    pub provider_chain: Vec<String>,
    pub selected_provider_ids: Vec<String>,
    pub issues: Vec<InstallReviewIssue>,
    pub observability: ObservabilityStatus,
    pub security: SecurityPersistenceSettings,
    pub system_check: SystemCheckReport,
}

#[derive(Debug, Clone, Serialize, Deserialize)]
struct UiStateSnapshot {
    schema_version: u32,
    global_provider_id: String,
    #[serde(default)]
    cloud_provider_priority: Vec<String>,
    #[serde(default)]
    provider_configs: BTreeMap<String, Value>,
    #[serde(default)]
    security_settings: SecurityPersistenceSettings,
    observability_status: ObservabilityStatus,
    #[serde(default)]
    sensitive_compute_policy: SensitiveComputePolicy,
    #[serde(default)]
    genesis_soul_file: Option<SoulFile>,
    #[serde(default)]
    task_sub_spheres: Vec<TaskSubSphere>,
    #[serde(default)]
    sub_sphere_torus: SubSphereTorus,
    #[serde(default)]
    lens_library: LensLibraryState,
    #[serde(default)]
    tool_registry: ToolRegistry,
    #[serde(default)]
    workflow_registry: WorkflowRegistry,
    #[serde(default)]
    communications: CommunicationHub,
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
pub struct RuntimeSnapshotResult {
    pub path: String,
    pub schema_version: u32,
    pub task_sub_sphere_count: usize,
    pub workflow_count: usize,
}

impl Default for ObservabilityStatus {
    fn default() -> Self {
        Self {
            retention_days: OBSERVABILITY_RETENTION_DAYS,
            log_level: DEFAULT_OBSERVABILITY_LOG_LEVEL.to_string(),
            full_tier_encrypted: true,
            redacted_graph_feed_enabled: true,
            full_event_log_path: "app_log_dir()/metacanon_ai/full-events.log.enc".to_string(),
            redacted_graph_feed_path: "app_log_dir()/metacanon_ai/redacted-graph.ndjson"
                .to_string(),
        }
    }
}

impl Default for SecurityPersistenceSettings {
    fn default() -> Self {
        Self {
            snapshot_path: DEFAULT_SECURITY_SNAPSHOT_PATH.to_string(),
            encryption_enabled: false,
            passphrase_configured: false,
            auto_save_enabled: true,
            secret_backend_mode: "dual_write".to_string(),
        }
    }
}

#[derive(Debug, Clone, Serialize, Deserialize, PartialEq, Eq)]
#[serde(tag = "code", rename_all = "snake_case")]
pub enum UiCommandError {
    InvalidGenesisRite {
        message: String,
    },
    InvalidProviderId {
        provider_id: String,
    },
    EmptyQuery,
    InvalidSnapshotPath,
    InvalidProviderConfig {
        provider_id: String,
        message: String,
    },
    InvalidSecuritySettings {
        message: String,
    },
    InvalidObservabilitySettings {
        message: String,
    },
    InvalidCommunicationSettings {
        message: String,
    },
    LocalBootstrap {
        message: String,
    },
    DeliberationFailed {
        requested_provider: String,
        attempts: Vec<ProviderAttemptError>,
    },
    ConstitutionalViolation {
        message: String,
    },
    Communication {
        message: String,
    },
    TaskSubSphereRuntime {
        message: String,
    },
    WorkflowRuntime {
        message: String,
    },
    Storage {
        message: String,
    },
    StatePoisoned,
}

impl std::fmt::Display for UiCommandError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        match self {
            UiCommandError::InvalidGenesisRite { message } => {
                write!(f, "invalid genesis rite request: {message}")
            }
            UiCommandError::InvalidProviderId { provider_id } => {
                write!(f, "provider '{provider_id}' is not supported")
            }
            UiCommandError::EmptyQuery => f.write_str("query must not be empty"),
            UiCommandError::InvalidSnapshotPath => f.write_str("snapshot path must not be empty"),
            UiCommandError::InvalidProviderConfig {
                provider_id,
                message,
            } => write!(f, "invalid config for '{provider_id}': {message}"),
            UiCommandError::InvalidSecuritySettings { message } => {
                write!(f, "invalid security settings: {message}")
            }
            UiCommandError::InvalidObservabilitySettings { message } => {
                write!(f, "invalid observability settings: {message}")
            }
            UiCommandError::InvalidCommunicationSettings { message } => {
                write!(f, "invalid communication settings: {message}")
            }
            UiCommandError::LocalBootstrap { message } => {
                write!(f, "local bootstrap error: {message}")
            }
            UiCommandError::DeliberationFailed {
                requested_provider,
                attempts,
            } => write!(
                f,
                "deliberation failed for provider '{requested_provider}' after {} attempt(s)",
                attempts.len()
            ),
            UiCommandError::ConstitutionalViolation { message } => {
                write!(f, "constitutional guardrail violation: {message}")
            }
            UiCommandError::Communication { message } => {
                write!(f, "communication runtime error: {message}")
            }
            UiCommandError::TaskSubSphereRuntime { message } => {
                write!(f, "task sub-sphere runtime error: {message}")
            }
            UiCommandError::WorkflowRuntime { message } => {
                write!(f, "workflow runtime error: {message}")
            }
            UiCommandError::Storage { message } => {
                write!(f, "storage error: {message}")
            }
            UiCommandError::StatePoisoned => f.write_str("ui command runtime is unavailable"),
        }
    }
}

impl std::error::Error for UiCommandError {}

impl From<TaskSubSphereRuntimeError> for UiCommandError {
    fn from(value: TaskSubSphereRuntimeError) -> Self {
        Self::TaskSubSphereRuntime {
            message: value.to_string(),
        }
    }
}

impl From<WorkflowError> for UiCommandError {
    fn from(value: WorkflowError) -> Self {
        Self::WorkflowRuntime {
            message: value.to_string(),
        }
    }
}

impl From<SnapshotStorageError> for UiCommandError {
    fn from(value: SnapshotStorageError) -> Self {
        Self::Storage {
            message: value.to_string(),
        }
    }
}

impl From<CommunicationError> for UiCommandError {
    fn from(value: CommunicationError) -> Self {
        Self::Communication {
            message: value.to_string(),
        }
    }
}

#[derive(Debug, Clone, Copy)]
struct ProviderDescriptor {
    id: &'static str,
    display_name: &'static str,
    kind: ProviderKind,
    implemented: bool,
    default_if_skipped: bool,
}

const PROVIDER_DESCRIPTORS: [ProviderDescriptor; 7] = [
    ProviderDescriptor {
        id: PROVIDER_QWEN_LOCAL,
        display_name: "Qwen Local (3.5 32B)",
        kind: ProviderKind::Local,
        implemented: true,
        default_if_skipped: true,
    },
    ProviderDescriptor {
        id: PROVIDER_OLLAMA,
        display_name: "Ollama Local",
        kind: ProviderKind::Local,
        implemented: true,
        default_if_skipped: false,
    },
    ProviderDescriptor {
        id: MORPHEUS_PROVIDER_ID,
        display_name: "Morpheus",
        kind: ProviderKind::Decentralized,
        implemented: true,
        default_if_skipped: false,
    },
    ProviderDescriptor {
        id: OPENAI_PROVIDER_ID,
        display_name: "OpenAI",
        kind: ProviderKind::Cloud,
        implemented: true,
        default_if_skipped: false,
    },
    ProviderDescriptor {
        id: ANTHROPIC_PROVIDER_ID,
        display_name: "Anthropic",
        kind: ProviderKind::Cloud,
        implemented: true,
        default_if_skipped: false,
    },
    ProviderDescriptor {
        id: MOONSHOT_KIMI_PROVIDER_ID,
        display_name: "Moonshot Kimi",
        kind: ProviderKind::Cloud,
        implemented: true,
        default_if_skipped: false,
    },
    ProviderDescriptor {
        id: GROK_PROVIDER_ID,
        display_name: "Grok (xAI)",
        kind: ProviderKind::Cloud,
        implemented: true,
        default_if_skipped: false,
    },
];

pub struct UiCommandRuntime {
    state: Mutex<UiState>,
    auto_snapshot_path: Mutex<Option<PathBuf>>,
}

impl Default for UiCommandRuntime {
    fn default() -> Self {
        Self::new()
    }
}

impl UiCommandRuntime {
    pub fn new() -> Self {
        Self {
            state: Mutex::new(UiState::new()),
            auto_snapshot_path: Mutex::new(None),
        }
    }

    pub fn new_with_auto_snapshot(path: String) -> Result<Self, UiCommandError> {
        let normalized_path = normalize_snapshot_path(&path)?;
        let path_buf = PathBuf::from(normalized_path.clone());

        let mut state = UiState::new();
        if path_buf.is_file() {
            let snapshot: UiStateSnapshot = read_snapshot_json(&path_buf)?;
            state.apply_snapshot(snapshot)?;
        }
        state.security_settings.snapshot_path = normalized_path.clone();
        state.security_settings.auto_save_enabled = true;

        Ok(Self {
            state: Mutex::new(state),
            auto_snapshot_path: Mutex::new(Some(path_buf)),
        })
    }

    fn lock_state(&self) -> Result<MutexGuard<'_, UiState>, UiCommandError> {
        self.state.lock().map_err(|_| UiCommandError::StatePoisoned)
    }

    fn lock_auto_snapshot_path(&self) -> Result<MutexGuard<'_, Option<PathBuf>>, UiCommandError> {
        self.auto_snapshot_path
            .lock()
            .map_err(|_| UiCommandError::StatePoisoned)
    }

    fn auto_snapshot_path_string(&self) -> Result<Option<String>, UiCommandError> {
        let guard = self.lock_auto_snapshot_path()?;
        Ok(guard
            .as_ref()
            .map(|path| path.to_string_lossy().into_owned()))
    }

    fn set_auto_snapshot_path_internal(&self, path: Option<PathBuf>) -> Result<(), UiCommandError> {
        let mut guard = self.lock_auto_snapshot_path()?;
        *guard = path;
        Ok(())
    }

    fn auto_save_snapshot_best_effort(&self) {
        let path = match self.auto_snapshot_path.lock() {
            Ok(guard) => guard.clone(),
            Err(_) => None,
        };
        let Some(path) = path else {
            return;
        };

        let snapshot = match self.state.lock() {
            Ok(state) => state.to_snapshot(),
            Err(_) => return,
        };

        let _ = write_snapshot_json(path, &snapshot);
    }
}

impl Drop for UiCommandRuntime {
    fn drop(&mut self) {
        self.auto_save_snapshot_best_effort();
    }
}

struct UiState {
    global_provider_id: String,
    cloud_provider_priority: Vec<String>,
    provider_configs: BTreeMap<String, Value>,
    security_settings: SecurityPersistenceSettings,
    observability_status: ObservabilityStatus,
    sensitive_compute_policy: SensitiveComputePolicy,
    genesis_soul_file: Option<SoulFile>,
    compute_router: ComputeRouter,
    task_sub_sphere_runtime: TaskSubSphereRuntime,
    sub_sphere_torus: SubSphereTorus,
    lens_library: LensLibraryState,
    tool_registry: ToolRegistry,
    workflow_registry: WorkflowRegistry,
    communications: CommunicationHub,
}

impl UiState {
    fn new() -> Self {
        let mut state = Self {
            global_provider_id: PROVIDER_QWEN_LOCAL.to_string(),
            cloud_provider_priority: default_cloud_provider_priority(),
            provider_configs: default_provider_configs(),
            security_settings: SecurityPersistenceSettings::default(),
            observability_status: ObservabilityStatus::default(),
            sensitive_compute_policy: SensitiveComputePolicy::UserChoice,
            genesis_soul_file: None,
            compute_router: ComputeRouter::new(PROVIDER_QWEN_LOCAL),
            task_sub_sphere_runtime: TaskSubSphereRuntime::new(Vec::new()),
            sub_sphere_torus: SubSphereTorus::new(),
            lens_library: LensLibraryState::new(),
            tool_registry: ToolRegistry::new(),
            workflow_registry: WorkflowRegistry::new(),
            communications: CommunicationHub::new(),
        };
        state
            .rebuild_compute_router()
            .expect("default UI state configuration should always be valid");
        state
    }

    fn to_snapshot(&self) -> UiStateSnapshot {
        UiStateSnapshot {
            schema_version: UI_STATE_SNAPSHOT_SCHEMA_VERSION,
            global_provider_id: self.global_provider_id.clone(),
            cloud_provider_priority: self.cloud_provider_priority.clone(),
            provider_configs: self.provider_configs.clone(),
            security_settings: self.security_settings.clone(),
            observability_status: self.observability_status.clone(),
            sensitive_compute_policy: self.sensitive_compute_policy.clone(),
            genesis_soul_file: self.genesis_soul_file.clone(),
            task_sub_spheres: self.task_sub_sphere_runtime.sub_spheres.clone(),
            sub_sphere_torus: self.sub_sphere_torus.clone(),
            lens_library: self.lens_library.clone(),
            tool_registry: self.tool_registry.clone(),
            workflow_registry: self.workflow_registry.clone(),
            communications: self.communications.clone_without_secrets(),
        }
    }

    fn apply_snapshot(&mut self, snapshot: UiStateSnapshot) -> Result<(), UiCommandError> {
        let global_provider_id = normalize_provider_id(&snapshot.global_provider_id)
            .unwrap_or_else(|| PROVIDER_QWEN_LOCAL.to_string());
        ensure_known_provider(&global_provider_id)?;

        let mut normalized_cloud_priority = Vec::new();
        let mut seen = HashSet::new();
        for provider_id in snapshot.cloud_provider_priority {
            let Some(provider_id) = normalize_provider_id(&provider_id) else {
                continue;
            };
            ensure_known_provider(&provider_id)?;
            if provider_id == PROVIDER_QWEN_LOCAL || provider_id == PROVIDER_OLLAMA {
                continue;
            }
            if seen.insert(provider_id.clone()) {
                normalized_cloud_priority.push(provider_id);
            }
        }
        if normalized_cloud_priority.is_empty() {
            normalized_cloud_priority = default_cloud_provider_priority();
        }

        let mut merged_provider_configs = default_provider_configs();
        for (provider_id, config) in snapshot.provider_configs {
            let Some(provider_id) = normalize_provider_id(&provider_id) else {
                continue;
            };
            ensure_known_provider(&provider_id)?;
            merged_provider_configs.insert(provider_id, config);
        }

        self.global_provider_id = global_provider_id;
        self.cloud_provider_priority = normalized_cloud_priority;
        self.provider_configs = merged_provider_configs;
        self.security_settings = snapshot.security_settings;
        self.observability_status = snapshot.observability_status;
        self.sensitive_compute_policy = snapshot.sensitive_compute_policy;
        self.genesis_soul_file = snapshot.genesis_soul_file;
        self.task_sub_sphere_runtime = TaskSubSphereRuntime::new(snapshot.task_sub_spheres);
        self.sub_sphere_torus = snapshot.sub_sphere_torus;
        self.lens_library = snapshot.lens_library;
        self.tool_registry = snapshot.tool_registry;
        self.workflow_registry = snapshot.workflow_registry;
        let mut communications = snapshot.communications;
        if communications.telegram.bot_token.is_none() {
            communications.telegram.bot_token = self.communications.telegram.bot_token.clone();
        }
        if communications.discord.bot_token.is_none() {
            communications.discord.bot_token = self.communications.discord.bot_token.clone();
        }
        self.communications = communications;

        self.rebuild_compute_router()
    }

    fn set_global_provider(&mut self, provider_id: &str) {
        self.global_provider_id = provider_id.to_string();
        self.compute_router
            .set_global_default_provider(provider_id.to_string());
    }

    fn compute_options(&self) -> Vec<ComputeOption> {
        PROVIDER_DESCRIPTORS
            .iter()
            .map(|descriptor| ComputeOption {
                provider_id: descriptor.id.to_string(),
                display_name: descriptor.display_name.to_string(),
                kind: provider_kind_label(descriptor.kind).to_string(),
                implemented: descriptor.implemented,
                configured: self.provider_is_configured(descriptor.id),
                available: self.provider_is_available(descriptor.id),
                selected_global: descriptor.id == self.global_provider_id,
                default_if_skipped: descriptor.default_if_skipped,
            })
            .collect()
    }

    fn provider_is_configured(&self, provider_id: &str) -> bool {
        let Some(config) = self.provider_configs.get(provider_id) else {
            return false;
        };

        match provider_id {
            PROVIDER_QWEN_LOCAL | PROVIDER_OLLAMA => true,
            OPENAI_PROVIDER_ID
            | ANTHROPIC_PROVIDER_ID
            | MOONSHOT_KIMI_PROVIDER_ID
            | GROK_PROVIDER_ID => config_has_non_empty_string(config, "api_key"),
            MORPHEUS_PROVIDER_ID => config_object_has_non_empty_values(config),
            _ => false,
        }
    }

    fn provider_is_available(&self, provider_id: &str) -> bool {
        let Some(descriptor) = provider_descriptor(provider_id) else {
            return false;
        };

        if !descriptor.implemented {
            return false;
        }

        self.provider_configs
            .get(provider_id)
            .and_then(|config| config.get("available"))
            .and_then(Value::as_bool)
            .unwrap_or(true)
    }

    fn rebuild_compute_router(&mut self) -> Result<(), UiCommandError> {
        let mut router = ComputeRouter::new(self.global_provider_id.clone());
        router.set_cloud_fallback_priority(self.cloud_provider_priority.clone());

        let qwen_config = qwen_config_from_value(self.provider_configs.get(PROVIDER_QWEN_LOCAL))?;
        router.register_provider(Arc::new(QwenLocalProvider::new(qwen_config)));

        let ollama_config = ollama_config_from_value(self.provider_configs.get(PROVIDER_OLLAMA))?;
        router.register_provider(Arc::new(OllamaProvider::new(ollama_config)));

        let morpheus_config =
            morpheus_config_from_value(self.provider_configs.get(MORPHEUS_PROVIDER_ID))?;
        let morpheus_provider =
            MorpheusProvider::from_local_keypair(morpheus_config).map_err(|error| {
                UiCommandError::InvalidProviderConfig {
                    provider_id: MORPHEUS_PROVIDER_ID.to_string(),
                    message: format!(
                        "failed to initialize morpheus provider from config: {}",
                        error.message
                    ),
                }
            })?;
        router.register_provider(Arc::new(morpheus_provider));

        let openai_config =
            openai_config_from_value(self.provider_configs.get(OPENAI_PROVIDER_ID))?;
        router.register_provider(Arc::new(OpenAiProvider::new(openai_config)));

        let anthropic_config =
            anthropic_config_from_value(self.provider_configs.get(ANTHROPIC_PROVIDER_ID))?;
        router.register_provider(Arc::new(AnthropicProvider::new(anthropic_config)));

        let moonshot_config =
            moonshot_kimi_config_from_value(self.provider_configs.get(MOONSHOT_KIMI_PROVIDER_ID))?;
        router.register_provider(Arc::new(MoonshotKimiProvider::new(moonshot_config)));

        let grok_config = grok_config_from_value(self.provider_configs.get(GROK_PROVIDER_ID))?;
        router.register_provider(Arc::new(GrokProvider::new(grok_config)));

        self.compute_router = router;
        Ok(())
    }
}

#[derive(Debug, Clone)]
struct SystemCheckContext {
    os: String,
    arch: String,
    ram_gb: Option<u64>,
    free_disk_gb: Option<u64>,
    model_dir_exists: bool,
    network_available: bool,
}

fn gather_system_check_context(_state: &UiState) -> SystemCheckContext {
    let home = std::env::var("HOME").ok();
    let model_dir_exists = home
        .as_deref()
        .map(PathBuf::from)
        .map(|path| path.join(".metacanon_ai/models"))
        .is_some_and(|path| path.is_dir());

    SystemCheckContext {
        os: std::env::consts::OS.to_string(),
        arch: std::env::consts::ARCH.to_string(),
        ram_gb: detect_total_ram_gb(),
        free_disk_gb: std::env::var("METACANON_FREE_DISK_GB")
            .ok()
            .and_then(|value| value.trim().parse::<u64>().ok()),
        model_dir_exists,
        network_available: !env_flag_enabled("METACANON_OFFLINE_MODE"),
    }
}

fn build_system_check_report(context: &SystemCheckContext) -> SystemCheckReport {
    let mut checks = Vec::new();
    let mut push_check =
        |check_id: &str, label: &str, status: &str, detail: String, blocking: bool| {
            checks.push(SystemCheckItem {
                check_id: check_id.to_string(),
                label: label.to_string(),
                status: status.to_string(),
                detail,
                blocking,
            });
        };

    let os_supported = matches!(context.os.as_str(), "macos" | "linux" | "windows");
    if os_supported {
        push_check(
            "os",
            "Operating System",
            "pass",
            format!("{} is supported.", context.os),
            false,
        );
    } else {
        push_check(
            "os",
            "Operating System",
            "fail",
            format!("{} is not currently supported.", context.os),
            true,
        );
    }

    let arch_supported = matches!(context.arch.as_str(), "aarch64" | "x86_64");
    if arch_supported {
        push_check(
            "cpu_arch",
            "CPU Architecture",
            "pass",
            format!("{} is supported.", context.arch),
            false,
        );
    } else {
        push_check(
            "cpu_arch",
            "CPU Architecture",
            "fail",
            format!(
                "{} is unsupported for local Qwen 32B defaults.",
                context.arch
            ),
            true,
        );
    }

    match context.ram_gb {
        Some(ram_gb) if ram_gb >= 64 => push_check(
            "ram",
            "System Memory",
            "pass",
            format!("{ram_gb} GB detected (>= 64 GB minimum for local 32B target)."),
            false,
        ),
        Some(ram_gb) if ram_gb >= 32 => push_check(
            "ram",
            "System Memory",
            "warn",
            format!("{ram_gb} GB detected; local 32B models may require downgrade profile."),
            false,
        ),
        Some(ram_gb) => push_check(
            "ram",
            "System Memory",
            "fail",
            format!("{ram_gb} GB detected; at least 32 GB is required."),
            true,
        ),
        None => push_check(
            "ram",
            "System Memory",
            "warn",
            "Unable to detect total RAM automatically.".to_string(),
            false,
        ),
    }

    match context.free_disk_gb {
        Some(free_disk) if free_disk >= 120 => push_check(
            "disk",
            "Free Disk Space",
            "pass",
            format!("{free_disk} GB free disk detected."),
            false,
        ),
        Some(free_disk) if free_disk >= 40 => push_check(
            "disk",
            "Free Disk Space",
            "warn",
            format!(
                "{free_disk} GB free disk detected; additional model downloads may be constrained."
            ),
            false,
        ),
        Some(free_disk) => push_check(
            "disk",
            "Free Disk Space",
            "fail",
            format!("{free_disk} GB free disk detected; at least 40 GB is required."),
            true,
        ),
        None => push_check(
            "disk",
            "Free Disk Space",
            "warn",
            "Free disk could not be detected in this runtime.".to_string(),
            false,
        ),
    }

    if context.model_dir_exists {
        push_check(
            "model_dir",
            "Model Directory",
            "pass",
            "Local model directory exists.".to_string(),
            false,
        );
    } else {
        push_check(
            "model_dir",
            "Model Directory",
            "warn",
            "Local model directory not found; it will be created during setup.".to_string(),
            false,
        );
    }

    if context.network_available {
        push_check(
            "network",
            "Network",
            "pass",
            "Network appears available for cloud provider setup.".to_string(),
            false,
        );
    } else {
        push_check(
            "network",
            "Network",
            "warn",
            "Offline mode enabled; cloud provider tests may fail.".to_string(),
            false,
        );
    }

    let warn_count = checks.iter().filter(|check| check.status == "warn").count();
    let fail_count = checks.iter().filter(|check| check.status == "fail").count();
    let has_blocking_failures = checks
        .iter()
        .any(|check| check.status == "fail" && check.blocking);

    SystemCheckReport {
        checks,
        has_blocking_failures,
        warn_count,
        fail_count,
    }
}

fn detect_total_ram_gb() -> Option<u64> {
    if let Ok(value) = std::env::var("METACANON_SYSTEM_RAM_GB") {
        if let Ok(parsed) = value.trim().parse::<u64>() {
            return Some(parsed);
        }
    }

    if std::env::consts::OS == "macos" {
        let output = Command::new("sysctl")
            .arg("-n")
            .arg("hw.memsize")
            .output()
            .ok()?;
        if !output.status.success() {
            return None;
        }
        let raw = String::from_utf8_lossy(&output.stdout);
        let bytes = raw.trim().parse::<u64>().ok()?;
        return Some(bytes / 1024 / 1024 / 1024);
    }

    None
}

fn env_flag_enabled(key: &str) -> bool {
    std::env::var(key)
        .ok()
        .map(|value| value.trim().to_ascii_lowercase())
        .is_some_and(|value| matches!(value.as_str(), "1" | "true" | "yes" | "on"))
}

fn default_cloud_provider_priority() -> Vec<String> {
    vec![
        OPENAI_PROVIDER_ID.to_string(),
        ANTHROPIC_PROVIDER_ID.to_string(),
        MOONSHOT_KIMI_PROVIDER_ID.to_string(),
        GROK_PROVIDER_ID.to_string(),
    ]
}

fn default_observability_log_level() -> String {
    DEFAULT_OBSERVABILITY_LOG_LEVEL.to_string()
}

fn default_provider_configs() -> BTreeMap<String, Value> {
    let mut configs = BTreeMap::new();
    configs.insert(PROVIDER_QWEN_LOCAL.to_string(), default_qwen_config_value());
    configs.insert(PROVIDER_OLLAMA.to_string(), default_ollama_config_value());
    configs.insert(
        OPENAI_PROVIDER_ID.to_string(),
        default_openai_config_value(),
    );
    configs.insert(
        ANTHROPIC_PROVIDER_ID.to_string(),
        default_anthropic_config_value(),
    );
    configs.insert(
        MOONSHOT_KIMI_PROVIDER_ID.to_string(),
        default_moonshot_kimi_config_value(),
    );
    configs.insert(
        MORPHEUS_PROVIDER_ID.to_string(),
        default_morpheus_config_value(),
    );
    configs.insert(GROK_PROVIDER_ID.to_string(), default_grok_config_value());
    configs
}

fn default_qwen_config_value() -> Value {
    json!({
        "primary_target": QWEN_DEFAULT_LOCAL_TARGET,
        "downgrade_profile": QWEN_DEFAULT_DOWNGRADE_PROFILE,
        "downgrade_target": QWEN_DOWNGRADE_LOCAL_TARGET,
        "runtime_backend": "llama.cpp",
        "base_url": QWEN_DEFAULT_BASE_URL,
        "primary_model_id": QWEN_DEFAULT_PRIMARY_MODEL_ID,
        "downgrade_model_id": QWEN_DEFAULT_DOWNGRADE_MODEL_ID,
        "llama_cpp_binary": QWEN_DEFAULT_LLAMACPP_BINARY,
        "llama_cpp_model_path": "",
        "live_api": false,
        "available": true
    })
}

fn default_ollama_config_value() -> Value {
    json!({
        "base_url": OLLAMA_DEFAULT_BASE_URL,
        "default_model": OLLAMA_DEFAULT_MODEL,
        "installed_models": [OLLAMA_DEFAULT_MODEL],
        "live_api": false,
        "available": true
    })
}

fn default_openai_config_value() -> Value {
    json!({
        "api_key": Value::Null,
        "base_url": OPENAI_DEFAULT_BASE_URL,
        "chat_model": OPENAI_DEFAULT_CHAT_MODEL,
        "embedding_model": OPENAI_DEFAULT_EMBEDDING_MODEL,
        "live_api": false,
        "available": true
    })
}

fn default_anthropic_config_value() -> Value {
    json!({
        "api_key": Value::Null,
        "base_url": ANTHROPIC_DEFAULT_BASE_URL,
        "model": ANTHROPIC_DEFAULT_MODEL,
        "live_api": false,
        "available": true
    })
}

fn default_moonshot_kimi_config_value() -> Value {
    json!({
        "api_key": Value::Null,
        "base_url": MOONSHOT_KIMI_DEFAULT_BASE_URL,
        "model": MOONSHOT_KIMI_DEFAULT_MODEL,
        "live_api": false,
        "available": true
    })
}

fn default_morpheus_config_value() -> Value {
    json!({
        "router_id": MORPHEUS_DEFAULT_ROUTER_ID,
        "endpoint": MORPHEUS_DEFAULT_ENDPOINT,
        "model": MORPHEUS_DEFAULT_MODEL,
        "key_id": MORPHEUS_DEFAULT_KEY_ID,
        "available": true
    })
}

fn default_grok_config_value() -> Value {
    json!({
        "api_key": Value::Null,
        "base_url": GROK_DEFAULT_BASE_URL,
        "model": GROK_DEFAULT_MODEL,
        "live_api": false,
        "available": true
    })
}

fn provider_descriptor(provider_id: &str) -> Option<ProviderDescriptor> {
    PROVIDER_DESCRIPTORS
        .iter()
        .find(|descriptor| descriptor.id == provider_id)
        .copied()
}

fn ensure_known_provider(provider_id: &str) -> Result<(), UiCommandError> {
    if provider_descriptor(provider_id).is_some() {
        Ok(())
    } else {
        Err(UiCommandError::InvalidProviderId {
            provider_id: provider_id.to_string(),
        })
    }
}

fn provider_kind_label(kind: ProviderKind) -> &'static str {
    match kind {
        ProviderKind::Local => "local",
        ProviderKind::Cloud => "cloud",
        ProviderKind::Decentralized => "decentralized",
    }
}

fn compute_error_kind_label(kind: &ComputeErrorKind) -> &'static str {
    match kind {
        ComputeErrorKind::ProviderUnavailable => "provider_unavailable",
        ComputeErrorKind::ProviderNotRegistered => "provider_not_registered",
        ComputeErrorKind::InvalidRequest => "invalid_request",
        ComputeErrorKind::Unsupported => "unsupported",
        ComputeErrorKind::Timeout => "timeout",
        ComputeErrorKind::Internal => "internal",
    }
}

fn normalize_provider_id(provider_id: &str) -> Option<String> {
    let trimmed = provider_id.trim();
    if trimmed.is_empty() {
        return None;
    }
    Some(trimmed.to_ascii_lowercase())
}

fn normalize_log_level(log_level: &str) -> Result<String, UiCommandError> {
    let normalized = log_level.trim().to_ascii_lowercase();
    if normalized.is_empty() {
        return Err(UiCommandError::InvalidObservabilitySettings {
            message: "log_level must not be empty".to_string(),
        });
    }

    match normalized.as_str() {
        "error" | "warn" | "info" | "debug" | "trace" => Ok(normalized),
        _ => Err(UiCommandError::InvalidObservabilitySettings {
            message: format!(
                "log_level '{}' is invalid; expected one of error|warn|info|debug|trace",
                log_level.trim()
            ),
        }),
    }
}

fn normalize_secret_backend_mode(mode: &str) -> Result<String, UiCommandError> {
    let normalized = mode.trim().to_ascii_lowercase();
    if normalized.is_empty() {
        return Err(UiCommandError::InvalidSecuritySettings {
            message: "secret_backend_mode must not be empty".to_string(),
        });
    }

    match normalized.as_str() {
        "keychain_only" | "encrypted_file_only" | "dual_write" => Ok(normalized),
        _ => Err(UiCommandError::InvalidSecuritySettings {
            message: format!(
                "secret_backend_mode '{}' is invalid; expected keychain_only|encrypted_file_only|dual_write",
                mode.trim()
            ),
        }),
    }
}

fn normalize_snapshot_path(path: &str) -> Result<String, UiCommandError> {
    let trimmed = path.trim();
    if trimmed.is_empty() {
        return Err(UiCommandError::InvalidSnapshotPath);
    }
    Ok(trimmed.to_string())
}

fn normalize_optional_text(value: Option<String>) -> Option<String> {
    value.and_then(|candidate| {
        let trimmed = candidate.trim();
        if trimmed.is_empty() {
            None
        } else {
            Some(trimmed.to_string())
        }
    })
}

fn default_model_root_path() -> PathBuf {
    if let Ok(home) = std::env::var("HOME") {
        return PathBuf::from(home).join(".metacanon_ai/models");
    }
    PathBuf::from(".metacanon_ai/models")
}

fn detect_qwen_model_hint(model_root: &PathBuf) -> bool {
    let Ok(entries) = std::fs::read_dir(model_root) else {
        return false;
    };
    entries
        .flatten()
        .filter_map(|entry| entry.file_name().into_string().ok())
        .any(|name| name.to_ascii_lowercase().contains("qwen"))
}

fn detect_ollama_status() -> (bool, bool, bool) {
    let version_output = Command::new("ollama").arg("--version").output();
    let Ok(version_output) = version_output else {
        return (false, false, false);
    };
    if !version_output.status.success() {
        return (false, false, false);
    }

    let list_output = Command::new("ollama").arg("list").output();
    let Ok(list_output) = list_output else {
        return (true, false, false);
    };
    if !list_output.status.success() {
        return (true, false, false);
    }

    let stdout = String::from_utf8_lossy(&list_output.stdout);
    let default_installed = stdout.lines().any(|line| {
        line.to_ascii_lowercase()
            .contains(&OLLAMA_DEFAULT_MODEL.to_ascii_lowercase())
    });
    (true, true, default_installed)
}

fn build_local_bootstrap_status() -> LocalBootstrapStatus {
    let model_root = default_model_root_path();
    let model_root_exists = model_root.is_dir();
    let qwen_model_hint_present = if model_root_exists {
        detect_qwen_model_hint(&model_root)
    } else {
        false
    };

    let (ollama_installed, ollama_reachable, ollama_default_model_installed) =
        detect_ollama_status();

    let mut recommended_actions = Vec::new();
    if !model_root_exists {
        recommended_actions.push("Create local model root directory.".to_string());
    }
    if !qwen_model_hint_present {
        recommended_actions
            .push("Download or place a local Qwen model artifact under model root.".to_string());
    }
    if !ollama_installed {
        recommended_actions.push("Install Ollama for local fallback compatibility.".to_string());
    } else if !ollama_reachable {
        recommended_actions
            .push("Start Ollama runtime so the local endpoint is reachable.".to_string());
    } else if !ollama_default_model_installed {
        recommended_actions.push(format!(
            "Run `ollama pull {}` to install the default local model.",
            OLLAMA_DEFAULT_MODEL
        ));
    }

    LocalBootstrapStatus {
        model_root: model_root.to_string_lossy().into_owned(),
        model_root_exists,
        qwen_model_hint_present,
        ollama_installed,
        ollama_reachable,
        ollama_default_model_installed,
        recommended_actions,
    }
}

fn normalize_existing_path(path: &str, field_name: &str) -> Result<PathBuf, UiCommandError> {
    let trimmed = path.trim();
    if trimmed.is_empty() {
        return Err(UiCommandError::LocalBootstrap {
            message: format!("{field_name} must not be empty"),
        });
    }
    let source = PathBuf::from(trimmed);
    if !source.exists() {
        return Err(UiCommandError::LocalBootstrap {
            message: format!("{field_name} does not exist: {}", source.to_string_lossy()),
        });
    }
    Ok(source)
}

fn copy_directory_recursive(source: &Path, destination: &Path) -> Result<usize, UiCommandError> {
    std::fs::create_dir_all(destination).map_err(|error| UiCommandError::LocalBootstrap {
        message: format!(
            "failed to create destination directory '{}': {error}",
            destination.to_string_lossy()
        ),
    })?;

    let entries = std::fs::read_dir(source).map_err(|error| UiCommandError::LocalBootstrap {
        message: format!(
            "failed to read source directory '{}': {error}",
            source.to_string_lossy()
        ),
    })?;

    let mut copied_files = 0usize;
    for entry in entries {
        let entry = entry.map_err(|error| UiCommandError::LocalBootstrap {
            message: format!("failed to read source directory entry: {error}"),
        })?;
        let source_path = entry.path();
        let destination_path = destination.join(entry.file_name());
        let metadata = entry
            .metadata()
            .map_err(|error| UiCommandError::LocalBootstrap {
                message: format!(
                    "failed to read metadata for '{}': {error}",
                    source_path.to_string_lossy()
                ),
            })?;

        if metadata.is_dir() {
            copied_files = copied_files
                .saturating_add(copy_directory_recursive(&source_path, &destination_path)?);
        } else if metadata.is_file() {
            std::fs::copy(&source_path, &destination_path).map_err(|error| {
                UiCommandError::LocalBootstrap {
                    message: format!(
                        "failed to copy '{}' to '{}': {error}",
                        source_path.to_string_lossy(),
                        destination_path.to_string_lossy()
                    ),
                }
            })?;
            copied_files = copied_files.saturating_add(1);
        }
    }

    Ok(copied_files)
}

fn is_tar_like_extension(source: &Path) -> bool {
    let lower = source.to_string_lossy().to_ascii_lowercase();
    lower.ends_with(".tar") || lower.ends_with(".tar.gz") || lower.ends_with(".tgz")
}

fn install_local_model_pack_to_root(
    source: &Path,
    model_root: &Path,
) -> Result<(String, usize, Vec<String>), UiCommandError> {
    std::fs::create_dir_all(model_root).map_err(|error| UiCommandError::LocalBootstrap {
        message: format!(
            "failed to create local model root '{}': {error}",
            model_root.to_string_lossy()
        ),
    })?;

    let mut notes = Vec::new();
    if source.is_dir() {
        let file_count = copy_directory_recursive(source, model_root)?;
        notes.push("copied model pack directory into local model root".to_string());
        return Ok(("directory".to_string(), file_count, notes));
    }

    if source.is_file() {
        let lower = source.to_string_lossy().to_ascii_lowercase();
        if lower.ends_with(".zip") {
            let output = Command::new("unzip")
                .arg("-o")
                .arg(source)
                .arg("-d")
                .arg(model_root)
                .output()
                .map_err(|error| UiCommandError::LocalBootstrap {
                    message: format!(
                        "failed to execute unzip for '{}': {error}",
                        source.to_string_lossy()
                    ),
                })?;
            if !output.status.success() {
                return Err(UiCommandError::LocalBootstrap {
                    message: format!(
                        "unzip failed: {}",
                        String::from_utf8_lossy(&output.stderr).trim()
                    ),
                });
            }
            notes.push("extracted zip archive into local model root".to_string());
            return Ok(("zip_archive".to_string(), 0, notes));
        }

        if is_tar_like_extension(source) {
            let output = Command::new("tar")
                .arg("-xf")
                .arg(source)
                .arg("-C")
                .arg(model_root)
                .output()
                .map_err(|error| UiCommandError::LocalBootstrap {
                    message: format!(
                        "failed to execute tar extraction for '{}': {error}",
                        source.to_string_lossy()
                    ),
                })?;
            if !output.status.success() {
                return Err(UiCommandError::LocalBootstrap {
                    message: format!(
                        "tar extraction failed: {}",
                        String::from_utf8_lossy(&output.stderr).trim()
                    ),
                });
            }
            notes.push("extracted tar archive into local model root".to_string());
            return Ok(("tar_archive".to_string(), 0, notes));
        }

        let destination =
            model_root.join(source.file_name().map(ToOwned::to_owned).ok_or_else(|| {
                UiCommandError::LocalBootstrap {
                    message: format!(
                        "source file '{}' is missing a file name",
                        source.to_string_lossy()
                    ),
                }
            })?);
        std::fs::copy(source, &destination).map_err(|error| UiCommandError::LocalBootstrap {
            message: format!(
                "failed to copy model file '{}' to '{}': {error}",
                source.to_string_lossy(),
                destination.to_string_lossy()
            ),
        })?;
        notes.push("copied single model file into local model root".to_string());
        return Ok(("single_file".to_string(), 1, notes));
    }

    Err(UiCommandError::LocalBootstrap {
        message: format!(
            "unsupported model pack source type: {}",
            source.to_string_lossy()
        ),
    })
}

fn parse_agent_routing_mode(value: &str) -> Result<AgentRoutingMode, UiCommandError> {
    AgentRoutingMode::parse(value).ok_or_else(|| UiCommandError::InvalidCommunicationSettings {
        message: format!(
            "routing_mode '{}' is invalid; expected per_agent|orchestrator",
            value.trim()
        ),
    })
}

fn parse_communication_platform(value: &str) -> Result<CommunicationPlatform, UiCommandError> {
    CommunicationPlatform::parse(value).ok_or_else(|| {
        UiCommandError::InvalidCommunicationSettings {
            message: format!(
                "platform '{}' is invalid; expected telegram|discord|in_app",
                value.trim()
            ),
        }
    })
}

fn validate_outbound_message_against_constitution( // HOPF: Add soul_file parameter as Option to enforce Hopf projection map while preserving backward compatibility
    message: &str,
    soul_file: Option<&SoulFile>,
) -> Result<String, UiCommandError> {
    let trimmed = message.trim();
    if trimmed.is_empty() {
        return Err(UiCommandError::ConstitutionalViolation {
            message: "message must not be empty".to_string(),
        });
    }

    let lowered = trimmed.to_ascii_lowercase();
    let blocked_patterns = [
        "disable constitutional",
        "bypass constitutional",
        "ignore will vector",
        "override will vector",
        "delete audit log",
        "bypass hitl",
    ];
    let mut request = GenerateRequest::new(trimmed.to_string());
    if let Some(matched) = blocked_patterns
        .iter()
        .find(|pattern| lowered.contains(**pattern))
    {
        request.metadata.insert(
            "blocked_by_will_vector".to_string(),
            format!("matched blocked pattern: {matched}"),
        );
    }

    if let Some(soul_file_ref) = soul_file {
        let action = crate::genesis::ActionSpace::from_prompt(trimmed); // HOPF: Create ActionSpace for Hopf projection
        if let Err(error) = soul_file_ref.validate_action(&action) { // HOPF: Use validate_action from SoulFile to enforce Shiab operator
            return Err(UiCommandError::ConstitutionalViolation {
                message: error.to_string(),
            });
        }
    } else {
        // HOPF: Skip validation if soul_file is not provided to preserve backward compatibility
    }

    Ok(trimmed.to_string())
}

fn config_has_non_empty_string(config: &Value, key: &str) -> bool {
    config
        .get(key)
        .and_then(Value::as_str)
        .is_some_and(|value| !value.trim().is_empty())
}

fn config_object_has_non_empty_values(config: &Value) -> bool {
    let Some(object) = config.as_object() else {
        return false;
    };

    object.values().any(|value| match value {
        Value::Null => false,
        Value::Bool(flag) => *flag,
        Value::Number(_) => true,
        Value::String(value) => !value.trim().is_empty(),
        Value::Array(values) => !values.is_empty(),
        Value::Object(values) => !values.is_empty(),
    })
}

fn string_field(
    provider_id: &str,
    object: &Map<String, Value>,
    field: &str,
) -> Result<Option<String>, UiCommandError> {
    match object.get(field) {
        Some(Value::String(value)) => Ok(Some(value.clone())),
        Some(Value::Null) => Ok(None),
        Some(_) => Err(UiCommandError::InvalidProviderConfig {
            provider_id: provider_id.to_string(),
            message: format!("'{field}' must be a string"),
        }),
        None => Ok(None),
    }
}

fn bool_field(
    provider_id: &str,
    object: &Map<String, Value>,
    field: &str,
) -> Result<Option<bool>, UiCommandError> {
    match object.get(field) {
        Some(Value::Bool(value)) => Ok(Some(*value)),
        Some(_) => Err(UiCommandError::InvalidProviderConfig {
            provider_id: provider_id.to_string(),
            message: format!("'{field}' must be a boolean"),
        }),
        None => Ok(None),
    }
}

fn string_array_field(
    provider_id: &str,
    object: &Map<String, Value>,
    field: &str,
) -> Result<Option<Vec<String>>, UiCommandError> {
    let Some(value) = object.get(field) else {
        return Ok(None);
    };

    let Some(array) = value.as_array() else {
        return Err(UiCommandError::InvalidProviderConfig {
            provider_id: provider_id.to_string(),
            message: format!("'{field}' must be an array of strings"),
        });
    };

    let mut parsed = Vec::with_capacity(array.len());
    for item in array {
        let Some(item) = item.as_str() else {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: provider_id.to_string(),
                message: format!("'{field}' must contain only strings"),
            });
        };
        let trimmed = item.trim();
        if !trimmed.is_empty() {
            parsed.push(trimmed.to_string());
        }
    }

    Ok(Some(parsed))
}

fn value_object<'a>(
    provider_id: &str,
    config: Option<&'a Value>,
) -> Result<Option<&'a Map<String, Value>>, UiCommandError> {
    match config {
        Some(Value::Object(object)) => Ok(Some(object)),
        Some(_) => Err(UiCommandError::InvalidProviderConfig {
            provider_id: provider_id.to_string(),
            message: "config must be a JSON object".to_string(),
        }),
        None => Ok(None),
    }
}

fn qwen_config_from_value(config: Option<&Value>) -> Result<QwenLocalConfig, UiCommandError> {
    let mut parsed = QwenLocalConfig::default();
    let Some(object) = value_object(PROVIDER_QWEN_LOCAL, config)? else {
        return Ok(parsed);
    };

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "primary_target")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'primary_target' must not be empty".to_string(),
            });
        }
        parsed.primary_target = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "downgrade_profile")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'downgrade_profile' must not be empty".to_string(),
            });
        }
        parsed.downgrade_profile = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "downgrade_target")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'downgrade_target' must not be empty".to_string(),
            });
        }
        parsed.downgrade_target = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "runtime_backend")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'runtime_backend' must not be empty".to_string(),
            });
        }
        parsed.runtime_backend = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "base_url")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'base_url' must not be empty".to_string(),
            });
        }
        parsed.base_url = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "primary_model_id")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'primary_model_id' must not be empty".to_string(),
            });
        }
        parsed.primary_model_id = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "downgrade_model_id")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'downgrade_model_id' must not be empty".to_string(),
            });
        }
        parsed.downgrade_model_id = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "llama_cpp_binary")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_QWEN_LOCAL.to_string(),
                message: "'llama_cpp_binary' must not be empty".to_string(),
            });
        }
        parsed.llama_cpp_binary = value;
    }

    if let Some(value) = string_field(PROVIDER_QWEN_LOCAL, object, "llama_cpp_model_path")? {
        parsed.llama_cpp_model_path = value;
    }

    if let Some(value) = bool_field(PROVIDER_QWEN_LOCAL, object, "live_api")? {
        parsed.live_api = value;
    }

    if let Some(value) = bool_field(PROVIDER_QWEN_LOCAL, object, "available")? {
        parsed.available = value;
    }

    Ok(parsed)
}

fn ollama_config_from_value(config: Option<&Value>) -> Result<OllamaConfig, UiCommandError> {
    let mut parsed = OllamaConfig::default();
    let Some(object) = value_object(PROVIDER_OLLAMA, config)? else {
        return Ok(parsed);
    };

    if let Some(value) = string_field(PROVIDER_OLLAMA, object, "base_url")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_OLLAMA.to_string(),
                message: "'base_url' must not be empty".to_string(),
            });
        }
        parsed.base_url = value;
    }

    if let Some(value) = string_field(PROVIDER_OLLAMA, object, "default_model")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: PROVIDER_OLLAMA.to_string(),
                message: "'default_model' must not be empty".to_string(),
            });
        }
        parsed.default_model = value;
    }

    if let Some(values) = string_array_field(PROVIDER_OLLAMA, object, "installed_models")? {
        parsed.installed_models = values;
    }

    if parsed.installed_models.is_empty() {
        parsed.installed_models.push(parsed.default_model.clone());
    }

    if !parsed
        .installed_models
        .iter()
        .any(|model| model == &parsed.default_model)
    {
        parsed
            .installed_models
            .insert(0, parsed.default_model.clone());
    }

    if let Some(value) = bool_field(PROVIDER_OLLAMA, object, "available")? {
        parsed.available = value;
    }

    if let Some(value) = bool_field(PROVIDER_OLLAMA, object, "live_api")? {
        parsed.live_api = value;
    }

    Ok(parsed)
}

fn openai_config_from_value(config: Option<&Value>) -> Result<OpenAiConfig, UiCommandError> {
    let mut parsed = OpenAiConfig::default();
    let Some(object) = value_object(OPENAI_PROVIDER_ID, config)? else {
        return Ok(parsed);
    };

    if let Some(value) = string_field(OPENAI_PROVIDER_ID, object, "api_key")? {
        parsed.api_key = if value.trim().is_empty() {
            None
        } else {
            Some(value)
        };
    } else if object.get("api_key").is_some_and(Value::is_null) {
        parsed.api_key = None;
    }

    if let Some(value) = string_field(OPENAI_PROVIDER_ID, object, "base_url")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: OPENAI_PROVIDER_ID.to_string(),
                message: "'base_url' must not be empty".to_string(),
            });
        }
        parsed.base_url = value;
    }

    if let Some(value) = string_field(OPENAI_PROVIDER_ID, object, "chat_model")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: OPENAI_PROVIDER_ID.to_string(),
                message: "'chat_model' must not be empty".to_string(),
            });
        }
        parsed.chat_model = value;
    }

    if let Some(value) = string_field(OPENAI_PROVIDER_ID, object, "embedding_model")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: OPENAI_PROVIDER_ID.to_string(),
                message: "'embedding_model' must not be empty".to_string(),
            });
        }
        parsed.embedding_model = value;
    }

    if let Some(value) = bool_field(OPENAI_PROVIDER_ID, object, "available")? {
        parsed.available = value;
    }

    if let Some(value) = bool_field(OPENAI_PROVIDER_ID, object, "live_api")? {
        parsed.live_api = value;
    }

    Ok(parsed)
}

fn anthropic_config_from_value(config: Option<&Value>) -> Result<AnthropicConfig, UiCommandError> {
    let mut parsed = AnthropicConfig::default();
    let Some(object) = value_object(ANTHROPIC_PROVIDER_ID, config)? else {
        return Ok(parsed);
    };

    if let Some(value) = string_field(ANTHROPIC_PROVIDER_ID, object, "api_key")? {
        parsed.api_key = if value.trim().is_empty() {
            None
        } else {
            Some(value)
        };
    } else if object.get("api_key").is_some_and(Value::is_null) {
        parsed.api_key = None;
    }

    if let Some(value) = string_field(ANTHROPIC_PROVIDER_ID, object, "base_url")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: ANTHROPIC_PROVIDER_ID.to_string(),
                message: "'base_url' must not be empty".to_string(),
            });
        }
        parsed.base_url = value;
    }

    if let Some(value) = string_field(ANTHROPIC_PROVIDER_ID, object, "model")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: ANTHROPIC_PROVIDER_ID.to_string(),
                message: "'model' must not be empty".to_string(),
            });
        }
        parsed.model = value;
    }

    if let Some(value) = bool_field(ANTHROPIC_PROVIDER_ID, object, "available")? {
        parsed.available = value;
    }

    if let Some(value) = bool_field(ANTHROPIC_PROVIDER_ID, object, "live_api")? {
        parsed.live_api = value;
    }

    Ok(parsed)
}

fn moonshot_kimi_config_from_value(
    config: Option<&Value>,
) -> Result<MoonshotKimiConfig, UiCommandError> {
    let mut parsed = MoonshotKimiConfig::default();
    let Some(object) = value_object(MOONSHOT_KIMI_PROVIDER_ID, config)? else {
        return Ok(parsed);
    };

    if let Some(value) = string_field(MOONSHOT_KIMI_PROVIDER_ID, object, "api_key")? {
        parsed.api_key = if value.trim().is_empty() {
            None
        } else {
            Some(value)
        };
    } else if object.get("api_key").is_some_and(Value::is_null) {
        parsed.api_key = None;
    }

    if let Some(value) = string_field(MOONSHOT_KIMI_PROVIDER_ID, object, "base_url")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: MOONSHOT_KIMI_PROVIDER_ID.to_string(),
                message: "'base_url' must not be empty".to_string(),
            });
        }
        parsed.base_url = value;
    }

    if let Some(value) = string_field(MOONSHOT_KIMI_PROVIDER_ID, object, "model")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: MOONSHOT_KIMI_PROVIDER_ID.to_string(),
                message: "'model' must not be empty".to_string(),
            });
        }
        parsed.model = value;
    }

    if let Some(value) = bool_field(MOONSHOT_KIMI_PROVIDER_ID, object, "available")? {
        parsed.available = value;
    }

    if let Some(value) = bool_field(MOONSHOT_KIMI_PROVIDER_ID, object, "live_api")? {
        parsed.live_api = value;
    }

    Ok(parsed)
}

fn grok_config_from_value(config: Option<&Value>) -> Result<GrokConfig, UiCommandError> {
    let mut parsed = GrokConfig::default();
    let Some(object) = value_object(GROK_PROVIDER_ID, config)? else {
        return Ok(parsed);
    };

    if let Some(value) = string_field(GROK_PROVIDER_ID, object, "api_key")? {
        parsed.api_key = if value.trim().is_empty() {
            None
        } else {
            Some(value)
        };
    } else if object.get("api_key").is_some_and(Value::is_null) {
        parsed.api_key = None;
    }

    if let Some(value) = string_field(GROK_PROVIDER_ID, object, "base_url")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: GROK_PROVIDER_ID.to_string(),
                message: "'base_url' must not be empty".to_string(),
            });
        }
        parsed.base_url = value;
    }

    if let Some(value) = string_field(GROK_PROVIDER_ID, object, "model")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: GROK_PROVIDER_ID.to_string(),
                message: "'model' must not be empty".to_string(),
            });
        }
        parsed.model = value;
    }

    if let Some(value) = bool_field(GROK_PROVIDER_ID, object, "live_api")? {
        parsed.live_api = value;
    }

    if let Some(value) = bool_field(GROK_PROVIDER_ID, object, "available")? {
        parsed.available = value;
    }

    Ok(parsed)
}

fn morpheus_config_from_value(config: Option<&Value>) -> Result<MorpheusConfig, UiCommandError> {
    let mut parsed = MorpheusConfig::default();
    let Some(object) = value_object(MORPHEUS_PROVIDER_ID, config)? else {
        return Ok(parsed);
    };

    if let Some(value) = string_field(MORPHEUS_PROVIDER_ID, object, "router_id")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: MORPHEUS_PROVIDER_ID.to_string(),
                message: "'router_id' must not be empty".to_string(),
            });
        }
        parsed.router_id = value;
    }

    if let Some(value) = string_field(MORPHEUS_PROVIDER_ID, object, "endpoint")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: MORPHEUS_PROVIDER_ID.to_string(),
                message: "'endpoint' must not be empty".to_string(),
            });
        }
        parsed.endpoint = value;
    }

    if let Some(value) = string_field(MORPHEUS_PROVIDER_ID, object, "model")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: MORPHEUS_PROVIDER_ID.to_string(),
                message: "'model' must not be empty".to_string(),
            });
        }
        parsed.model = value;
    }

    if let Some(value) = string_field(MORPHEUS_PROVIDER_ID, object, "key_id")? {
        if value.trim().is_empty() {
            return Err(UiCommandError::InvalidProviderConfig {
                provider_id: MORPHEUS_PROVIDER_ID.to_string(),
                message: "'key_id' must not be empty".to_string(),
            });
        }
        parsed.key_id = value;
    }

    if let Some(value) = bool_field(MORPHEUS_PROVIDER_ID, object, "available")? {
        parsed.available = value;
    }

    Ok(parsed)
}

fn merge_json_objects(target: &mut Map<String, Value>, patch: &Map<String, Value>) {
    for (key, value) in patch {
        match (target.get_mut(key), value) {
            (Some(Value::Object(target_obj)), Value::Object(patch_obj)) => {
                merge_json_objects(target_obj, patch_obj);
            }
            _ => {
                target.insert(key.clone(), value.clone());
            }
        }
    }
}

fn redacted_provider_config(mut config: Value) -> Value {
    let Some(object) = config